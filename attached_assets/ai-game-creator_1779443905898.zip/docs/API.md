# API Documentation

## REST API Endpoints

### Games

#### POST /api/v1/games/create
Create a new game from prompt.

**Request Body:**
```json
{
  "prompt": "string (required)",
  "genre": "string (optional)",
  "platform": ["string"] (optional),
  "multiplayer": "boolean (optional)",
  "complexity": "string (optional: simple|medium|complex)",
  "style": "string (optional: realistic|cartoon|lowpoly|retro)"
}
```

**Response:**
```json
{
  "success": true,
  "project": {
    "id": "uuid",
    "name": "GameName",
    "status": "planning",
    "progress": 0
  }
}
```

#### GET /api/v1/games
List all projects.

#### GET /api/v1/games/:id
Get project details.

#### PATCH /api/v1/games/:id
Update project settings.

#### DELETE /api/v1/games/:id
Delete project.

#### POST /api/v1/games/:id/export
Export build for platform.

### Agents

#### GET /api/v1/agents
List all agent statuses.

#### GET /api/v1/agents/:id
Get specific agent status.

#### POST /api/v1/agents/:id/restart
Restart agent.

### Assets

#### GET /api/v1/assets/:projectId/:assetId
Get asset details.

#### POST /api/v1/assets/:projectId/:assetId/regenerate
Regenerate asset.

## WebSocket Events

### Client -> Server
- `subscribe`: Subscribe to project updates
- `unsubscribe`: Unsubscribe from project
- `command`: Send command to server

### Server -> Client
- `log`: Build log entry
- `agent_update`: Agent status change
- `project_update`: Project progress update
- `build_complete`: Build finished
- `build_error`: Build error occurred

## Error Codes

| Code | Description |
|------|-------------|
| 400 | Bad Request |
| 404 | Not Found |
| 500 | Internal Server Error |
| 503 | Service Unavailable |
