# AI Game Creator - Documentation

## Overview

AI Game Creator is a fully autonomous AI-powered platform that generates, edits, tests, optimizes, and packages complete playable Unreal Engine 5 games from a single text prompt.

## Features

- **Single-Prompt Game Generation**: Describe your game in natural language
- **10+ Specialized AI Agents**: Level design, coding, art, sound, QA, networking
- **Unreal Engine 5 Integration**: Native UE5 project generation with C++ and Blueprints
- **Mobile Optimization**: Android APK, iOS, and Windows builds with Nanite/Lumen
- **Multiplayer Support**: LAN, dedicated servers, EOS, and Steam integration
- **Auto Debugging**: AI detects and fixes compile errors automatically
- **Real-time Dashboard**: Web-based studio with live build monitoring

## Quick Start

### Prerequisites

- Node.js 18+
- Unreal Engine 5.4+ (optional, for actual builds)
- 16GB+ RAM (32GB recommended)
- NVIDIA GPU with 8GB+ VRAM (for local AI models)

### Installation

```bash
# Clone the repository
git clone https://github.com/your-org/ai-game-creator.git
cd ai-game-creator

# Run setup
node scripts/setup.js

# Or manually:
npm install
cd apps/web && npm install && cd ../..
cd apps/server && npm install && cd ../..

# Create .env file
cp .env.example .env
# Edit .env with your API keys
```

### Running the Platform

```bash
# Start all services (uses turbo)
npm run dev

# Or start individually:
cd apps/web && npm run dev    # Dashboard on http://localhost:3000
cd apps/server && npm run dev  # API on http://localhost:8000
```

### Creating Your First Game

1. Open http://localhost:3000
2. Enter a prompt like: "Create a realistic multiplayer survival shooter with zombies"
3. Select platforms (Windows, Android, Linux)
4. Click "Create Game"
5. Watch AI agents build your game in real-time

## Architecture

```
ai-game-creator/
├── apps/
│   ├── web/              # Next.js 14 Dashboard
│   └── server/           # Node.js + Express Backend
├── packages/
│   ├── ue5-bridge/       # Python UE5 Automation
│   ├── ai-core/          # AI Model Integration
│   └── shared/           # Shared Types & Utils
├── docker/               # Docker Compose Config
└── scripts/              # Setup & Utility Scripts
```

## AI Agents

| Agent | Role | Description |
|-------|------|-------------|
| AI Director | Orchestrator | Breaks prompts into tasks, manages workflow |
| Level Designer | Level Design | Generates maps, terrain, lighting |
| Blueprint Agent | Blueprints | Creates visual scripting |
| C++ Coder | Programming | Writes game logic, systems |
| Asset Generator | Art | Generates 3D models, textures |
| UI Designer | Interface | Creates HUD, menus, widgets |
| Audio Engineer | Sound | Generates music, SFX |
| Network Engineer | Multiplayer | Implements networking |
| QA Tester | Testing | Automated gameplay tests |
| Optimizer | Performance | Mobile optimization, LODs |

## API Reference

### Create Game
```http
POST /api/v1/games/create
Content-Type: application/json

{
  "prompt": "Create a battle royale game",
  "genre": "shooter",
  "platform": ["windows", "android"],
  "multiplayer": true,
  "complexity": "complex"
}
```

### Get Project Status
```http
GET /api/v1/games/:id
```

### Export Build
```http
POST /api/v1/games/:id/export
{
  "platform": "android"
}
```

## Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `PORT` | HTTP API port | 8000 |
| `WS_PORT` | WebSocket port | 8001 |
| `UE5_PATH` | Unreal Engine installation | - |
| `OPENAI_API_KEY` | OpenAI API key | - |
| `CLAUDE_API_KEY` | Anthropic API key | - |
| `PROJECTS_DIR` | Projects storage path | ./projects |

## Mobile Optimization

The platform automatically optimizes for mobile devices:

- **Nanite**: Virtualized geometry with fallback LODs
- **Lumen**: Dynamic global illumination (mobile variant)
- **Texture Compression**: ASTC/ETC2 for mobile GPUs
- **Draw Call Batching**: Instanced rendering, occlusion culling
- **LOD Generation**: Automatic level-of-detail meshes
- **Memory Management**: Streaming pools, texture streaming

## Multiplayer

Supported networking modes:

- **LAN**: Local network multiplayer
- **Dedicated Server**: Headless server builds
- **EOS**: Epic Online Services integration
- **Steam**: Steamworks networking ready
- **Voice Chat**: In-game voice communication
- **Anti-Cheat**: Server-side validation

## License

MIT License - See LICENSE file for details.
