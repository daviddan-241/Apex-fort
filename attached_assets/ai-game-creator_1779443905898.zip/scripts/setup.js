#!/usr/bin/env node

const { execSync } = require('child_process');
const fs = require('fs');

console.log('🎮 AI Game Creator - Setup');
console.log('=========================\n');

const steps = [
  {
    name: 'Check Node.js version',
    run: () => {
      const version = process.version;
      const major = parseInt(version.split('.')[0].replace('v', ''));
      if (major < 18) {
        throw new Error(`Node.js 18+ required. Current: ${version}`);
      }
      console.log(`✅ Node.js ${version}`);
    }
  },
  {
    name: 'Install root dependencies',
    run: () => {
      execSync('npm install', { stdio: 'inherit' });
      console.log('✅ Root dependencies installed');
    }
  },
  {
    name: 'Install web dashboard dependencies',
    run: () => {
      process.chdir('apps/web');
      execSync('npm install', { stdio: 'inherit' });
      process.chdir('../..');
      console.log('✅ Web dashboard dependencies installed');
    }
  },
  {
    name: 'Install server dependencies',
    run: () => {
      process.chdir('apps/server');
      execSync('npm install', { stdio: 'inherit' });
      process.chdir('../..');
      console.log('✅ Server dependencies installed');
    }
  },
  {
    name: 'Create environment file',
    run: () => {
      const envContent = `PORT=8000
WS_PORT=8001
NODE_ENV=development
LOG_LEVEL=info
PROJECTS_DIR=./projects
UE5_PATH=C:/Program Files/Epic Games/UE_5.4
OPENAI_API_KEY=your_openai_key_here
CLAUDE_API_KEY=your_claude_key_here
DATABASE_URL=postgresql://localhost:5432/aigamecreator
JWT_SECRET=your_jwt_secret_here
`;
      fs.writeFileSync('.env', envContent);
      console.log('✅ Environment file created (.env)');
    }
  },
  {
    name: 'Create projects directory',
    run: () => {
      fs.mkdirSync('projects', { recursive: true });
      console.log('✅ Projects directory created');
    }
  },
  {
    name: 'Create logs directory',
    run: () => {
      fs.mkdirSync('logs', { recursive: true });
      console.log('✅ Logs directory created');
    }
  },
];

(async () => {
  for (const step of steps) {
    console.log(`\n📦 ${step.name}...`);
    try {
      step.run();
    } catch (error) {
      console.error(`❌ ${step.name} failed:`, error.message);
      process.exit(1);
    }
  }

  console.log('\n✨ Setup complete!');
  console.log('\nNext steps:');
  console.log('  1. Edit .env with your API keys and UE5 path');
  console.log('  2. Start the backend: npm run dev');
  console.log('  3. Open http://localhost:3000 in your browser');
})();
