# AI Game Creator - Autonomous UE5 Game Development Platform

## Overview
A fully autonomous AI-powered platform that generates, edits, tests, optimizes, and packages complete playable Unreal Engine 5 games from a single text prompt.

## Quick Start

```bash
# 1. Clone and setup
npm run setup

# 2. Start all services
npm run dev

# 3. Open http://localhost:3000
```

## Architecture
- **Web Dashboard** (Next.js 14, React, Tailwind, Framer Motion)
- **AI Orchestrator** (Node.js + Python FastAPI)
- **Multi-Agent System** (10+ specialized AI agents)
- **UE5 Bridge** (Python automation + C++ generation)
- **Asset Pipeline** (AI 3D, textures, audio generation)

## Features
- Single-prompt game generation
- Automatic UE5 project creation
- AI asset generation (3D models, textures, audio)
- Blueprint & C++ code generation
- Auto-debugging & error fixing
- AI gameplay testing
- Multiplayer support (LAN, dedicated servers)
- Export to Windows, Android, Linux

## System Requirements
- Windows 10/11 or Linux
- 16GB+ RAM (32GB recommended)
- NVIDIA GPU with 8GB+ VRAM
- 100GB+ free disk space
- Unreal Engine 5.4+

## License
MIT
