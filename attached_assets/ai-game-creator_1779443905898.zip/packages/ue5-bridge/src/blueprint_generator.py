import json
from pathlib import Path
from typing import Dict, List

class BlueprintGenerator:
    def __init__(self, ue5_path: str):
        self.ue5_path = Path(ue5_path)
        self.editor_cmd = self.ue5_path / "Engine/Binaries/Win64/UE5Editor-Cmd.exe"

    def generate_from_json(self, project_path: str, blueprint_json: Dict) -> Dict:
        """Generate Blueprint from JSON definition"""
        script = self._blueprint_to_python(blueprint_json)
        return self._execute_script(project_path, script)

    def _blueprint_to_python(self, blueprint_data: Dict) -> str:
        """Convert Blueprint JSON to Python script"""
        name = blueprint_data.get('name', 'NewBlueprint')
        bp_type = blueprint_data.get('type', 'Actor')

        script = f"""
import unreal

# Create Blueprint
factory = unreal.BlueprintFactory()
parent_class = unreal.{bp_type} if hasattr(unreal, '{bp_type}') else unreal.Actor
factory.set_editor_property('parent_class', parent_class)

asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
blueprint = asset_tools.create_asset(
    '{name}',
    '/Game/Blueprints',
    unreal.Blueprint,
    factory
)

# Get generated class
bp_class = unreal.EditorAssetLibrary.load_blueprint_class('/Game/Blueprints/{name}')

# Add components
components = {blueprint_data.get('components', [])}
for comp_data in components:
    comp_name = comp_data.get('name', 'Component')
    comp_type = comp_data.get('type', 'SceneComponent')

    if comp_type == 'SkeletalMesh':
        comp = unreal.SkeletalMeshComponent()
    elif comp_type == 'CameraComponent':
        comp = unreal.CameraComponent()
    elif comp_type == 'SpringArmComponent':
        comp = unreal.SpringArmComponent()
    elif comp_type == 'StaticMesh':
        comp = unreal.StaticMeshComponent()
    else:
        comp = unreal.SceneComponent()

    comp.set_editor_property('component_name', comp_name)
    unreal.EditorLevelLibrary.spawn_actor_from_class(bp_class, unreal.Vector(0, 0, 0))

print(f"Blueprint {name} created successfully")
"""

        return script

    def add_event_graph_nodes(self, project_path: str, blueprint_name: str, nodes: List[Dict]) -> Dict:
        """Add nodes to Blueprint Event Graph"""
        script = f"""
import unreal

# Load Blueprint
blueprint_path = f'/Game/Blueprints/{blueprint_name}'
blueprint = unreal.EditorAssetLibrary.load_asset(blueprint_path)

if not blueprint:
    print(f"Blueprint not found: {blueprint_path}")
    exit(1)

# Get Event Graph
graph = blueprint.get_editor_property('uber_graph_pages')[0]

# Add nodes
nodes_data = {nodes}
for node_data in nodes_data:
    node_type = node_data.get('type')

    if node_type == 'EventBeginPlay':
        node = unreal.EditorGraphLibrary.create_node(graph, unreal.K2Node_EventBeginPlay)
    elif node_type == 'PrintString':
        node = unreal.EditorGraphLibrary.create_node(graph, unreal.K2Node_CallFunction)
        # Configure print string
    elif node_type == 'CustomEvent':
        node = unreal.EditorGraphLibrary.create_node(graph, unreal.K2Node_CustomEvent)
        node.set_editor_property('custom_event_name', node_data.get('name', 'CustomEvent'))

    print(f"Added node: {node_type}")

# Compile Blueprint
unreal.EditorAssetLibrary.save_loaded_asset(blueprint)
print(f"Event Graph updated for {blueprint_name}")
"""

        return self._execute_script(project_path, script)

    def _execute_script(self, project_path: str, script: str) -> Dict:
        import subprocess

        project_name = Path(project_path).name
        script_file = Path(project_path) / "Scripts" / "blueprint_gen.py"
        script_file.parent.mkdir(parents=True, exist_ok=True)
        script_file.write_text(script)

        cmd = [
            str(self.editor_cmd),
            f"{project_path}/{project_name}.uproject",
            "-ExecutePythonScript",
            str(script_file),
            "-unattended",
            "-nullrhi",
        ]

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            return {
                "success": result.returncode == 0,
                "output": result.stdout,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
