import os
import json
from pathlib import Path
from typing import Dict, List

class AssetImporter:
    def __init__(self, ue5_path: str):
        self.ue5_path = Path(ue5_path)
        self.editor_cmd = self.ue5_path / "Engine/Binaries/Win64/UE5Editor-Cmd.exe"

    def import_mesh(self, project_path: str, mesh_path: str, destination: str = "/Game/Meshes") -> Dict:
        """Import 3D mesh into UE5 project"""
        script = f"""
import unreal

asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
import_data = unreal.FbxImportUI()
import_data.set_editor_property('import_mesh', True)
import_data.set_editor_property('import_textures', True)
import_data.set_editor_property('import_materials', True)
import_data.set_editor_property('import_animations', False)

task = unreal.AssetImportTask()
task.set_editor_property('filename', '{mesh_path}')
task.set_editor_property('destination_path', '{destination}')
task.set_editor_property('replace_existing', True)
task.set_editor_property('automated', True)
task.set_editor_property('save', True)
task.set_editor_property('options', import_data)

asset_tools.import_asset_tasks([task])
print(f"Imported: {mesh_path}")
"""

        return self._execute_script(project_path, script)

    def import_texture(self, project_path: str, texture_path: str, destination: str = "/Game/Textures") -> Dict:
        """Import texture into UE5 project"""
        script = f"""
import unreal

asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
texture_factory = unreal.TextureFactory()

task = unreal.AssetImportTask()
task.set_editor_property('filename', '{texture_path}')
task.set_editor_property('destination_path', '{destination}')
task.set_editor_property('replace_existing', True)
task.set_editor_property('automated', True)
task.set_editor_property('save', True)
task.set_editor_property('factory', texture_factory)

asset_tools.import_asset_tasks([task])
print(f"Imported texture: {texture_path}")
"""

        return self._execute_script(project_path, script)

    def import_sound(self, project_path: str, sound_path: str, destination: str = "/Game/Sounds") -> Dict:
        """Import audio into UE5 project"""
        script = f"""
import unreal

asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
sound_factory = unreal.SoundFactory()

task = unreal.AssetImportTask()
task.set_editor_property('filename', '{sound_path}')
task.set_editor_property('destination_path', '{destination}')
task.set_editor_property('replace_existing', True)
task.set_editor_property('automated', True)
task.set_editor_property('save', True)
task.set_editor_property('factory', sound_factory)

asset_tools.import_asset_tasks([task])
print(f"Imported sound: {sound_path}")
"""

        return self._execute_script(project_path, script)

    def import_blueprint(self, project_path: str, blueprint_data: Dict, destination: str = "/Game/Blueprints") -> Dict:
        """Create Blueprint from JSON data"""
        script = f"""
import unreal

# Create Blueprint from data
blueprint_factory = unreal.BlueprintFactory()
blueprint_factory.set_editor_property('parent_class', unreal.Actor)

asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
blueprint = asset_tools.create_asset(
    '{blueprint_data.get("name", "NewBlueprint")}',
    '{destination}',
    unreal.Blueprint,
    blueprint_factory
)

# Add components and nodes based on blueprint_data
print(f"Created Blueprint: {blueprint.get_name()}")
"""

        return self._execute_script(project_path, script)

    def batch_import(self, project_path: str, assets: List[Dict]) -> Dict:
        """Import multiple assets"""
        results = []

        for asset in assets:
            asset_type = asset.get('type', 'mesh')
            asset_path = asset.get('path')

            if asset_type == 'mesh':
                result = self.import_mesh(project_path, asset_path)
            elif asset_type == 'texture':
                result = self.import_texture(project_path, asset_path)
            elif asset_type == 'sound':
                result = self.import_sound(project_path, asset_path)
            else:
                result = {"success": False, "error": f"Unknown asset type: {asset_type}"}

            results.append({
                "asset": asset.get('name', 'Unknown'),
                "result": result,
            })

        return {
            "success": all(r["result"]["success"] for r in results),
            "results": results,
        }

    def _execute_script(self, project_path: str, script: str) -> Dict:
        """Execute Python script in UE5"""
        import subprocess

        project_name = Path(project_path).name
        script_file = Path(project_path) / "Scripts" / "import_script.py"
        script_file.parent.mkdir(parents=True, exist_ok=True)
        script_file.write_text(script)

        cmd = [
            str(self.editor_cmd),
            f"{project_path}/{project_name}.uproject",
            "-ExecutePythonScript",
            str(script_file),
            "-unattended",
            "-nullrhi",
        ]

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            return {
                "success": result.returncode == 0,
                "output": result.stdout,
                "errors": result.stderr if result.stderr else None,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
