import os
import subprocess
from pathlib import Path
from typing import Dict, List, Optional

class BuildSystem:
    def __init__(self, ue5_path: str):
        self.ue5_path = Path(ue5_path)
        self.build_tool = self.ue5_path / "Engine/Build/BatchFiles/Build.bat"
        self.run_uat = self.ue5_path / "Engine/Build/BatchFiles/RunUAT.bat"

    def compile_project(self, project_path: str, config: str = "Development", target: str = "Game") -> Dict:
        """Compile C++ code"""
        project_name = Path(project_path).name

        cmd = [
            str(self.build_tool),
            project_name + target,
            "Win64",
            config,
            f"-Project={project_path}/{project_name}.uproject",
            "-WaitMutex",
        ]

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
            return self._parse_result(result)
        except Exception as e:
            return {"success": False, "error": str(e)}

    def cook_content(self, project_path: str, platforms: List[str] = None) -> Dict:
        """Cook content for target platforms"""
        platforms = platforms or ["Windows"]
        project_name = Path(project_path).name

        results = []
        for platform in platforms:
            cmd = [
                str(self.run_uat),
                "BuildCookRun",
                f"-project={project_path}/{project_name}.uproject",
                f"-platform={platform}",
                "-clientconfig=Shipping",
                "-serverconfig=Shipping",
                "-cook",
                "-allmaps",
                "-stage",
                "-pak",
                "-archive",
                f"-archivedirectory={project_path}/Build/{platform}",
                "-prereqs",
                "-distribution",
                "-nodebuginfo",
                "-unattended",
                "-nullrhi",
            ]

            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=3600)
                results.append({
                    "platform": platform,
                    "result": self._parse_result(result),
                })
            except Exception as e:
                results.append({
                    "platform": platform,
                    "result": {"success": False, "error": str(e)},
                })

        return {
            "success": all(r["result"]["success"] for r in results),
            "platforms": results,
        }

    def package_android(self, project_path: str, output_dir: str = None) -> Dict:
        """Package for Android (APK)"""
        project_name = Path(project_path).name
        output = output_dir or f"{project_path}/Build/Android"

        cmd = [
            str(self.run_uat),
            "BuildCookRun",
            f"-project={project_path}/{project_name}.uproject",
            "-platform=Android",
            "-clientconfig=Shipping",
            "-cook",
            "-allmaps",
            "-stage",
            "-pak",
            "-archive",
            f"-archivedirectory={output}",
            "-prereqs",
            "-distribution",
            "-nodebuginfo",
            "-unattended",
        ]

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=7200)
            return self._parse_result(result)
        except Exception as e:
            return {"success": False, "error": str(e)}

    def package_linux(self, project_path: str, output_dir: str = None) -> Dict:
        """Package for Linux"""
        project_name = Path(project_path).name
        output = output_dir or f"{project_path}/Build/Linux"

        cmd = [
            str(self.run_uat),
            "BuildCookRun",
            f"-project={project_path}/{project_name}.uproject",
            "-platform=Linux",
            "-clientconfig=Shipping",
            "-cook",
            "-allmaps",
            "-stage",
            "-pak",
            "-archive",
            f"-archivedirectory={output}",
            "-prereqs",
            "-distribution",
            "-nodebuginfo",
            "-unattended",
        ]

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=3600)
            return self._parse_result(result)
        except Exception as e:
            return {"success": False, "error": str(e)}

    def run_tests(self, project_path: str, test_filter: str = None) -> Dict:
        """Run automated tests"""
        project_name = Path(project_path).name

        cmd = [
            str(self.ue5_path / "Engine/Binaries/Win64/UE5Editor-Cmd.exe"),
            f"{project_path}/{project_name}.uproject",
            "-ExecCmds=Automation RunAll",
            "-unattended",
            "-nullrhi",
            "-ReportOutputPath",
            f"{project_path}/TestResults",
        ]

        if test_filter:
            cmd.extend(["-TestFilter", test_filter])

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
            return self._parse_result(result)
        except Exception as e:
            return {"success": False, "error": str(e)}

    def _parse_result(self, result) -> Dict:
        """Parse subprocess result"""
        output = result.stdout + result.stderr

        errors = []
        warnings = []

        for line in output.split('\n'):
            if 'error:' in line.lower() or 'error C' in line:
                errors.append(line.strip())
            elif 'warning:' in line.lower():
                warnings.append(line.strip())

        return {
            "success": result.returncode == 0 and len(errors) == 0,
            "returncode": result.returncode,
            "output": result.stdout,
            "errors": errors,
            "warnings": warnings,
            "error_count": len(errors),
            "warning_count": len(warnings),
        }
