import os
import json
import subprocess
from pathlib import Path
from typing import Dict, List, Optional

class UE5ProjectManager:
    def __init__(self, ue5_path: str, projects_dir: str):
        self.ue5_path = Path(ue5_path)
        self.projects_dir = Path(projects_dir)
        self.unreal_build_tool = self.ue5_path / "Engine/Build/BatchFiles/Build.bat"
        self.editor_cmd = self.ue5_path / "Engine/Binaries/Win64/UE5Editor-Cmd.exe"

    def create_project(self, project_name: str, template: str = "Blank") -> Dict:
        """Create a new UE5 project from template"""
        project_path = self.projects_dir / project_name

        # Create project using UE5 commandlet
        cmd = [
            str(self.editor_cmd),
            "/Game",
            f"/Game={project_name}",
            f"/Project={project_path}",
            "/NoSplash",
            "/NullRHI",
        ]

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            return {
                "success": result.returncode == 0,
                "project_path": str(project_path),
                "output": result.stdout,
                "errors": result.stderr if result.stderr else None,
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "Project creation timed out"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def generate_project_files(self, project_path: str) -> Dict:
        """Generate Visual Studio project files"""
        project_file = Path(project_path) / f"{Path(project_path).name}.uproject"

        cmd = [
            str(self.ue5_path / "Engine/Binaries/DotNET/UnrealBuildTool/UnrealBuildTool.exe"),
            "-projectfiles",
            f"-project={project_file}",
            "-game",
            "-engine",
        ]

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
            return {
                "success": result.returncode == 0,
                "output": result.stdout,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def build_project(self, project_path: str, configuration: str = "Development") -> Dict:
        """Build the UE5 project"""
        project_name = Path(project_path).name

        cmd = [
            str(self.unreal_build_tool),
            project_name,
            "Win64",
            configuration,
            f"-Project={project_path}/{project_name}.uproject",
            "-WaitMutex",
            "-FromMsBuild",
        ]

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)

            # Parse errors from output
            errors = self._parse_build_errors(result.stdout + result.stderr)

            return {
                "success": result.returncode == 0 and len(errors) == 0,
                "output": result.stdout,
                "errors": errors,
                "warnings": self._parse_build_warnings(result.stdout),
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "Build timed out"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def cook_content(self, project_path: str, platform: str = "Windows") -> Dict:
        """Cook content for target platform"""
        project_name = Path(project_path).name

        cmd = [
            str(self.editor_cmd),
            f"{project_path}/{project_name}.uproject",
            "-run=cook",
            f"-targetplatform={platform}",
            "-fileserver",
            "-unattended",
            "-nullrhi",
        ]

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
            return {
                "success": result.returncode == 0,
                "output": result.stdout,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def package_project(self, project_path: str, platform: str = "Windows", output_dir: str = None) -> Dict:
        """Package project for distribution"""
        project_name = Path(project_path).name
        output = output_dir or f"{project_path}/Build/{platform}"

        cmd = [
            str(self.editor_cmd),
            f"{project_path}/{project_name}.uproject",
            "-run=Package",
            f"-targetplatform={platform}",
            f"-clientconfig=Shipping",
            f"-serverconfig=Shipping",
            f"-stagingdirectory={output}",
            "-pak",
            "-prereqs",
            "-distribution",
            "-nodebuginfo",
            "-unattended",
            "-nullrhi",
        ]

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=3600)
            return {
                "success": result.returncode == 0,
                "output_path": output,
                "output": result.stdout,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def run_play_in_editor(self, project_path: str, map_name: str = "MainLevel") -> Dict:
        """Launch Play In Editor session"""
        project_name = Path(project_path).name

        cmd = [
            str(self.editor_cmd),
            f"{project_path}/{project_name}.uproject",
            map_name,
            "-game",
            "-fullscreen",
            "-ResX=1920",
            "-ResY=1080",
        ]

        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            return {
                "success": True,
                "pid": process.pid,
                "message": "PIE session started",
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def execute_python_script(self, project_path: str, script_path: str) -> Dict:
        """Execute Python script within UE5"""
        project_name = Path(project_path).name

        cmd = [
            str(self.editor_cmd),
            f"{project_path}/{project_name}.uproject",
            "-ExecutePythonScript",
            f"{script_path}",
            "-unattended",
            "-nullrhi",
        ]

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            return {
                "success": result.returncode == 0,
                "output": result.stdout,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def _parse_build_errors(self, output: str) -> List[Dict]:
        """Parse build errors from UBT output"""
        errors = []
        for line in output.split('\n'):
            if 'error:' in line.lower() or 'error C' in line:
                errors.append({
                    "message": line.strip(),
                    "severity": "error",
                })
        return errors

    def _parse_build_warnings(self, output: str) -> List[str]:
        """Parse build warnings from UBT output"""
        warnings = []
        for line in output.split('\n'):
            if 'warning:' in line.lower():
                warnings.append(line.strip())
        return warnings
