import subprocess
import time
from pathlib import Path
from typing import Dict, List

class PlaytestRunner:
    def __init__(self, ue5_path: str):
        self.ue5_path = Path(ue5_path)
        self.editor = self.ue5_path / "Engine/Binaries/Win64/UE5Editor.exe"

    def run_playtest(self, project_path: str, map_name: str = "MainLevel", duration: int = 60) -> Dict:
        """Run automated playtest session"""
        project_name = Path(project_path).name

        # Launch game in standalone mode
        cmd = [
            str(self.editor),
            f"{project_path}/{project_name}.uproject",
            map_name,
            "-game",
            "-windowed",
            "-ResX=1280",
            "-ResY=720",
            "-log",
            f"-PlayTestDuration={duration}",
        ]

        try:
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )

            # Wait for specified duration
            time.sleep(duration)

            # Terminate process
            process.terminate()
            stdout, stderr = process.communicate(timeout=10)

            # Parse results
            results = self._parse_playtest_output(stdout + stderr)

            return {
                "success": True,
                "duration": duration,
                "results": results,
                "output": stdout,
            }

        except subprocess.TimeoutExpired:
            process.kill()
            return {"success": False, "error": "Playtest timed out"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def run_performance_test(self, project_path: str, map_name: str = "MainLevel", duration: int = 120) -> Dict:
        """Run performance benchmark"""
        project_name = Path(project_path).name

        cmd = [
            str(self.editor),
            f"{project_path}/{project_name}.uproject",
            map_name,
            "-game",
            "-windowed",
            "-ResX=1920",
            "-ResY=1080",
            "-log",
            "-StatFPS",
            "-StatMemory",
            "-StatGPU",
            "-StatSceneRendering",
            f"-PerfTestDuration={duration}",
        ]

        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            time.sleep(duration)
            process.terminate()
            stdout, stderr = process.communicate(timeout=10)

            return {
                "success": True,
                "duration": duration,
                "performance_data": self._parse_performance_data(stdout),
                "output": stdout,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def run_multiplayer_test(self, project_path: str, map_name: str = "MainLevel", num_clients: int = 2) -> Dict:
        """Run multiplayer session test"""
        project_name = Path(project_path).name

        # Start server
        server_cmd = [
            str(self.editor),
            f"{project_path}/{project_name}.uproject",
            map_name,
            "-server",
            "-log",
            "-nosteam",
        ]

        server_process = subprocess.Popen(server_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        time.sleep(5)  # Wait for server to start

        # Start clients
        clients = []
        for i in range(num_clients):
            client_cmd = [
                str(self.editor),
                f"{project_path}/{project_name}.uproject",
                "127.0.0.1",
                "-game",
                "-windowed",
                "-ResX=800",
                "-ResY=600",
                "-log",
                f"-ClientId={i}",
            ]
            client_process = subprocess.Popen(client_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            clients.append(client_process)
            time.sleep(2)

        # Run for test duration
        time.sleep(30)

        # Cleanup
        for client in clients:
            client.terminate()
        server_process.terminate()

        return {
            "success": True,
            "num_clients": num_clients,
            "message": f"Multiplayer test completed with {num_clients} clients",
        }

    def _parse_playtest_output(self, output: str) -> Dict:
        """Parse playtest output for issues"""
        issues = {
            "crashes": [],
            "errors": [],
            "warnings": [],
            "fps_drops": [],
            "stuck_areas": [],
        }

        for line in output.split('\n'):
            if 'crash' in line.lower():
                issues["crashes"].append(line.strip())
            elif 'error' in line.lower():
                issues["errors"].append(line.strip())
            elif 'warning' in line.lower():
                issues["warnings"].append(line.strip())
            elif 'fps' in line.lower() and any(c.isdigit() for c in line):
                try:
                    fps = float([s for s in line.split() if s.replace('.', '').isdigit()][0])
                    if fps < 30:
                        issues["fps_drops"].append(f"Low FPS: {fps}")
                except:
                    pass

        return issues

    def _parse_performance_data(self, output: str) -> Dict:
        """Extract performance metrics"""
        fps_values = []
        memory_values = []

        for line in output.split('\n'):
            if 'FPS' in line:
                try:
                    fps = float([s for s in line.split() if s.replace('.', '').isdigit()][0])
                    fps_values.append(fps)
                except:
                    pass
            elif 'Memory' in line:
                try:
                    mem = float([s for s in line.split() if s.replace('.', '').isdigit()][0])
                    memory_values.append(mem)
                except:
                    pass

        return {
            "avg_fps": sum(fps_values) / len(fps_values) if fps_values else 0,
            "min_fps": min(fps_values) if fps_values else 0,
            "max_fps": max(fps_values) if fps_values else 0,
            "avg_memory": sum(memory_values) / len(memory_values) if memory_values else 0,
            "peak_memory": max(memory_values) if memory_values else 0,
        }
