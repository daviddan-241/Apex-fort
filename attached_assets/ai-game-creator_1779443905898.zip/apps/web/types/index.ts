export interface GameProject {
  id: string;
  name: string;
  description: string;
  status: 'idle' | 'planning' | 'generating' | 'building' | 'testing' | 'packaging' | 'completed' | 'error';
  progress: number;
  createdAt: string;
  updatedAt: string;
  ue5Path: string;
  buildPath: string;
  genre: string;
  platform: string[];
  assets: GameAsset[];
  agents: AgentStatus[];
  logs: BuildLog[];
  errors: BuildError[];
  testResults: TestResult[];
}

export interface GameAsset {
  id: string;
  name: string;
  type: 'mesh' | 'texture' | 'material' | 'blueprint' | 'cpp' | 'sound' | 'animation' | 'ui';
  status: 'pending' | 'generating' | 'completed' | 'error';
  path: string;
  size: number;
  generatedBy: string;
  createdAt: string;
}

export interface AgentStatus {
  id: string;
  name: string;
  role: string;
  status: 'idle' | 'working' | 'completed' | 'error';
  currentTask: string;
  progress: number;
  lastActivity: string;
  icon: string;
  color: string;
}

export interface BuildLog {
  id: string;
  timestamp: string;
  level: 'info' | 'warn' | 'error' | 'success';
  message: string;
  agent: string;
  metadata?: Record<string, any>;
}

export interface BuildError {
  id: string;
  timestamp: string;
  file: string;
  line: number;
  message: string;
  severity: 'warning' | 'error' | 'critical';
  fixed: boolean;
  fixAttempt: number;
}

export interface TestResult {
  id: string;
  timestamp: string;
  type: 'unit' | 'integration' | 'gameplay' | 'performance';
  passed: boolean;
  duration: number;
  details: string;
  screenshots: string[];
  fps: number;
  memoryUsage: number;
}

export interface GamePrompt {
  prompt: string;
  genre?: string;
  platform?: string[];
  multiplayer?: boolean;
  style?: string;
  complexity?: 'simple' | 'medium' | 'complex';
}

export interface User {
  id: string;
  email: string;
  name: string;
  avatar: string;
  role: 'user' | 'admin';
  credits: number;
  projects: string[];
  settings: UserSettings;
}

export interface UserSettings {
  theme: 'dark' | 'light';
  notifications: boolean;
  autoSave: boolean;
  aiModel: 'openai' | 'claude' | 'local';
  ue5Path: string;
  outputPath: string;
}

export interface Task {
  id: string;
  projectId: string;
  agentId: string;
  type: string;
  description: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  priority: number;
  dependencies: string[];
  result?: any;
  error?: string;
  createdAt: string;
  completedAt?: string;
}
