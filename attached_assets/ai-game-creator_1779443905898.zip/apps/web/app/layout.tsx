import type { Metadata } from 'next';
import { Inter, JetBrains_Mono } from 'next/font/google';
import './globals.css';
import { GameProvider } from '@/components/providers/GameProvider';
import { SocketProvider } from '@/components/providers/SocketProvider';
import { Toaster } from '@/components/ui/Toaster';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });
const jetbrains = JetBrains_Mono({ subsets: ['latin'], variable: '--font-mono' });

export const metadata: Metadata = {
  title: 'AI Game Creator | Autonomous UE5 Game Studio',
  description: 'Generate complete playable games from a single text prompt using AI',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body className={`${inter.variable} ${jetbrains.variable} font-sans`}>
        <GameProvider>
          <SocketProvider>
            {children}
            <Toaster />
          </SocketProvider>
        </GameProvider>
      </body>
    </html>
  );
}
