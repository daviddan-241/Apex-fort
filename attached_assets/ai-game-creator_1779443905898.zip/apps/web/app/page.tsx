'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Sparkles, Zap, Shield, Globe, Cpu, Gamepad2, 
  ChevronRight, Star, Users, Clock, ArrowRight 
} from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import Link from 'next/link';

const features = [
  {
    icon: Sparkles,
    title: 'AI-Powered Generation',
    desc: 'Describe your dream game and watch AI build it from scratch using Unreal Engine 5.',
    color: 'text-neon-blue',
    bg: 'bg-neon-blue/10',
  },
  {
    icon: Cpu,
    title: '10+ Specialized Agents',
    desc: 'Level designers, coders, artists, and QA testers working together autonomously.',
    color: 'text-neon-gold',
    bg: 'bg-neon-gold/10',
  },
  {
    icon: Zap,
    title: 'Auto Debugging',
    desc: 'AI detects errors, reads logs, fixes broken blueprints, and retries builds automatically.',
    color: 'text-green-400',
    bg: 'bg-green-400/10',
  },
  {
    icon: Gamepad2,
    title: 'Multiplayer Ready',
    desc: 'LAN, dedicated servers, EOS, and Steam integration built-in from day one.',
    color: 'text-purple-400',
    bg: 'bg-purple-400/10',
  },
  {
    icon: Shield,
    title: 'Secure & Local',
    desc: 'Run entirely offline with local AI models. Your code, your data, your control.',
    color: 'text-neon-red',
    bg: 'bg-neon-red/10',
  },
  {
    icon: Globe,
    title: 'Cross-Platform',
    desc: 'Export to Windows EXE, Android APK, and Linux builds with one click.',
    color: 'text-cyan-400',
    bg: 'bg-cyan-400/10',
  },
];

const stats = [
  { value: '10+', label: 'AI Agents' },
  { value: '<5min', label: 'Avg Gen Time' },
  { value: '100%', label: 'UE5 Native' },
  { value: '3', label: 'Platforms' },
];

export default function LandingPage() {
  const [prompt, setPrompt] = useState('');
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div className="min-h-screen bg-dark-bg overflow-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-neon-blue/5 rounded-full blur-[100px] animate-pulse" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-neon-gold/5 rounded-full blur-[100px] animate-pulse delay-1000" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-purple-500/3 rounded-full blur-[150px]" />
      </div>

      {/* Navigation */}
      <nav className="relative z-10 border-b border-white/5">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-neon-blue to-blue-600 flex items-center justify-center">
              <Gamepad2 className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-white">
              AI <span className="neon-text">Game Creator</span>
            </span>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/docs" className="text-gray-400 hover:text-white transition-colors">Docs</Link>
            <Link href="/pricing" className="text-gray-400 hover:text-white transition-colors">Pricing</Link>
            <Link href="/dashboard">
              <Button variant="primary" icon={<ArrowRight className="w-4 h-4" />}>
                Launch Studio
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative z-10 pt-20 pb-32">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-neon-blue/10 border border-neon-blue/30 text-neon-blue text-sm mb-8">
              <Sparkles className="w-4 h-4" />
              <span>Powered by Unreal Engine 5 + Multi-Agent AI</span>
            </div>

            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
              Create Games with
              <br />
              <span className="neon-text">Artificial Intelligence</span>
            </h1>

            <p className="text-xl text-gray-400 max-w-2xl mx-auto mb-12">
              Describe your game idea in plain English. Our AI team of 10+ specialized agents
              will design, code, test, and package a complete playable Unreal Engine 5 game.
            </p>

            {/* Prompt Input */}
            <motion.div
              className="max-w-3xl mx-auto relative"
              onHoverStart={() => setIsHovered(true)}
              onHoverEnd={() => setIsHovered(false)}
            >
              <div className={\`glass-card p-2 transition-all duration-300 \${isHovered ? 'neon-border scale-[1.02]' : ''}\`}>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="Describe your game... e.g., 'Create a realistic multiplayer survival shooter with zombies'"
                    className="flex-1 bg-transparent text-white placeholder:text-gray-600 px-4 py-3 outline-none text-lg"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && prompt) {
                        window.location.href = \`/dashboard?prompt=\${encodeURIComponent(prompt)}\`;
                      }
                    }}
                  />
                  <Link href={\`/dashboard?prompt=\${encodeURIComponent(prompt)}\`}>
                    <Button 
                      variant="primary" 
                      size="lg" 
                      isLoading={false}
                      icon={<Sparkles className="w-5 h-5" />}
                      className="h-full px-8"
                      disabled={!prompt}
                    >
                      Create Game
                    </Button>
                  </Link>
                </div>
              </div>

              {/* Quick Prompts */}
              <div className="flex gap-2 mt-4 justify-center flex-wrap">
                {[
                  'Battle Royale shooter',
                  'Open world RPG',
                  'Horror survival game',
                  'Racing simulator',
                  'Tower defense',
                ].map((quick) => (
                  <button
                    key={quick}
                    onClick={() => setPrompt(\`Create a \${quick}\`)}
                    className="px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-sm text-gray-400 hover:text-white hover:bg-white/10 transition-all"
                  >
                    {quick}
                  </button>
                ))}
              </div>
            </motion.div>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-3xl mx-auto mt-20"
          >
            {stats.map((stat, i) => (
              <div key={i} className="text-center">
                <div className="text-3xl font-bold neon-text">{stat.value}</div>
                <div className="text-sm text-gray-500 mt-1">{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="relative z-10 py-20 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-white mb-4">
              Everything You Need to <span className="gold-text">Build Games</span>
            </h2>
            <p className="text-gray-400 max-w-xl mx-auto">
              A complete autonomous game development pipeline powered by specialized AI agents.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Card hover className="h-full">
                  <div className={\`w-12 h-12 rounded-xl \${feature.bg} flex items-center justify-center mb-4\`}>
                    <feature.icon className={\`w-6 h-6 \${feature.color}\`} />
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">{feature.title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">{feature.desc}</p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="relative z-10 py-20 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-white mb-4">
              How It <span className="neon-text">Works</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              { step: '01', title: 'Describe', desc: 'Type your game idea in natural language' },
              { step: '02', title: 'Plan', desc: 'AI Director breaks it into tasks for specialized agents' },
              { step: '03', title: 'Build', desc: 'Agents generate code, assets, and blueprints in UE5' },
              { step: '04', title: 'Play', desc: 'Test, optimize, and export your playable game' },
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                className="relative"
              >
                <div className="text-6xl font-bold text-white/5 mb-4">{item.step}</div>
                <h3 className="text-xl font-semibold text-white mb-2">{item.title}</h3>
                <p className="text-gray-400">{item.desc}</p>
                {i < 3 && (
                  <ChevronRight className="hidden md:block absolute top-8 -right-4 w-6 h-6 text-gray-700" />
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative z-10 py-20 border-t border-white/5">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <Card glow className="p-12">
            <h2 className="text-3xl font-bold text-white mb-4">
              Ready to Create Your First Game?
            </h2>
            <p className="text-gray-400 mb-8 max-w-xl mx-auto">
              Join thousands of developers using AI to build games faster than ever before.
              No coding required.
            </p>
            <Link href="/dashboard">
              <Button variant="primary" size="lg" icon={<Sparkles className="w-5 h-5" />}>
                Start Creating Now
              </Button>
            </Link>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-white/5 py-12">
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Gamepad2 className="w-5 h-5 text-neon-blue" />
            <span className="text-white font-semibold">AI Game Creator</span>
          </div>
          <p className="text-gray-600 text-sm">
            © 2024 AI Game Creator. Built with Unreal Engine 5.
          </p>
        </div>
      </footer>
    </div>
  );
}
