'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  LayoutDashboard, Plus, Search, Filter, MoreVertical, 
  Play, Pause, RotateCcw, Trash2, Download, Settings,
  Clock, CheckCircle, AlertCircle, Loader2, Gamepad2
} from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Progress } from '@/components/ui/Progress';
import { useGameStore } from '@/lib/store';
import { getStatusColor, getStatusBg, formatBytes, formatDuration } from '@/lib/utils';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';

const statusIcons = {
  idle: Clock,
  planning: Loader2,
  generating: Loader2,
  building: Loader2,
  testing: Loader2,
  packaging: Loader2,
  completed: CheckCircle,
  error: AlertCircle,
};

export default function DashboardPage() {
  const { projects, setCurrentProject, createGame } = useGameStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const searchParams = useSearchParams();
  const initialPrompt = searchParams.get('prompt') || '';

  useEffect(() => {
    if (initialPrompt) {
      setShowCreateModal(true);
    }
  }, [initialPrompt]);

  const filteredProjects = projects.filter((project) => {
    const matchesSearch = project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         project.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterStatus === 'all' || project.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="min-h-screen bg-dark-bg">
      {/* Header */}
      <header className="border-b border-white/5 bg-dark-bg/80 backdrop-blur-xl sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/" className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-neon-blue to-blue-600 flex items-center justify-center">
                <Gamepad2 className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold text-white hidden md:block">
                AI <span className="neon-text">Game Creator</span>
              </span>
            </Link>
            <div className="h-6 w-px bg-white/10 hidden md:block" />
            <nav className="hidden md:flex items-center gap-1">
              <Link href="/dashboard" className="px-3 py-2 rounded-lg bg-white/5 text-white text-sm font-medium">
                Dashboard
              </Link>
              <Link href="/studio" className="px-3 py-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 text-sm transition-all">
                Studio
              </Link>
              <Link href="/agents" className="px-3 py-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 text-sm transition-all">
                Agents
              </Link>
            </nav>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" icon={<Settings className="w-4 h-4" />}>
              Settings
            </Button>
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-neon-blue to-purple-500" />
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total Projects', value: projects.length, icon: LayoutDashboard, color: 'text-neon-blue' },
            { label: 'In Progress', value: projects.filter(p => p.status === 'generating' || p.status === 'building').length, icon: Loader2, color: 'text-neon-gold' },
            { label: 'Completed', value: projects.filter(p => p.status === 'completed').length, icon: CheckCircle, color: 'text-green-400' },
            { label: 'Errors', value: projects.filter(p => p.status === 'error').length, icon: AlertCircle, color: 'text-neon-red' },
          ].map((stat, i) => (
            <Card key={i} className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-500 text-sm">{stat.label}</p>
                  <p className="text-2xl font-bold text-white mt-1">{stat.value}</p>
                </div>
                <stat.icon className={`w-8 h-8 ${stat.color} opacity-50`} />
              </div>
            </Card>
          ))}
        </div>

        {/* Toolbar */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-4 flex-1 w-full md:w-auto">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="text"
                placeholder="Search projects..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-lg pl-10 pr-4 py-2 text-sm text-white placeholder:text-gray-600 outline-none focus:border-neon-blue/50 transition-colors"
              />
            </div>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-neon-blue/50"
            >
              <option value="all">All Status</option>
              <option value="idle">Idle</option>
              <option value="generating">Generating</option>
              <option value="building">Building</option>
              <option value="completed">Completed</option>
              <option value="error">Error</option>
            </select>
          </div>
          <Button 
            variant="primary" 
            icon={<Plus className="w-4 h-4" />}
            onClick={() => setShowCreateModal(true)}
          >
            New Game
          </Button>
        </div>

        {/* Projects Grid */}
        {filteredProjects.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence>
              {filteredProjects.map((project) => {
                const StatusIcon = statusIcons[project.status as keyof typeof statusIcons] || Clock;
                return (
                  <motion.div
                    key={project.id}
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                  >
                    <Card hover className="p-5 cursor-pointer group" onClick={() => setCurrentProject(project)}>
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${getStatusBg(project.status)}`}>
                            <StatusIcon className={`w-5 h-5 ${getStatusColor(project.status)} ${project.status === 'generating' || project.status === 'building' ? 'animate-spin' : ''}`} />
                          </div>
                          <div>
                            <h3 className="font-semibold text-white group-hover:text-neon-blue transition-colors">{project.name}</h3>
                            <p className="text-xs text-gray-500">{project.genre}</p>
                          </div>
                        </div>
                        <Badge variant={project.status === 'completed' ? 'success' : project.status === 'error' ? 'error' : 'info'}>
                          {project.status}
                        </Badge>
                      </div>

                      <p className="text-sm text-gray-400 mb-4 line-clamp-2">{project.description}</p>

                      {(project.status === 'generating' || project.status === 'building') && (
                        <div className="mb-4">
                          <Progress value={project.progress} label="Progress" />
                        </div>
                      )}

                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <div className="flex items-center gap-4">
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {new Date(project.createdAt).toLocaleDateString()}
                          </span>
                          <span>{project.platform?.join(', ')}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <button className="p-1.5 hover:bg-white/10 rounded-lg transition-colors" title="Play">
                            <Play className="w-4 h-4 text-green-400" />
                          </button>
                          <button className="p-1.5 hover:bg-white/10 rounded-lg transition-colors" title="Restart">
                            <RotateCcw className="w-4 h-4 text-neon-blue" />
                          </button>
                          <button className="p-1.5 hover:bg-white/10 rounded-lg transition-colors" title="Delete">
                            <Trash2 className="w-4 h-4 text-neon-red" />
                          </button>
                        </div>
                      </div>
                    </Card>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        ) : (
          <Card className="p-12 text-center">
            <Gamepad2 className="w-16 h-16 text-gray-700 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">No projects yet</h3>
            <p className="text-gray-500 mb-6">Create your first AI-generated game to get started.</p>
            <Button variant="primary" icon={<Plus className="w-4 h-4" />} onClick={() => setShowCreateModal(true)}>
              Create New Game
            </Button>
          </Card>
        )}
      </main>

      {/* Create Game Modal */}
      <CreateGameModal 
        isOpen={showCreateModal} 
        onClose={() => setShowCreateModal(false)}
        initialPrompt={initialPrompt}
      />
    </div>
  );
}

function CreateGameModal({ isOpen, onClose, initialPrompt }: { isOpen: boolean; onClose: () => void; initialPrompt: string }) {
  const [prompt, setPrompt] = useState(initialPrompt);
  const [genre, setGenre] = useState('shooter');
  const [platform, setPlatform] = useState<string[]>(['windows']);
  const [multiplayer, setMultiplayer] = useState(false);
  const [complexity, setComplexity] = useState('medium');
  const [isCreating, setIsCreating] = useState(false);
  const { createGame } = useGameStore();

  const handleCreate = async () => {
    if (!prompt.trim()) return;
    setIsCreating(true);
    try {
      await createGame({
        prompt,
        genre,
        platform,
        multiplayer,
        complexity: complexity as any,
      });
      onClose();
    } catch (error) {
      console.error('Failed to create game:', error);
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="glass-card neon-border w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 border-b border-white/10">
              <h2 className="text-xl font-bold text-white">Create New Game</h2>
              <p className="text-gray-400 text-sm mt-1">Describe your game and our AI agents will build it.</p>
            </div>

            <div className="p-6 space-y-6">
              {/* Prompt */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Game Description</label>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Describe your game idea in detail..."
                  rows={4}
                  className="w-full bg-white/5 border border-white/10 rounded-lg p-3 text-white placeholder:text-gray-600 outline-none focus:border-neon-blue/50 transition-colors resize-none"
                />
                <div className="flex gap-2 mt-2 flex-wrap">
                  {['Battle Royale', 'Survival Horror', 'Open World RPG', 'Racing', 'Tower Defense'].map((s) => (
                    <button
                      key={s}
                      onClick={() => setPrompt(`Create a ${s.toLowerCase()} game`)}
                      className="px-2 py-1 rounded-md bg-white/5 text-xs text-gray-400 hover:text-white hover:bg-white/10 transition-all"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              {/* Genre */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Genre</label>
                <div className="grid grid-cols-3 gap-2">
                  {['shooter', 'rpg', 'survival', 'racing', 'strategy', 'puzzle'].map((g) => (
                    <button
                      key={g}
                      onClick={() => setGenre(g)}
                      className={`px-3 py-2 rounded-lg text-sm capitalize transition-all border ${
                        genre === g 
                          ? 'bg-neon-blue/20 border-neon-blue/50 text-neon-blue' 
                          : 'bg-white/5 border-white/10 text-gray-400 hover:text-white'
                      }`}
                    >
                      {g}
                    </button>
                  ))}
                </div>
              </div>

              {/* Platform */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Target Platforms</label>
                <div className="flex gap-2">
                  {['windows', 'android', 'linux'].map((p) => (
                    <button
                      key={p}
                      onClick={() => {
                        setPlatform(prev => 
                          prev.includes(p) ? prev.filter(x => x !== p) : [...prev, p]
                        );
                      }}
                      className={`px-3 py-2 rounded-lg text-sm capitalize transition-all border ${
                        platform.includes(p)
                          ? 'bg-neon-blue/20 border-neon-blue/50 text-neon-blue'
                          : 'bg-white/5 border-white/10 text-gray-400 hover:text-white'
                      }`}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>

              {/* Complexity */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Complexity</label>
                <div className="flex gap-2">
                  {['simple', 'medium', 'complex'].map((c) => (
                    <button
                      key={c}
                      onClick={() => setComplexity(c)}
                      className={`flex-1 px-3 py-2 rounded-lg text-sm capitalize transition-all border ${
                        complexity === c
                          ? 'bg-neon-gold/20 border-neon-gold/50 text-neon-gold'
                          : 'bg-white/5 border-white/10 text-gray-400 hover:text-white'
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              {/* Multiplayer */}
              <div className="flex items-center justify-between">
                <div>
                  <label className="block text-sm font-medium text-gray-300">Multiplayer</label>
                  <p className="text-xs text-gray-500">Enable LAN and online multiplayer support</p>
                </div>
                <button
                  onClick={() => setMultiplayer(!multiplayer)}
                  className={`w-12 h-6 rounded-full transition-all relative ${
                    multiplayer ? 'bg-neon-blue' : 'bg-white/10'
                  }`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-all ${
                    multiplayer ? 'left-6' : 'left-0.5'
                  }`} />
                </button>
              </div>
            </div>

            <div className="p-6 border-t border-white/10 flex justify-end gap-3">
              <Button variant="ghost" onClick={onClose}>Cancel</Button>
              <Button 
                variant="primary" 
                isLoading={isCreating}
                disabled={!prompt.trim() || platform.length === 0}
                onClick={handleCreate}
              >
                Create Game
              </Button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
