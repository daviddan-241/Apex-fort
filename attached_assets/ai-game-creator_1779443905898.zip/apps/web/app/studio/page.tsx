'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Play, Pause, Square, RotateCcw, Save, Download, 
  Code, Box, Image, Music, Settings, Eye, Bug,
  ChevronLeft, ChevronRight, Maximize2, Terminal as TerminalIcon,
  Cpu, Users, Zap, FileCode, Layers, Map, Volume2, Monitor
} from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Progress } from '@/components/ui/Progress';
import { Terminal } from '@/components/ui/Terminal';
import { useGameStore } from '@/lib/store';
import { getStatusColor, getStatusBg } from '@/lib/utils';
import Link from 'next/link';

const tabs = [
  { id: 'overview', label: 'Overview', icon: Monitor },
  { id: 'agents', label: 'Agents', icon: Cpu },
  { id: 'assets', label: 'Assets', icon: Box },
  { id: 'code', label: 'Code', icon: FileCode },
  { id: 'blueprints', label: 'Blueprints', icon: Layers },
  { id: 'map', label: 'Level', icon: Map },
  { id: 'audio', label: 'Audio', icon: Volume2 },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export default function StudioPage() {
  const { currentProject, setCurrentProject, agents, logs, terminalOpen, setTerminalOpen } = useGameStore();
  const [activeTab, setActiveTab] = useState('overview');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  // If no project selected, redirect or show placeholder
  if (!currentProject) {
    return (
      <div className="min-h-screen bg-dark-bg flex items-center justify-center">
        <Card className="p-12 text-center max-w-md">
          <Monitor className="w-16 h-16 text-gray-700 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-white mb-2">No Project Selected</h2>
          <p className="text-gray-500 mb-6">Select a project from the dashboard to start editing.</p>
          <Link href="/dashboard">
            <Button variant="primary">Go to Dashboard</Button>
          </Link>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-bg flex">
      {/* Sidebar */}
      <motion.aside
        className="border-r border-white/5 bg-dark-card/50 backdrop-blur-xl flex flex-col"
        animate={{ width: sidebarCollapsed ? 64 : 280 }}
      >
        {/* Project Header */}
        <div className="p-4 border-b border-white/5">
          <div className="flex items-center gap-3">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm" className="p-1">
                <ChevronLeft className="w-5 h-5" />
              </Button>
            </Link>
            {!sidebarCollapsed && (
              <div className="flex-1 min-w-0">
                <h2 className="font-semibold text-white truncate">{currentProject.name}</h2>
                <p className="text-xs text-gray-500 truncate">{currentProject.genre}</p>
              </div>
            )}
          </div>
          {!sidebarCollapsed && (
            <div className="mt-3">
              <Progress value={currentProject.progress} size="sm" />
            </div>
          )}
        </div>

        {/* Tabs */}
        <nav className="flex-1 py-2">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm transition-all ${
                activeTab === tab.id
                  ? 'bg-neon-blue/10 text-neon-blue border-r-2 border-neon-blue'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <tab.icon className="w-5 h-5 shrink-0" />
              {!sidebarCollapsed && <span>{tab.label}</span>}
            </button>
          ))}
        </nav>

        {/* Collapse Toggle */}
        <div className="p-4 border-t border-white/5">
          <Button
            variant="ghost"
            size="sm"
            className="w-full justify-center"
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
          >
            {sidebarCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </Button>
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Toolbar */}
        <header className="border-b border-white/5 px-6 py-3 flex items-center justify-between bg-dark-bg/80 backdrop-blur-xl">
          <div className="flex items-center gap-2">
            <Badge variant={currentProject.status === 'completed' ? 'success' : 'info'}>
              {currentProject.status}
            </Badge>
            <span className="text-sm text-gray-500">{currentProject.platform?.join(', ')}</span>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" icon={<TerminalIcon className="w-4 h-4" />} onClick={() => setTerminalOpen(!terminalOpen)}>
              Terminal
            </Button>
            <Button variant="ghost" size="sm" icon={<Bug className="w-4 h-4" />}>
              Debug
            </Button>
            <Button variant="ghost" size="sm" icon={<Save className="w-4 h-4" />}>
              Save
            </Button>
            <div className="w-px h-6 bg-white/10" />
            <Button variant="primary" size="sm" icon={<Play className="w-4 h-4" />}>
              Play
            </Button>
            <Button variant="gold" size="sm" icon={<Download className="w-4 h-4" />}>
              Export
            </Button>
          </div>
        </header>

        {/* Tab Content */}
        <div className="flex-1 overflow-auto p-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === 'overview' && <OverviewTab project={currentProject} agents={agents} />}
              {activeTab === 'agents' && <AgentsTab agents={agents} />}
              {activeTab === 'assets' && <AssetsTab project={currentProject} />}
              {activeTab === 'code' && <CodeTab project={currentProject} />}
              {activeTab === 'blueprints' && <BlueprintsTab project={currentProject} />}
              {activeTab === 'map' && <MapTab project={currentProject} />}
              {activeTab === 'audio' && <AudioTab project={currentProject} />}
              {activeTab === 'settings' && <SettingsTab project={currentProject} />}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Terminal */}
      <Terminal />
    </div>
  );
}

// Tab Components
function OverviewTab({ project, agents }: { project: any; agents: any[] }) {
  return (
    <div className="space-y-6">
      {/* Project Info */}
      <div className="grid md:grid-cols-3 gap-6">
        <Card className="md:col-span-2 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Project Overview</h3>
          <div className="space-y-4">
            <div>
              <label className="text-xs text-gray-500 uppercase tracking-wider">Description</label>
              <p className="text-gray-300 mt-1">{project.description}</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-gray-500 uppercase tracking-wider">Genre</label>
                <p className="text-white mt-1 capitalize">{project.genre}</p>
              </div>
              <div>
                <label className="text-xs text-gray-500 uppercase tracking-wider">Platforms</label>
                <p className="text-white mt-1">{project.platform?.join(', ')}</p>
              </div>
              <div>
                <label className="text-xs text-gray-500 uppercase tracking-wider">Created</label>
                <p className="text-white mt-1">{new Date(project.createdAt).toLocaleString()}</p>
              </div>
              <div>
                <label className="text-xs text-gray-500 uppercase tracking-wider">UE5 Path</label>
                <p className="text-neon-blue mt-1 font-mono text-sm truncate">{project.ue5Path}</p>
              </div>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Build Status</h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-400">Overall Progress</span>
                <span className="text-neon-blue font-mono">{project.progress}%</span>
              </div>
              <Progress value={project.progress} />
            </div>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="bg-white/5 rounded-lg p-3">
                <p className="text-gray-500">Assets</p>
                <p className="text-white font-semibold">{project.assets?.length || 0}</p>
              </div>
              <div className="bg-white/5 rounded-lg p-3">
                <p className="text-gray-500">Errors</p>
                <p className="text-neon-red font-semibold">{project.errors?.length || 0}</p>
              </div>
              <div className="bg-white/5 rounded-lg p-3">
                <p className="text-gray-500">Tests</p>
                <p className="text-green-400 font-semibold">{project.testResults?.length || 0}</p>
              </div>
              <div className="bg-white/5 rounded-lg p-3">
                <p className="text-gray-500">Agents</p>
                <p className="text-neon-blue font-semibold">{agents.length}</p>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Active Agents */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Active Agents</h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {agents.map((agent) => (
            <div key={agent.id} className={`p-4 rounded-lg border ${getStatusBg(agent.status)}`}>
              <div className="flex items-center gap-3 mb-2">
                <div className={`w-2 h-2 rounded-full ${
                  agent.status === 'working' ? 'bg-neon-blue animate-pulse' :
                  agent.status === 'completed' ? 'bg-green-400' :
                  agent.status === 'error' ? 'bg-neon-red' : 'bg-gray-500'
                }`} />
                <span className="font-medium text-white">{agent.name}</span>
              </div>
              <p className="text-xs text-gray-400 mb-2">{agent.role}</p>
              <p className="text-sm text-gray-300">{agent.currentTask || 'Idle'}</p>
              {agent.status === 'working' && (
                <Progress value={agent.progress} size="sm" className="mt-2" />
              )}
            </div>
          ))}
        </div>
      </Card>

      {/* Recent Logs */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Recent Activity</h3>
        <div className="space-y-2 max-h-64 overflow-y-auto">
          {project.logs?.slice(0, 20).map((log: any) => (
            <div key={log.id} className="flex items-center gap-3 text-sm py-1">
              <span className="text-gray-600 text-xs font-mono">{new Date(log.timestamp).toLocaleTimeString()}</span>
              <Badge variant={log.level === 'error' ? 'error' : log.level === 'warn' ? 'warning' : 'default'} size="sm">
                {log.level}
              </Badge>
              <span className="text-gray-500 text-xs">[{log.agent}]</span>
              <span className="text-gray-300">{log.message}</span>
            </div>
          )) || (
            <p className="text-gray-600 text-center py-4">No activity yet</p>
          )}
        </div>
      </Card>
    </div>
  );
}

function AgentsTab({ agents }: { agents: any[] }) {
  const agentTypes = [
    { id: 'director', name: 'AI Director', role: 'Orchestrator', icon: Cpu, color: 'text-purple-400' },
    { id: 'level', name: 'Level Designer', role: 'Level Design', icon: Map, color: 'text-green-400' },
    { id: 'blueprint', name: 'Blueprint Agent', role: 'Blueprint Generation', icon: Layers, color: 'text-neon-blue' },
    { id: 'cpp', name: 'C++ Coder', role: 'C++ Programming', icon: FileCode, color: 'text-orange-400' },
    { id: 'asset', name: 'Asset Generator', role: '3D/2D Assets', icon: Box, color: 'text-pink-400' },
    { id: 'ui', name: 'UI Designer', role: 'Interface Design', icon: Monitor, color: 'text-cyan-400' },
    { id: 'sound', name: 'Audio Engineer', role: 'Sound & Music', icon: Volume2, color: 'text-yellow-400' },
    { id: 'network', name: 'Network Engineer', role: 'Multiplayer', icon: Users, color: 'text-indigo-400' },
    { id: 'qa', name: 'QA Tester', role: 'Testing', icon: Bug, color: 'text-red-400' },
    { id: 'optimizer', name: 'Optimizer', role: 'Performance', icon: Zap, color: 'text-neon-gold' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-white">AI Agents</h2>
        <Button variant="primary" size="sm" icon={<RotateCcw className="w-4 h-4" />}>
          Restart All
        </Button>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {agentTypes.map((agentType) => {
          const agent = agents.find(a => a.id === agentType.id);
          return (
            <Card key={agentType.id} className="p-5">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center`}>
                    <agentType.icon className={`w-6 h-6 ${agentType.color}`} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white">{agentType.name}</h3>
                    <p className="text-sm text-gray-500">{agentType.role}</p>
                  </div>
                </div>
                <div className={`w-3 h-3 rounded-full ${
                  agent?.status === 'working' ? 'bg-neon-blue animate-pulse' :
                  agent?.status === 'completed' ? 'bg-green-400' :
                  agent?.status === 'error' ? 'bg-neon-red' : 'bg-gray-500'
                }`} />
              </div>

              {agent && (
                <div className="mt-4 pt-4 border-t border-white/5">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Current Task:</span>
                    <span className="text-gray-300">{agent.currentTask || 'Idle'}</span>
                  </div>
                  {agent.status === 'working' && (
                    <Progress value={agent.progress} className="mt-2" size="sm" />
                  )}
                  <div className="flex items-center justify-between text-xs text-gray-500 mt-2">
                    <span>Last active: {new Date(agent.lastActivity).toLocaleTimeString()}</span>
                    <Badge variant={agent.status === 'completed' ? 'success' : agent.status === 'error' ? 'error' : 'info'} size="sm">
                      {agent.status}
                    </Badge>
                  </div>
                </div>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
}

function AssetsTab({ project }: { project: any }) {
  const assetTypes = [
    { type: 'mesh', label: '3D Models', icon: Box, color: 'text-blue-400' },
    { type: 'texture', label: 'Textures', icon: Image, color: 'text-purple-400' },
    { type: 'material', label: 'Materials', icon: Layers, color: 'text-pink-400' },
    { type: 'blueprint', label: 'Blueprints', icon: FileCode, color: 'text-neon-blue' },
    { type: 'cpp', label: 'C++ Classes', icon: Code, color: 'text-orange-400' },
    { type: 'sound', label: 'Audio', icon: Volume2, color: 'text-yellow-400' },
    { type: 'animation', label: 'Animations', icon: Zap, color: 'text-green-400' },
    { type: 'ui', label: 'UI Widgets', icon: Monitor, color: 'text-cyan-400' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-white">Assets</h2>
        <div className="flex gap-2">
          <Button variant="secondary" size="sm" icon={<Box className="w-4 h-4" />}>
            Import
          </Button>
          <Button variant="primary" size="sm" icon={<Zap className="w-4 h-4" />}>
            Generate All
          </Button>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        {assetTypes.map((assetType) => {
          const assets = project.assets?.filter((a: any) => a.type === assetType.type) || [];
          const completed = assets.filter((a: any) => a.status === 'completed').length;

          return (
            <Card key={assetType.type} hover className="p-5 cursor-pointer">
              <div className="flex items-center gap-3 mb-3">
                <assetType.icon className={`w-6 h-6 ${assetType.color}`} />
                <h3 className="font-medium text-white">{assetType.label}</h3>
              </div>
              <div className="flex items-end justify-between">
                <div>
                  <p className="text-2xl font-bold text-white">{assets.length}</p>
                  <p className="text-xs text-gray-500">{completed} completed</p>
                </div>
                <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center">
                  <span className="text-sm text-gray-400">{Math.round((completed / Math.max(assets.length, 1)) * 100)}%</span>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Asset List */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold text-white mb-4">All Assets</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-gray-500 border-b border-white/5">
                <th className="pb-3 font-medium">Name</th>
                <th className="pb-3 font-medium">Type</th>
                <th className="pb-3 font-medium">Status</th>
                <th className="pb-3 font-medium">Generated By</th>
                <th className="pb-3 font-medium">Size</th>
                <th className="pb-3 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {project.assets?.map((asset: any) => (
                <tr key={asset.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                  <td className="py-3 text-white">{asset.name}</td>
                  <td className="py-3">
                    <Badge variant="default" size="sm">{asset.type}</Badge>
                  </td>
                  <td className="py-3">
                    <Badge variant={asset.status === 'completed' ? 'success' : asset.status === 'error' ? 'error' : 'warning'} size="sm">
                      {asset.status}
                    </Badge>
                  </td>
                  <td className="py-3 text-gray-400">{asset.generatedBy}</td>
                  <td className="py-3 text-gray-400 font-mono">{asset.size} KB</td>
                  <td className="py-3">
                    <div className="flex gap-1">
                      <Button variant="ghost" size="sm" className="p-1">
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="sm" className="p-1">
                        <RotateCcw className="w-4 h-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              )) || (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-gray-600">
                    No assets generated yet
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function CodeTab({ project }: { project: any }) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-white">Source Code</h2>
        <div className="flex gap-2">
          <Button variant="secondary" size="sm" icon={<FileCode className="w-4 h-4" />}>
            New Class
          </Button>
          <Button variant="primary" size="sm" icon={<Zap className="w-4 h-4" />}>
            Generate
          </Button>
        </div>
      </div>
      <Card className="p-6">
        <div className="font-mono text-sm space-y-4">
          <div className="text-gray-500">// Generated C++ Classes will appear here</div>
          <div className="text-neon-blue">class AMyGameCharacter : public ACharacter</div>
          <div className="text-gray-300">{'{'}</div>
          <div className="text-gray-300 pl-4">GENERATED_BODY()</div>
          <div className="text-gray-300">{'}'};</div>
        </div>
      </Card>
    </div>
  );
}

function BlueprintsTab({ project }: { project: any }) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-white">Blueprints</h2>
        <Button variant="primary" size="sm" icon={<Layers className="w-4 h-4" />}>
          New Blueprint
        </Button>
      </div>
      <div className="grid md:grid-cols-3 gap-4">
        {['BP_PlayerCharacter', 'BP_GameMode', 'BP_GameInstance', 'BP_HUD', 'BP_Weapon', 'BP_EnemyAI'].map((bp) => (
          <Card key={bp} hover className="p-4 cursor-pointer">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-neon-blue/10 flex items-center justify-center">
                <Layers className="w-5 h-5 text-neon-blue" />
              </div>
              <div>
                <p className="text-white font-medium">{bp}</p>
                <p className="text-xs text-gray-500">Blueprint Class</p>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

function MapTab({ project }: { project: any }) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-white">Level Editor</h2>
        <div className="flex gap-2">
          <Button variant="secondary" size="sm" icon={<Map className="w-4 h-4" />}>
            New Level
          </Button>
          <Button variant="primary" size="sm" icon={<Zap className="w-4 h-4" />}>
            Generate Map
          </Button>
        </div>
      </div>
      <Card className="p-6 min-h-[500px] flex items-center justify-center">
        <div className="text-center">
          <Map className="w-16 h-16 text-gray-700 mx-auto mb-4" />
          <p className="text-gray-500">Level preview will appear here</p>
          <p className="text-gray-600 text-sm mt-2">Connect to UE5 to see real-time level editing</p>
        </div>
      </Card>
    </div>
  );
}

function AudioTab({ project }: { project: any }) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-white">Audio</h2>
        <Button variant="primary" size="sm" icon={<Volume2 className="w-4 h-4" />}>
          Generate Audio
        </Button>
      </div>
      <div className="grid md:grid-cols-2 gap-4">
        {['Background Music', 'Weapon Sounds', 'Footsteps', 'UI Sounds', 'Ambient', 'Voice Lines'].map((audio) => (
          <Card key={audio} className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Volume2 className="w-5 h-5 text-yellow-400" />
                <span className="text-white">{audio}</span>
              </div>
              <Button variant="ghost" size="sm" className="p-1">
                <Play className="w-4 h-4" />
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

function SettingsTab({ project }: { project: any }) {
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-white">Project Settings</h2>
      <div className="grid md:grid-cols-2 gap-6">
        <Card className="p-6">
          <h3 className="font-semibold text-white mb-4">General</h3>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-gray-400">Project Name</label>
              <input type="text" defaultValue={project.name} className="w-full mt-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-white" />
            </div>
            <div>
              <label className="text-sm text-gray-400">Description</label>
              <textarea defaultValue={project.description} rows={3} className="w-full mt-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-white resize-none" />
            </div>
          </div>
        </Card>
        <Card className="p-6">
          <h3 className="font-semibold text-white mb-4">Build Settings</h3>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-gray-400">Output Directory</label>
              <input type="text" defaultValue={project.buildPath} className="w-full mt-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-white font-mono text-sm" />
            </div>
            <div>
              <label className="text-sm text-gray-400">UE5 Engine Path</label>
              <input type="text" defaultValue={project.ue5Path} className="w-full mt-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-white font-mono text-sm" />
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
