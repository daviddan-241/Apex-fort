import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatBytes(bytes: number, decimals = 2): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

export function formatDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
  const mins = Math.floor(ms / 60000);
  const secs = ((ms % 60000) / 1000).toFixed(0);
  return `${mins}m ${secs}s`;
}

export function getStatusColor(status: string): string {
  switch (status) {
    case 'completed':
    case 'success':
      return 'text-green-400';
    case 'working':
    case 'in_progress':
      return 'text-neon-blue';
    case 'error':
    case 'failed':
      return 'text-neon-red';
    case 'warning':
      return 'text-neon-gold';
    default:
      return 'text-gray-400';
  }
}

export function getStatusBg(status: string): string {
  switch (status) {
    case 'completed':
    case 'success':
      return 'bg-green-400/10 border-green-400/30';
    case 'working':
    case 'in_progress':
      return 'bg-neon-blue/10 border-neon-blue/30';
    case 'error':
    case 'failed':
      return 'bg-neon-red/10 border-neon-red/30';
    case 'warning':
      return 'bg-neon-gold/10 border-neon-gold/30';
    default:
      return 'bg-gray-500/10 border-gray-500/30';
  }
}

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

export function debounce<T extends (...args: any[]) => void>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout;
  return (...args: Parameters<T>) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
}
