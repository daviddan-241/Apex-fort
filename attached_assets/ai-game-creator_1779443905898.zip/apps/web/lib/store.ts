import { create } from 'zustand';
import { GameProject, AgentStatus, BuildLog, User, GamePrompt } from '@/types';

interface GameState {
  // Current project
  currentProject: GameProject | null;
  projects: GameProject[];

  // UI State
  sidebarOpen: boolean;
  activeTab: string;
  terminalOpen: boolean;

  // Real-time data
  agents: AgentStatus[];
  logs: BuildLog[];
  isConnected: boolean;

  // User
  user: User | null;

  // Actions
  setCurrentProject: (project: GameProject | null) => void;
  setProjects: (projects: GameProject[]) => void;
  addProject: (project: GameProject) => void;
  updateProject: (id: string, updates: Partial<GameProject>) => void;

  setSidebarOpen: (open: boolean) => void;
  setActiveTab: (tab: string) => void;
  setTerminalOpen: (open: boolean) => void;

  setAgents: (agents: AgentStatus[]) => void;
  updateAgent: (id: string, updates: Partial<AgentStatus>) => void;

  addLog: (log: BuildLog) => void;
  setLogs: (logs: BuildLog[]) => void;

  setConnected: (connected: boolean) => void;
  setUser: (user: User | null) => void;

  // Game creation
  createGame: (prompt: GamePrompt) => Promise<void>;
  stopGeneration: () => void;
}

export const useGameStore = create<GameState>((set, get) => ({
  currentProject: null,
  projects: [],
  sidebarOpen: true,
  activeTab: 'dashboard',
  terminalOpen: true,
  agents: [],
  logs: [],
  isConnected: false,
  user: null,

  setCurrentProject: (project) => set({ currentProject: project }),
  setProjects: (projects) => set({ projects }),
  addProject: (project) => set((state) => ({ projects: [project, ...state.projects] })),
  updateProject: (id, updates) => set((state) => ({
    projects: state.projects.map(p => p.id === id ? { ...p, ...updates } : p),
    currentProject: state.currentProject?.id === id ? { ...state.currentProject, ...updates } : state.currentProject,
  })),

  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  setActiveTab: (tab) => set({ activeTab: tab }),
  setTerminalOpen: (open) => set({ terminalOpen: open }),

  setAgents: (agents) => set({ agents }),
  updateAgent: (id, updates) => set((state) => ({
    agents: state.agents.map(a => a.id === id ? { ...a, ...updates } : a),
  })),

  addLog: (log) => set((state) => ({ logs: [log, ...state.logs].slice(0, 1000) })),
  setLogs: (logs) => set({ logs }),

  setConnected: (connected) => set({ isConnected: connected }),
  setUser: (user) => set({ user }),

  createGame: async (prompt) => {
    try {
      const res = await fetch('/api/v1/games/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(prompt),
      });

      if (!res.ok) throw new Error('Failed to create game');

      const project = await res.json();
      set((state) => ({
        projects: [project, ...state.projects],
        currentProject: project,
        activeTab: 'studio',
      }));
    } catch (error) {
      console.error('Create game error:', error);
      throw error;
    }
  },

  stopGeneration: () => {
    fetch('/api/v1/games/stop', { method: 'POST' }).catch(console.error);
  },
}));
