'use client';

import { createContext, useContext, useEffect, ReactNode } from 'react';
import { useGameStore } from '@/lib/store';

const GameContext = createContext(null);

export function GameProvider({ children }: { children: ReactNode }) {
  const { setProjects } = useGameStore();

  useEffect(() => {
    const saved = localStorage.getItem('ai-game-projects');
    if (saved) {
      try {
        setProjects(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to load projects:', e);
      }
    }
  }, [setProjects]);

  return <GameContext.Provider value={null}>{children}</GameContext.Provider>;
}

export function useGame() {
  return useContext(GameContext);
}
