'use client';

import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { io, Socket } from 'socket.io-client';
import { useGameStore } from '@/lib/store';
import { toast } from '@/components/ui/Toaster';

const SocketContext = createContext<Socket | null>(null);

export function SocketProvider({ children }: { children: ReactNode }) {
  const [socket, setSocket] = useState<Socket | null>(null);
  const { setConnected, addLog, updateAgent, updateProject } = useGameStore();

  useEffect(() => {
    const newSocket = io('http://localhost:8001', {
      transports: ['websocket'],
      reconnection: true,
      reconnectionAttempts: 5,
    });

    newSocket.on('connect', () => {
      setConnected(true);
      toast('Connected to AI Game Studio', 'success');
    });

    newSocket.on('disconnect', () => {
      setConnected(false);
      toast('Disconnected from server', 'error');
    });

    newSocket.on('log', (data) => {
      addLog(data);
    });

    newSocket.on('agent_update', (data) => {
      updateAgent(data.id, data);
    });

    newSocket.on('project_update', (data) => {
      updateProject(data.id, data);
    });

    newSocket.on('build_complete', (data) => {
      toast(`Build completed: ${data.projectName}`, 'success');
    });

    newSocket.on('build_error', (data) => {
      toast(`Build error: ${data.message}`, 'error');
    });

    setSocket(newSocket);

    return () => {
      newSocket.close();
    };
  }, [setConnected, addLog, updateAgent, updateProject]);

  return (
    <SocketContext.Provider value={socket}>
      {children}
    </SocketContext.Provider>
  );
}

export function useSocket() {
  return useContext(SocketContext);
}
