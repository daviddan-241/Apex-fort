'use client';

import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, CheckCircle, AlertCircle, Info } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

let toastListeners: ((toasts: Toast[]) => void)[] = [];
let toasts: Toast[] = [];

export function toast(message: string, type: Toast['type'] = 'info') {
  const id = Math.random().toString(36).substr(2, 9);
  toasts = [...toasts, { id, message, type }];
  toastListeners.forEach((listener) => listener(toasts));
  setTimeout(() => {
    toasts = toasts.filter((t) => t.id !== id);
    toastListeners.forEach((listener) => listener(toasts));
  }, 4000);
}

export function Toaster() {
  const [activeToasts, setActiveToasts] = useState<Toast[]>([]);

  useEffect(() => {
    toastListeners.push(setActiveToasts);
    return () => {
      toastListeners = toastListeners.filter((l) => l !== setActiveToasts);
    };
  }, []);

  return (
    <div className="fixed top-4 right-4 z-[100] space-y-2">
      <AnimatePresence>
        {activeToasts.map((t) => (
          <motion.div
            key={t.id}
            initial={{ opacity: 0, x: 50, scale: 0.9 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 50, scale: 0.9 }}
            className={cn(
              'glass-card p-4 flex items-center gap-3 min-w-[300px]',
              t.type === 'success' && 'border-green-400/30',
              t.type === 'error' && 'border-neon-red/30',
              t.type === 'info' && 'border-neon-blue/30'
            )}
          >
            {t.type === 'success' && <CheckCircle className="w-5 h-5 text-green-400" />}
            {t.type === 'error' && <AlertCircle className="w-5 h-5 text-neon-red" />}
            {t.type === 'info' && <Info className="w-5 h-5 text-neon-blue" />}
            <span className="text-sm text-gray-200 flex-1">{t.message}</span>
            <button
              onClick={() => {
                toasts = toasts.filter((toast) => toast.id !== t.id);
                setActiveToasts(toasts);
              }}
              className="p-1 hover:bg-white/10 rounded"
            >
              <X className="w-4 h-4 text-gray-400" />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
