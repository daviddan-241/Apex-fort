import { cn } from '@/lib/utils';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'default' | 'success' | 'warning' | 'error' | 'info' | 'gold';
  className?: string;
}

export function Badge({ children, variant = 'default', className }: BadgeProps) {
  const variants = {
    default: 'bg-white/10 text-white',
    success: 'bg-green-400/20 text-green-400 border-green-400/30',
    warning: 'bg-neon-gold/20 text-neon-gold border-neon-gold/30',
    error: 'bg-neon-red/20 text-neon-red border-neon-red/30',
    info: 'bg-neon-blue/20 text-neon-blue border-neon-blue/30',
    gold: 'bg-neon-gold/20 text-neon-gold border-neon-gold/30',
  };

  return (
    <span className={cn('inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border', variants[variant], className)}>
      {children}
    </span>
  );
}
