'use client';

import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';
import { Loader2 } from 'lucide-react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'gold';
  size?: 'sm' | 'md' | 'lg';
  isLoading?: boolean;
  icon?: React.ReactNode;
}

export function Button({
  children,
  variant = 'primary',
  size = 'md',
  isLoading = false,
  icon,
  className,
  disabled,
  ...props
}: ButtonProps) {
  const variants = {
    primary: 'bg-neon-blue/20 text-neon-blue border-neon-blue/50 hover:bg-neon-blue/30 hover:shadow-[0_0_20px_rgba(0,240,255,0.3)]',
    secondary: 'bg-white/5 text-white border-white/10 hover:bg-white/10',
    ghost: 'bg-transparent text-gray-400 border-transparent hover:text-white hover:bg-white/5',
    danger: 'bg-neon-red/20 text-neon-red border-neon-red/50 hover:bg-neon-red/30 hover:shadow-[0_0_20px_rgba(255,42,109,0.3)]',
    gold: 'bg-neon-gold/20 text-neon-gold border-neon-gold/50 hover:bg-neon-gold/30 hover:shadow-[0_0_20px_rgba(255,215,0,0.3)]',
  };

  const sizes = {
    sm: 'px-3 py-1.5 text-sm',
    md: 'px-4 py-2',
    lg: 'px-6 py-3 text-lg',
  };

  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className={cn(
        'relative inline-flex items-center justify-center gap-2 rounded-lg border font-medium transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed',
        variants[variant],
        sizes[size],
        className
      )}
      disabled={disabled || isLoading}
      {...props}
    >
      {isLoading && <Loader2 className="w-4 h-4 animate-spin" />}
      {!isLoading && icon}
      {children}
    </motion.button>
  );
}
