'use client';

import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
  glow?: boolean;
  onClick?: () => void;
}

export function Card({ children, className, hover = false, glow = false, onClick }: CardProps) {
  return (
    <motion.div
      whileHover={hover ? { y: -2, scale: 1.01 } : undefined}
      className={cn(
        'glass-card p-6',
        hover && 'cursor-pointer transition-transform',
        glow && 'neon-border',
        className
      )}
      onClick={onClick}
    >
      {children}
    </motion.div>
  );
}
