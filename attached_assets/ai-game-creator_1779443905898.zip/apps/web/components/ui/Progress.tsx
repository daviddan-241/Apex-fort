'use client';

import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface ProgressProps {
  value: number;
  max?: number;
  className?: string;
  barClassName?: string;
  animated?: boolean;
  label?: string;
}

export function Progress({ value, max = 100, className, barClassName, animated = true, label }: ProgressProps) {
  const percentage = Math.min(100, Math.max(0, (value / max) * 100));

  return (
    <div className={cn('w-full', className)}>
      {label && (
        <div className="flex justify-between mb-1">
          <span className="text-xs text-gray-400">{label}</span>
          <span className="text-xs text-neon-blue font-mono">{percentage.toFixed(1)}%</span>
        </div>
      )}
      <div className="h-2 bg-white/5 rounded-full overflow-hidden border border-white/10">
        <motion.div
          className={cn('h-full rounded-full', barClassName || 'bg-gradient-to-r from-neon-blue to-cyan-400')}
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={animated ? { duration: 0.5, ease: 'easeOut' } : { duration: 0 }}
        />
      </div>
    </div>
  );
}
