'use client';

import { useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Terminal as TerminalIcon, X, Minimize2, Maximize2, Trash2 } from 'lucide-react';
import { useGameStore } from '@/lib/store';
import { cn } from '@/lib/utils';
import { formatDuration } from '@/lib/utils';

export function Terminal() {
  const { terminalOpen, setTerminalOpen, logs } = useGameStore();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [maximized, setMaximized] = React.useState(false);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  if (!terminalOpen) {
    return (
      <motion.button
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        onClick={() => setTerminalOpen(true)}
        className="fixed bottom-4 right-4 z-50 glass-card p-3 neon-border cursor-pointer"
      >
        <TerminalIcon className="w-5 h-5 text-neon-blue" />
        {logs.length > 0 && (
          <span className="absolute -top-1 -right-1 w-3 h-3 bg-neon-red rounded-full animate-pulse" />
        )}
      </motion.button>
    );
  }

  const getLogColor = (level: string) => {
    switch (level) {
      case 'error': return 'text-neon-red';
      case 'warn': return 'text-neon-gold';
      case 'success': return 'text-green-400';
      default: return 'text-gray-300';
    }
  };

  const getLogIcon = (level: string) => {
    switch (level) {
      case 'error': return '✗';
      case 'warn': return '⚠';
      case 'success': return '✓';
      default: return '>';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 50 }}
      className={cn(
        'fixed z-50 glass-card neon-border flex flex-col',
        maximized 
          ? 'inset-4' 
          : 'bottom-4 right-4 w-[600px] h-[400px]'
      )}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-white/10">
        <div className="flex items-center gap-2">
          <TerminalIcon className="w-4 h-4 text-neon-blue" />
          <span className="text-sm font-medium text-gray-300">Build Terminal</span>
          <span className="text-xs text-gray-500 font-mono">{logs.length} entries</span>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={() => setMaximized(!maximized)} className="p-1 hover:bg-white/10 rounded">
            {maximized ? <Minimize2 className="w-4 h-4 text-gray-400" /> : <Maximize2 className="w-4 h-4 text-gray-400" />}
          </button>
          <button onClick={() => useGameStore.getState().setLogs([])} className="p-1 hover:bg-white/10 rounded">
            <Trash2 className="w-4 h-4 text-gray-400" />
          </button>
          <button onClick={() => setTerminalOpen(false)} className="p-1 hover:bg-white/10 rounded">
            <X className="w-4 h-4 text-gray-400" />
          </button>
        </div>
      </div>

      {/* Logs */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 font-mono text-xs space-y-1 scrollbar-hide">
        <AnimatePresence>
          {logs.map((log) => (
            <motion.div
              key={log.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex gap-2"
            >
              <span className="text-gray-600 shrink-0">
                {new Date(log.timestamp).toLocaleTimeString()}
              </span>
              <span className={cn('shrink-0', getLogColor(log.level))}>
                {getLogIcon(log.level)}
              </span>
              <span className="text-gray-500 shrink-0">[{log.agent}]</span>
              <span className={cn('break-all', getLogColor(log.level))}>
                {log.message}
              </span>
            </motion.div>
          ))}
        </AnimatePresence>
        {logs.length === 0 && (
          <div className="text-gray-600 text-center py-8">
            No logs yet. Start creating a game to see live build output.
          </div>
        )}
      </div>

      {/* Input */}
      <div className="px-4 py-2 border-t border-white/10 flex items-center gap-2">
        <span className="text-neon-blue font-mono text-sm">$</span>
        <input
          type="text"
          placeholder="Type command..."
          className="flex-1 bg-transparent text-sm text-gray-300 font-mono outline-none placeholder:text-gray-600"
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              // Send command to backend
              e.currentTarget.value = '';
            }
          }}
        />
      </div>
    </motion.div>
  );
}
