const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const { createServer } = require('http');
const { Server } = require('socket.io');
require('dotenv').config();

const logger = require('./utils/logger');
const { errorHandler } = require('./utils/errors');
const gameRoutes = require('./api/routes/games');
const agentRoutes = require('./api/routes/agents');
const assetRoutes = require('./api/routes/assets');
const { ProjectManager } = require('./models/ProjectManager');
const { AgentOrchestrator } = require('./orchestrator/director');
const { WebSocketManager } = require('./api/websocket');

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: { origin: '*' },
  transports: ['websocket'],
});

const PORT = process.env.PORT || 8000;
const WS_PORT = process.env.WS_PORT || 8001;

// Middleware
app.use(helmet());
app.use(compression());
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Request logging
app.use((req, res, next) => {
  logger.info(`${req.method} ${req.path}`, { ip: req.ip });
  next();
});

// Initialize systems
const projectManager = new ProjectManager();
const orchestrator = new AgentOrchestrator(projectManager);
const wsManager = new WebSocketManager(io, orchestrator);

// Routes
app.use('/api/v1/games', gameRoutes({ projectManager, orchestrator, wsManager }));
app.use('/api/v1/agents', agentRoutes({ orchestrator, wsManager }));
app.use('/api/v1/assets', assetRoutes({ projectManager }));

// Health check
app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    agents: orchestrator.getAgentStatuses(),
  });
});

// Error handling
app.use(errorHandler);

// Start servers
httpServer.listen(PORT, () => {
  logger.info(`HTTP Server running on port ${PORT}`);
});

// WebSocket server on separate port for real-time updates
const wsHttpServer = createServer();
const wsIo = new Server(wsHttpServer, {
  cors: { origin: '*' },
  transports: ['websocket'],
});

wsManager.attach(wsIo);

wsHttpServer.listen(WS_PORT, () => {
  logger.info(`WebSocket Server running on port ${WS_PORT}`);
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  logger.info('SIGTERM received, shutting down gracefully');
  await orchestrator.shutdown();
  httpServer.close(() => {
    logger.info('HTTP server closed');
    process.exit(0);
  });
});

module.exports = { app, io, projectManager, orchestrator };
