const BaseAgent = require('../BaseAgent');
const path = require('path');

class UIGenerationAgent extends BaseAgent {
  constructor(id, name, role, color, orchestrator) {
    super(id, name, role, color, orchestrator);
  }

  async processTask(task, project) {
    const projectDir = path.join(process.env.PROJECTS_DIR || './projects', project.id);
    const uiDir = path.join(projectDir, 'Content', 'UI');

    this.emitLog(project.id, 'info', `Generating UI: ${task.type}`);

    let result;
    switch (task.type) {
      case 'hud':
        result = await this.generateHUD(uiDir, project);
        break;
      default:
        result = await this.generateGenericUI(uiDir, task, project);
    }

    this.emitLog(project.id, 'success', `UI generated: ${task.type}`);
    return result;
  }

  async generateHUD(uiDir, project) {
    // Generate UMG Widget Blueprints as JSON
    const widgets = {
      'WBP_MainHUD': this.generateMainHUD(project),
      'WBP_MainMenu': this.generateMainMenu(project),
      'WBP_PauseMenu': this.generatePauseMenu(project),
      'WBP_Settings': this.generateSettings(project),
      'WBP_Inventory': this.generateInventory(project),
      'WBP_Scoreboard': this.generateScoreboard(project),
      'WBP_Chat': this.generateChat(project),
      'WBP_Loading': this.generateLoadingScreen(project),
    };

    const assets = [];
    for (const [name, data] of Object.entries(widgets)) {
      await this.writeFile(
        path.join(uiDir, `${name}.json`),
        JSON.stringify(data, null, 2)
      );

      assets.push({
        name,
        type: 'ui',
        path: path.join(uiDir, `${name}.json`),
        size: JSON.stringify(data).length / 1024,
        status: 'completed',
        generatedBy: this.name,
      });
    }

    return { assets };
  }

  generateMainHUD(project) {
    return {
      type: 'WidgetBlueprint',
      name: 'WBP_MainHUD',
      size: { x: 1920, y: 1080 },
      elements: [
        {
          name: 'HealthBar',
          type: 'ProgressBar',
          position: { x: 40, y: 40 },
          size: { x: 300, y: 24 },
          style: {
            fillColor: { r: 0.9, g: 0.1, b: 0.1 },
            backgroundColor: { r: 0.1, g: 0.1, b: 0.1, a: 0.5 },
            borderRadius: 4,
          },
          binding: { source: 'PlayerCharacter', property: 'Health', maxProperty: 'MaxHealth' },
        },
        {
          name: 'HealthText',
          type: 'TextBlock',
          position: { x: 40, y: 70 },
          text: '{Health}/{MaxHealth}',
          font: { size: 14, family: 'Roboto', color: { r: 1, g: 1, b: 1 } },
          binding: { source: 'PlayerCharacter', property: 'Health' },
        },
        {
          name: 'AmmoCounter',
          type: 'TextBlock',
          position: { x: 40, y: 100 },
          text: '{CurrentAmmo} / {MaxAmmo}',
          font: { size: 18, family: 'Roboto', color: { r: 1, g: 0.8, b: 0 } },
          binding: { source: 'CurrentWeapon', property: 'CurrentAmmo' },
        },
        {
          name: 'Crosshair',
          type: 'Image',
          position: { center: true },
          size: { x: 32, y: 32 },
          image: '/Game/UI/Images/Crosshair',
          color: { r: 0, g: 1, b: 0, a: 0.8 },
        },
        {
          name: 'Minimap',
          type: 'Image',
          position: { x: -180, y: 40, anchor: 'TopRight' },
          size: { x: 160, y: 160 },
          image: '/Game/UI/Images/Minimap_BG',
          borderRadius: 80,
        },
        {
          name: 'KillFeed',
          type: 'ScrollBox',
          position: { x: -320, y: 200, anchor: 'TopRight' },
          size: { x: 300, y: 200 },
          items: [],
        },
        {
          name: 'WeaponIcon',
          type: 'Image',
          position: { x: 40, y: 140 },
          size: { x: 64, y: 64 },
          binding: { source: 'CurrentWeapon', property: 'Icon' },
        },
        {
          name: 'ScoreDisplay',
          type: 'TextBlock',
          position: { center: true, y: 40 },
          text: '{TeamScore} - {EnemyScore}',
          font: { size: 24, family: 'Roboto', color: { r: 1, g: 1, b: 1 } },
          binding: { source: 'GameState', property: 'Score' },
        },
        {
          name: 'TimerDisplay',
          type: 'TextBlock',
          position: { center: true, y: 80 },
          text: '{MatchTimeRemaining}',
          font: { size: 20, family: 'Roboto Mono', color: { r: 1, g: 1, b: 1 } },
          binding: { source: 'GameState', property: 'MatchTimeRemaining' },
        },
        {
          name: 'NotificationArea',
          type: 'VerticalBox',
          position: { x: 40, y: -100, anchor: 'BottomLeft' },
          size: { x: 400, y: 200 },
        },
      ],
    };
  }

  generateMainMenu(project) {
    return {
      type: 'WidgetBlueprint',
      name: 'WBP_MainMenu',
      size: { x: 1920, y: 1080 },
      elements: [
        {
          name: 'Background',
          type: 'Image',
          position: { x: 0, y: 0 },
          size: { x: 1920, y: 1080 },
          image: '/Game/UI/Images/MenuBackground',
        },
        {
          name: 'Overlay',
          type: 'Image',
          position: { x: 0, y: 0 },
          size: { x: 1920, y: 1080 },
          color: { r: 0, g: 0, b: 0, a: 0.3 },
        },
        {
          name: 'GameTitle',
          type: 'TextBlock',
          position: { center: true, y: 150 },
          text: project.name,
          font: { size: 72, family: 'Impact', color: { r: 1, g: 1, b: 1 }, shadow: true },
        },
        {
          name: 'Subtitle',
          type: 'TextBlock',
          position: { center: true, y: 240 },
          text: 'AI Generated with Unreal Engine 5',
          font: { size: 16, family: 'Roboto', color: { r: 0.7, g: 0.7, b: 0.7 } },
        },
        {
          name: 'PlayButton',
          type: 'Button',
          position: { center: true, y: 400 },
          size: { x: 300, y: 60 },
          text: 'PLAY',
          font: { size: 24, family: 'Roboto', color: { r: 1, g: 1, b: 1 } },
          style: {
            backgroundColor: { r: 0, g: 0.8, b: 1, a: 0.8 },
            hoverColor: { r: 0, g: 1, b: 1, a: 1 },
            borderRadius: 8,
          },
          action: 'StartGame',
        },
        {
          name: 'MultiplayerButton',
          type: 'Button',
          position: { center: true, y: 480 },
          size: { x: 300, y: 60 },
          text: 'MULTIPLAYER',
          font: { size: 24, family: 'Roboto', color: { r: 1, g: 1, b: 1 } },
          style: {
            backgroundColor: { r: 0.2, g: 0.2, b: 0.2, a: 0.8 },
            hoverColor: { r: 0.3, g: 0.3, b: 0.3, a: 1 },
            borderRadius: 8,
          },
          action: 'OpenMultiplayer',
        },
        {
          name: 'SettingsButton',
          type: 'Button',
          position: { center: true, y: 560 },
          size: { x: 300, y: 60 },
          text: 'SETTINGS',
          font: { size: 24, family: 'Roboto', color: { r: 1, g: 1, b: 1 } },
          style: {
            backgroundColor: { r: 0.2, g: 0.2, b: 0.2, a: 0.8 },
            hoverColor: { r: 0.3, g: 0.3, b: 0.3, a: 1 },
            borderRadius: 8,
          },
          action: 'OpenSettings',
        },
        {
          name: 'QuitButton',
          type: 'Button',
          position: { center: true, y: 640 },
          size: { x: 300, y: 60 },
          text: 'QUIT',
          font: { size: 24, family: 'Roboto', color: { r: 1, g: 1, b: 1 } },
          style: {
            backgroundColor: { r: 0.8, g: 0.1, b: 0.1, a: 0.8 },
            hoverColor: { r: 1, g: 0.2, b: 0.2, a: 1 },
            borderRadius: 8,
          },
          action: 'QuitGame',
        },
        {
          name: 'VersionText',
          type: 'TextBlock',
          position: { x: 20, y: -20, anchor: 'BottomLeft' },
          text: 'v1.0.0 - UE5.4',
          font: { size: 12, family: 'Roboto', color: { r: 0.5, g: 0.5, b: 0.5 } },
        },
      ],
    };
  }

  generatePauseMenu(project) {
    return {
      type: 'WidgetBlueprint',
      name: 'WBP_PauseMenu',
      size: { x: 1920, y: 1080 },
      elements: [
        {
          name: 'Background',
          type: 'Image',
          position: { x: 0, y: 0 },
          size: { x: 1920, y: 1080 },
          color: { r: 0, g: 0, b: 0, a: 0.7 },
        },
        {
          name: 'MenuPanel',
          type: 'Image',
          position: { center: true },
          size: { x: 400, y: 500 },
          color: { r: 0.1, g: 0.1, b: 0.1, a: 0.9 },
          borderRadius: 16,
        },
        {
          name: 'Title',
          type: 'TextBlock',
          position: { center: true, y: 200 },
          text: 'PAUSED',
          font: { size: 36, family: 'Impact', color: { r: 1, g: 1, b: 1 } },
        },
        {
          name: 'ResumeButton',
          type: 'Button',
          position: { center: true, y: 300 },
          size: { x: 250, y: 50 },
          text: 'RESUME',
          action: 'ResumeGame',
        },
        {
          name: 'SettingsButton',
          type: 'Button',
          position: { center: true, y: 370 },
          size: { x: 250, y: 50 },
          text: 'SETTINGS',
          action: 'OpenSettings',
        },
        {
          name: 'RestartButton',
          type: 'Button',
          position: { center: true, y: 440 },
          size: { x: 250, y: 50 },
          text: 'RESTART',
          action: 'RestartLevel',
        },
        {
          name: 'QuitButton',
          type: 'Button',
          position: { center: true, y: 510 },
          size: { x: 250, y: 50 },
          text: 'QUIT TO MENU',
          action: 'QuitToMenu',
        },
      ],
    };
  }

  generateSettings(project) {
    return {
      type: 'WidgetBlueprint',
      name: 'WBP_Settings',
      size: { x: 1920, y: 1080 },
      elements: [
        {
          name: 'Background',
          type: 'Image',
          position: { x: 0, y: 0 },
          size: { x: 1920, y: 1080 },
          color: { r: 0, g: 0, b: 0, a: 0.8 },
        },
        {
          name: 'SettingsPanel',
          type: 'Image',
          position: { center: true },
          size: { x: 800, y: 700 },
          color: { r: 0.1, g: 0.1, b: 0.1, a: 0.95 },
          borderRadius: 16,
        },
        {
          name: 'Title',
          type: 'TextBlock',
          position: { center: true, y: 120 },
          text: 'SETTINGS',
          font: { size: 36, family: 'Impact', color: { r: 1, g: 1, b: 1 } },
        },
        {
          name: 'GraphicsQuality',
          type: 'Slider',
          position: { center: true, y: 220 },
          size: { x: 400, y: 40 },
          label: 'Graphics Quality',
          min: 0,
          max: 3,
          default: 2,
          options: ['Low', 'Medium', 'High', 'Epic'],
          binding: 'GraphicsQuality',
        },
        {
          name: 'Resolution',
          type: 'Dropdown',
          position: { center: true, y: 290 },
          size: { x: 400, y: 40 },
          label: 'Resolution',
          options: ['1280x720', '1920x1080', '2560x1440', '3840x2160'],
          default: '1920x1080',
          binding: 'ScreenResolution',
        },
        {
          name: 'Fullscreen',
          type: 'Toggle',
          position: { center: true, y: 360 },
          size: { x: 400, y: 40 },
          label: 'Fullscreen',
          default: true,
          binding: 'Fullscreen',
        },
        {
          name: 'VSync',
          type: 'Toggle',
          position: { center: true, y: 420 },
          size: { x: 400, y: 40 },
          label: 'VSync',
          default: true,
          binding: 'VSync',
        },
        {
          name: 'Sensitivity',
          type: 'Slider',
          position: { center: true, y: 490 },
          size: { x: 400, y: 40 },
          label: 'Mouse Sensitivity',
          min: 0.1,
          max: 5.0,
          default: 1.0,
          binding: 'MouseSensitivity',
        },
        {
          name: 'MasterVolume',
          type: 'Slider',
          position: { center: true, y: 560 },
          size: { x: 400, y: 40 },
          label: 'Master Volume',
          min: 0,
          max: 100,
          default: 80,
          binding: 'MasterVolume',
        },
        {
          name: 'ApplyButton',
          type: 'Button',
          position: { center: true, y: 650 },
          size: { x: 200, y: 50 },
          text: 'APPLY',
          action: 'ApplySettings',
        },
        {
          name: 'BackButton',
          type: 'Button',
          position: { center: true, y: 720 },
          size: { x: 200, y: 50 },
          text: 'BACK',
          action: 'BackToMenu',
        },
      ],
    };
  }

  generateInventory(project) {
    return {
      type: 'WidgetBlueprint',
      name: 'WBP_Inventory',
      size: { x: 800, y: 600 },
      elements: [
        {
          name: 'Background',
          type: 'Image',
          position: { x: 0, y: 0 },
          size: { x: 800, y: 600 },
          color: { r: 0, g: 0, b: 0, a: 0.9 },
          borderRadius: 16,
        },
        {
          name: 'Title',
          type: 'TextBlock',
          position: { x: 30, y: 20 },
          text: 'INVENTORY',
          font: { size: 28, family: 'Impact', color: { r: 1, g: 1, b: 1 } },
        },
        {
          name: 'Grid',
          type: 'UniformGridPanel',
          position: { x: 30, y: 80 },
          size: { x: 500, y: 480 },
          columns: 5,
          rows: 4,
          slotSize: { x: 90, y: 90 },
          binding: { source: 'InventoryComponent', property: 'Items' },
        },
        {
          name: 'ItemDetail',
          type: 'Image',
          position: { x: 560, y: 80 },
          size: { x: 220, y: 300 },
          color: { r: 0.15, g: 0.15, b: 0.15, a: 1 },
          borderRadius: 8,
        },
        {
          name: 'ItemName',
          type: 'TextBlock',
          position: { x: 570, y: 400 },
          text: 'Select an item',
          font: { size: 18, family: 'Roboto', color: { r: 1, g: 1, b: 1 } },
        },
        {
          name: 'ItemDescription',
          type: 'TextBlock',
          position: { x: 570, y: 430 },
          text: '',
          font: { size: 14, family: 'Roboto', color: { r: 0.7, g: 0.7, b: 0.7 } },
          wrap: true,
          size: { x: 200, y: 100 },
        },
        {
          name: 'CloseButton',
          type: 'Button',
          position: { x: -60, y: 20, anchor: 'TopRight' },
          size: { x: 40, y: 40 },
          text: 'X',
          action: 'CloseInventory',
        },
      ],
    };
  }

  generateScoreboard(project) {
    return {
      type: 'WidgetBlueprint',
      name: 'WBP_Scoreboard',
      size: { x: 600, y: 500 },
      elements: [
        {
          name: 'Background',
          type: 'Image',
          position: { x: 0, y: 0 },
          size: { x: 600, y: 500 },
          color: { r: 0, g: 0, b: 0, a: 0.85 },
          borderRadius: 12,
        },
        {
          name: 'Title',
          type: 'TextBlock',
          position: { center: true, y: 20 },
          text: 'SCOREBOARD',
          font: { size: 24, family: 'Impact', color: { r: 1, g: 1, b: 1 } },
        },
        {
          name: 'Team1Header',
          type: 'TextBlock',
          position: { x: 50, y: 70 },
          text: 'TEAM A',
          font: { size: 16, family: 'Roboto', color: { r: 0, g: 0.8, b: 1 } },
        },
        {
          name: 'Team2Header',
          type: 'TextBlock',
          position: { x: 350, y: 70 },
          text: 'TEAM B',
          font: { size: 16, family: 'Roboto', color: { r: 1, g: 0.2, b: 0.2 } },
        },
        {
          name: 'PlayerList',
          type: 'ScrollBox',
          position: { x: 50, y: 110 },
          size: { x: 500, y: 350 },
          binding: { source: 'GameState', property: 'PlayerList' },
        },
      ],
    };
  }

  generateChat(project) {
    return {
      type: 'WidgetBlueprint',
      name: 'WBP_Chat',
      size: { x: 450, y: 300 },
      elements: [
        {
          name: 'Background',
          type: 'Image',
          position: { x: 0, y: 0 },
          size: { x: 450, y: 300 },
          color: { r: 0, g: 0, b: 0, a: 0.5 },
          borderRadius: 8,
        },
        {
          name: 'MessageList',
          type: 'ScrollBox',
          position: { x: 10, y: 10 },
          size: { x: 430, y: 250 },
        },
        {
          name: 'InputField',
          type: 'EditableTextBox',
          position: { x: 10, y: -40, anchor: 'BottomLeft' },
          size: { x: 360, y: 35 },
          hint: 'Type a message...',
        },
        {
          name: 'SendButton',
          type: 'Button',
          position: { x: -10, y: -40, anchor: 'BottomRight' },
          size: { x: 60, y: 35 },
          text: 'Send',
          action: 'SendChatMessage',
        },
      ],
    };
  }

  generateLoadingScreen(project) {
    return {
      type: 'WidgetBlueprint',
      name: 'WBP_Loading',
      size: { x: 1920, y: 1080 },
      elements: [
        {
          name: 'Background',
          type: 'Image',
          position: { x: 0, y: 0 },
          size: { x: 1920, y: 1080 },
          image: '/Game/UI/Images/LoadingBackground',
        },
        {
          name: 'Logo',
          type: 'Image',
          position: { center: true, y: -100 },
          size: { x: 400, y: 200 },
          image: '/Game/UI/Images/GameLogo',
        },
        {
          name: 'LoadingBar',
          type: 'ProgressBar',
          position: { center: true, y: 200 },
          size: { x: 600, y: 8 },
          style: {
            fillColor: { r: 0, g: 0.8, b: 1 },
            backgroundColor: { r: 0.2, g: 0.2, b: 0.2 },
          },
          binding: 'LoadingProgress',
        },
        {
          name: 'LoadingText',
          type: 'TextBlock',
          position: { center: true, y: 230 },
          text: 'Loading... {Progress}%',
          font: { size: 16, family: 'Roboto', color: { r: 0.8, g: 0.8, b: 0.8 } },
          binding: 'LoadingProgress',
        },
        {
          name: 'TipText',
          type: 'TextBlock',
          position: { center: true, y: 300 },
          text: 'Tip: Use cover to avoid enemy fire',
          font: { size: 14, family: 'Roboto', color: { r: 0.6, g: 0.6, b: 0.6 } },
        },
      ],
    };
  }

  async generateGenericUI(uiDir, task, project) {
    const widget = {
      type: 'WidgetBlueprint',
      name: `WBP_${task.type}`,
      generatedBy: this.name,
      timestamp: new Date().toISOString(),
    };

    await this.writeFile(
      path.join(uiDir, `WBP_${task.type}.json`),
      JSON.stringify(widget, null, 2)
    );

    return {
      assets: [
        { name: `WBP_${task.type}`, type: 'ui', path: path.join(uiDir, `WBP_${task.type}.json`), size: 4, status: 'completed', generatedBy: this.name },
      ],
    };
  }
}

module.exports = UIGenerationAgent;
