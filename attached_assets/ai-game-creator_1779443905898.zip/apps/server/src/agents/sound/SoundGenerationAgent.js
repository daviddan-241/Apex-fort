const BaseAgent = require('../BaseAgent');
const path = require('path');

class SoundGenerationAgent extends BaseAgent {
  constructor(id, name, role, color, orchestrator) {
    super(id, name, role, color, orchestrator);
  }

  async processTask(task, project) {
    const projectDir = path.join(process.env.PROJECTS_DIR || './projects', project.id);
    const soundDir = path.join(projectDir, 'Content', 'Sounds');

    this.emitLog(project.id, 'info', `Generating audio: ${task.type}`);

    const sounds = this.generateSoundList(project);
    const assets = [];

    for (const sound of sounds) {
      const soundData = this.generateSoundData(sound);
      await this.writeFile(path.join(soundDir, `${sound.name}.wav`), soundData);
      assets.push({
        name: sound.name, type: 'sound',
        path: path.join(soundDir, `${sound.name}.wav`),
        size: sound.size, status: 'completed', generatedBy: this.name,
      });
    }

    this.emitLog(project.id, 'success', `Generated ${assets.length} audio files`);
    return { assets };
  }

  generateSoundList(project) {
    const baseSounds = [
      { name: 'S_Footstep_Concrete', category: 'footsteps', size: 256 },
      { name: 'S_Footstep_Grass', category: 'footsteps', size: 256 },
      { name: 'S_Footstep_Metal', category: 'footsteps', size: 256 },
      { name: 'S_Jump', category: 'movement', size: 128 },
      { name: 'S_Land', category: 'movement', size: 128 },
      { name: 'S_Rifle_Fire', category: 'weapons', size: 512 },
      { name: 'S_Pistol_Fire', category: 'weapons', size: 384 },
      { name: 'S_Shotgun_Fire', category: 'weapons', size: 640 },
      { name: 'S_Sniper_Fire', category: 'weapons', size: 768 },
      { name: 'S_Reload', category: 'weapons', size: 384 },
      { name: 'S_Weapon_Empty', category: 'weapons', size: 64 },
      { name: 'S_Explosion', category: 'effects', size: 1024 },
      { name: 'S_Impact_Bullet', category: 'effects', size: 128 },
      { name: 'S_UI_Click', category: 'ui', size: 32 },
      { name: 'S_UI_Hover', category: 'ui', size: 16 },
      { name: 'S_Ambient_Wind', category: 'ambient', size: 2048 },
      { name: 'S_Music_Menu', category: 'music', size: 4096 },
      { name: 'S_Music_Combat', category: 'music', size: 4096 },
      { name: 'S_Voice_Hit', category: 'voice', size: 128 },
      { name: 'S_Voice_Death', category: 'voice', size: 256 },
    ];
    if (project.genre === 'racing') {
      baseSounds.push(
        { name: 'S_Engine_Rev', category: 'vehicle', size: 1024 },
        { name: 'S_Tire_Skid', category: 'vehicle', size: 384 },
        { name: 'S_Crash', category: 'vehicle', size: 768 },
      );
    }
    if (project.genre === 'survival') {
      baseSounds.push(
        { name: 'S_Zombie_Growl', category: 'enemy', size: 512 },
        { name: 'S_Zombie_Attack', category: 'enemy', size: 384 },
        { name: 'S_Crafting', category: 'interaction', size: 256 },
      );
    }
    return baseSounds;
  }

  generateSoundData(sound) {
    return `WAV_AUDIO_DATA_PLACEHOLDER_${sound.name}_${sound.category}_${sound.size}KB`;
  }
}

module.exports = SoundGenerationAgent;
