const BaseAgent = require('../BaseAgent');
const logger = require('../../utils/logger');
const path = require('path');

class BlueprintAgent extends BaseAgent {
  constructor(id, name, role, color, orchestrator) {
    super(id, name, role, color, orchestrator);
  }

  async processTask(task, project) {
    const projectDir = path.join(process.env.PROJECTS_DIR || './projects', project.id);
    const bpDir = path.join(projectDir, 'Content', 'Blueprints');

    this.emitLog(project.id, 'info', `Generating blueprints: ${task.type}`);

    let result;
    switch (task.type) {
      case 'game_mode':
        result = await this.generateGameMode(bpDir, project);
        break;
      case 'character_bp':
        result = await this.generateCharacterBlueprint(bpDir, project);
        break;
      case 'weapon_system':
        result = await this.generateWeaponSystem(bpDir, project);
        break;
      case 'hud':
        result = await this.generateHUD(bpDir, project);
        break;
      default:
        result = await this.generateGenericBlueprint(bpDir, task, project);
    }

    this.emitLog(project.id, 'success', `Blueprint generated: ${task.type}`);
    return result;
  }

  async generateGameMode(bpDir, project) {
    const gameModeBP = {
      name: 'BP_GameMode',
      type: 'GameModeBase',
      parent: '/Script/Engine.GameModeBase',
      properties: {
        DefaultPawnClass: '/Game/Blueprints/BP_PlayerCharacter',
        PlayerControllerClass: '/Game/Blueprints/BP_PlayerController',
        HUDClass: '/Game/Blueprints/BP_HUD',
        GameStateClass: '/Game/Blueprints/BP_GameState',
        PlayerStateClass: '/Game/Blueprints/BP_PlayerState',
      },
      events: {
        'Event BeginPlay': {
          nodes: [
            { type: 'EventBeginPlay', outputs: ['Exec'] },
            { type: 'PrintString', inputs: ['Exec', 'In String'], params: { InString: 'Game Started!' } },
            { type: 'SetGameState', inputs: ['Exec'], params: { State: 'Playing' } },
          ],
        },
        'Event OnPlayerJoined': {
          nodes: [
            { type: 'CustomEvent', name: 'OnPlayerJoined', outputs: ['Exec', 'Player'] },
            { type: 'SpawnActor', inputs: ['Exec', 'Player'], params: { Class: 'BP_PlayerCharacter' } },
            { type: 'Possess', inputs: ['Exec', 'Player', 'Pawn'] },
          ],
        },
      },
    };

    await this.writeFile(
      path.join(bpDir, 'BP_GameMode.json'),
      JSON.stringify(gameModeBP, null, 2)
    );

    // Generate actual .uasset placeholder
    await this.writeFile(
      path.join(bpDir, 'BP_GameMode.uasset'),
      'UE5_BLUEPRINT_BINARY_DATA'
    );

    return {
      assets: [
        { name: 'BP_GameMode', type: 'blueprint', path: path.join(bpDir, 'BP_GameMode.uasset'), status: 'completed' },
      ],
    };
  }

  async generateCharacterBlueprint(bpDir, project) {
    const characterBP = {
      name: 'BP_PlayerCharacter',
      type: 'Character',
      parent: '/Script/Engine.Character',
      components: [
        { name: 'Mesh', type: 'SkeletalMesh', mesh: '/Game/Meshes/SK_Player', relativeLocation: { x: 0, y: 0, z: -90 } },
        { name: 'Camera', type: 'CameraComponent', relativeLocation: { x: 0, y: 0, z: 60 } },
        { name: 'SpringArm', type: 'SpringArmComponent', relativeLocation: { x: 0, y: 0, z: 60 }, targetArmLength: 300 },
        { name: 'WeaponSocket', type: 'SceneComponent', relativeLocation: { x: 50, y: 20, z: 40 } },
      ],
      variables: [
        { name: 'Health', type: 'Float', default: 100, category: 'Stats' },
        { name: 'MaxHealth', type: 'Float', default: 100, category: 'Stats' },
        { name: 'Speed', type: 'Float', default: 600, category: 'Movement' },
        { name: 'IsDead', type: 'Bool', default: false, category: 'State' },
        { name: 'CurrentWeapon', type: 'Object', class: 'BP_Weapon', category: 'Combat' },
        { name: 'Inventory', type: 'Array', elementType: 'Object', category: 'Inventory' },
      ],
      events: {
        'Event BeginPlay': {
          nodes: [
            { type: 'EventBeginPlay', outputs: ['Exec'] },
            { type: 'InitializeHealth', inputs: ['Exec'] },
            { type: 'SetupInput', inputs: ['Exec'] },
          ],
        },
        'Event Tick': {
          nodes: [
            { type: 'EventTick', outputs: ['Exec', 'DeltaTime'] },
            { type: 'UpdateMovement', inputs: ['Exec', 'DeltaTime'] },
            { type: 'CheckHealth', inputs: ['Exec'] },
          ],
        },
        'Input MoveForward': {
          nodes: [
            { type: 'InputAxis', axisName: 'MoveForward', outputs: ['Exec', 'AxisValue'] },
            { type: 'AddMovementInput', inputs: ['Exec', 'WorldDirection', 'ScaleValue'], params: { WorldDirection: 'ForwardVector' } },
          ],
        },
        'Input MoveRight': {
          nodes: [
            { type: 'InputAxis', axisName: 'MoveRight', outputs: ['Exec', 'AxisValue'] },
            { type: 'AddMovementInput', inputs: ['Exec', 'WorldDirection', 'ScaleValue'], params: { WorldDirection: 'RightVector' } },
          ],
        },
        'Input Jump': {
          nodes: [
            { type: 'InputAction', actionName: 'Jump', outputs: ['Pressed', 'Released'] },
            { type: 'Jump', inputs: ['Pressed'] },
            { type: 'StopJumping', inputs: ['Released'] },
          ],
        },
        'Input Fire': {
          nodes: [
            { type: 'InputAction', actionName: 'Fire', outputs: ['Pressed', 'Released'] },
            { type: 'FireWeapon', inputs: ['Pressed'] },
            { type: 'StopFiring', inputs: ['Released'] },
          ],
        },
        'Input Reload': {
          nodes: [
            { type: 'InputAction', actionName: 'Reload', outputs: ['Pressed'] },
            { type: 'ReloadWeapon', inputs: ['Pressed'] },
          ],
        },
        'Input Aim': {
          nodes: [
            { type: 'InputAction', actionName: 'Aim', outputs: ['Pressed', 'Released'] },
            { type: 'SetAiming', inputs: ['Pressed'], params: { Aiming: true } },
            { type: 'SetAiming', inputs: ['Released'], params: { Aiming: false } },
          ],
        },
        'Input Interact': {
          nodes: [
            { type: 'InputAction', actionName: 'Interact', outputs: ['Pressed'] },
            { type: 'LineTrace', inputs: ['Pressed'], params: { Distance: 200 } },
            { type: 'InteractWithHit', inputs: ['Exec', 'HitResult'] },
          ],
        },
        'TakeDamage': {
          nodes: [
            { type: 'CustomEvent', name: 'TakeDamage', outputs: ['Exec', 'Damage'] },
            { type: 'SubtractFloat', inputs: ['Health', 'Damage'], outputs: ['NewHealth'] },
            { type: 'SetHealth', inputs: ['Exec', 'NewHealth'] },
            { type: 'Branch', inputs: ['Exec', 'Condition'], condition: 'NewHealth <= 0' },
            { type: 'Die', inputs: ['True'] },
            { type: 'PlayDamageEffect', inputs: ['False'] },
          ],
        },
        'Die': {
          nodes: [
            { type: 'CustomEvent', name: 'Die', outputs: ['Exec'] },
            { type: 'SetIsDead', inputs: ['Exec'], params: { IsDead: true } },
            { type: 'Ragdoll', inputs: ['Exec'] },
            { type: 'DisableInput', inputs: ['Exec'] },
            { type: 'StartRespawnTimer', inputs: ['Exec'], params: { Delay: 5 } },
          ],
        },
        'Respawn': {
          nodes: [
            { type: 'CustomEvent', name: 'Respawn', outputs: ['Exec'] },
            { type: 'ResetHealth', inputs: ['Exec'] },
            { type: 'TeleportToSpawn', inputs: ['Exec'] },
            { type: 'EnableInput', inputs: ['Exec'] },
            { type: 'SetIsDead', inputs: ['Exec'], params: { IsDead: false } },
          ],
        },
      },
      functions: [
        { name: 'InitializeHealth', inputs: ['Exec'], outputs: ['Exec'], nodes: [
          { type: 'SetVariable', variable: 'Health', value: 'MaxHealth' },
        ]},
        { name: 'FireWeapon', inputs: ['Exec'], outputs: ['Exec'], nodes: [
          { type: 'GetCurrentWeapon', outputs: ['Weapon'] },
          { type: 'Branch', condition: 'Weapon != null' },
          { type: 'WeaponFire', inputs: ['True', 'Weapon'] },
          { type: 'PlayEmptySound', inputs: ['False'] },
        ]},
        { name: 'ReloadWeapon', inputs: ['Exec'], outputs: ['Exec'], nodes: [
          { type: 'PlayReloadAnimation', inputs: ['Exec'] },
          { type: 'Delay', inputs: ['Exec'], params: { Duration: 1.5 } },
          { type: 'RefillAmmo', inputs: ['Exec'] },
        ]},
      ],
    };

    await this.writeFile(
      path.join(bpDir, 'BP_PlayerCharacter.json'),
      JSON.stringify(characterBP, null, 2)
    );

    await this.writeFile(
      path.join(bpDir, 'BP_PlayerCharacter.uasset'),
      'UE5_BLUEPRINT_BINARY_DATA'
    );

    // Generate PlayerController
    const pcBP = {
      name: 'BP_PlayerController',
      type: 'PlayerController',
      events: {
        'Event OnPossess': {
          nodes: [
            { type: 'EventOnPossess', outputs: ['Exec', 'Pawn'] },
            { type: 'SetupHUD', inputs: ['Exec'] },
            { type: 'ShowMouseCursor', inputs: ['Exec'], params: { ShowCursor: false } },
          ],
        },
      },
    };

    await this.writeFile(
      path.join(bpDir, 'BP_PlayerController.json'),
      JSON.stringify(pcBP, null, 2)
    );

    return {
      assets: [
        { name: 'BP_PlayerCharacter', type: 'blueprint', path: path.join(bpDir, 'BP_PlayerCharacter.uasset'), status: 'completed' },
        { name: 'BP_PlayerController', type: 'blueprint', path: path.join(bpDir, 'BP_PlayerController.uasset'), status: 'completed' },
      ],
    };
  }

  async generateWeaponSystem(bpDir, project) {
    const weapons = [
      { name: 'BP_Rifle', type: 'rifle', damage: 25, fireRate: 0.1, ammo: 30, range: 5000 },
      { name: 'BP_Pistol', type: 'pistol', damage: 15, fireRate: 0.2, ammo: 12, range: 2000 },
      { name: 'BP_Shotgun', type: 'shotgun', damage: 80, fireRate: 1.0, ammo: 8, range: 1500 },
      { name: 'BP_Sniper', type: 'sniper', damage: 100, fireRate: 2.0, ammo: 5, range: 10000 },
    ];

    const assets = [];

    for (const weapon of weapons) {
      const weaponBP = {
        name: weapon.name,
        type: 'Actor',
        variables: [
          { name: 'Damage', type: 'Float', default: weapon.damage },
          { name: 'FireRate', type: 'Float', default: weapon.fireRate },
          { name: 'MaxAmmo', type: 'Int', default: weapon.ammo },
          { name: 'CurrentAmmo', type: 'Int', default: weapon.ammo },
          { name: 'Range', type: 'Float', default: weapon.range },
          { name: 'IsFiring', type: 'Bool', default: false },
        ],
        events: {
          'Fire': {
            nodes: [
              { type: 'CustomEvent', name: 'Fire', outputs: ['Exec'] },
              { type: 'Branch', condition: 'CurrentAmmo > 0 && !IsFiring' },
              { type: 'SetIsFiring', inputs: ['True'], params: { IsFiring: true } },
              { type: 'LineTrace', inputs: ['Exec'], params: { Distance: weapon.range } },
              { type: 'ApplyDamage', inputs: ['Exec', 'HitActor'], params: { Damage: weapon.damage } },
              { type: 'DecrementAmmo', inputs: ['Exec'] },
              { type: 'PlayFireEffects', inputs: ['Exec'] },
              { type: 'Delay', inputs: ['Exec'], params: { Duration: weapon.fireRate } },
              { type: 'SetIsFiring', inputs: ['Exec'], params: { IsFiring: false } },
            ],
          },
        },
      };

      await this.writeFile(
        path.join(bpDir, `${weapon.name}.json`),
        JSON.stringify(weaponBP, null, 2)
      );

      await this.writeFile(
        path.join(bpDir, `${weapon.name}.uasset`),
        'UE5_BLUEPRINT_BINARY_DATA'
      );

      assets.push({
        name: weapon.name,
        type: 'blueprint',
        path: path.join(bpDir, `${weapon.name}.uasset`),
        status: 'completed',
      });
    }

    return { assets };
  }

  async generateHUD(bpDir, project) {
    const hudBP = {
      name: 'BP_HUD',
      type: 'HUD',
      widgets: [
        {
          name: 'WBP_MainHUD',
          elements: [
            { type: 'HealthBar', position: { x: 20, y: 20 }, size: { x: 300, y: 20 }, binding: 'Health/MaxHealth' },
            { type: 'AmmoCounter', position: { x: 20, y: 50 }, binding: 'CurrentAmmo/MaxAmmo' },
            { type: 'Crosshair', position: { center: true }, size: { x: 20, y: 20 } },
            { type: 'Minimap', position: { x: -150, y: 20 }, anchor: 'TopRight', size: { x: 150, y: 150 } },
            { type: 'KillFeed', position: { x: -300, y: 100 }, anchor: 'TopRight', size: { x: 280, y: 200 } },
            { type: 'WeaponIcon', position: { x: 20, y: 80 }, size: { x: 64, y: 64 } },
            { type: 'ScoreBoard', position: { center: true }, visible: false },
            { type: 'ChatBox', position: { x: 20, y: -200 }, anchor: 'BottomLeft', size: { x: 400, y: 180 } },
          ],
        },
        {
          name: 'WBP_MainMenu',
          elements: [
            { type: 'Background', image: '/Game/Textures/T_MenuBG' },
            { type: 'Title', text: project.name, position: { center: true, y: 100 }, fontSize: 48 },
            { type: 'Button', text: 'Play', position: { center: true, y: 250 }, action: 'StartGame' },
            { type: 'Button', text: 'Settings', position: { center: true, y: 310 }, action: 'OpenSettings' },
            { type: 'Button', text: 'Quit', position: { center: true, y: 370 }, action: 'QuitGame' },
          ],
        },
        {
          name: 'WBP_PauseMenu',
          elements: [
            { type: 'Background', color: 'rgba(0,0,0,0.7)' },
            { type: 'Button', text: 'Resume', action: 'ResumeGame' },
            { type: 'Button', text: 'Settings', action: 'OpenSettings' },
            { type: 'Button', text: 'Quit to Menu', action: 'QuitToMenu' },
          ],
        },
        {
          name: 'WBP_Settings',
          elements: [
            { type: 'Slider', label: 'Graphics Quality', min: 0, max: 3, default: 2, binding: 'GraphicsQuality' },
            { type: 'Slider', label: 'Sensitivity', min: 0.1, max: 5, default: 1, binding: 'MouseSensitivity' },
            { type: 'Toggle', label: 'VSync', default: true, binding: 'VSync' },
            { type: 'Toggle', label: 'Fullscreen', default: true, binding: 'Fullscreen' },
            { type: 'Slider', label: 'Volume', min: 0, max: 100, default: 80, binding: 'MasterVolume' },
            { type: 'Button', text: 'Apply', action: 'ApplySettings' },
            { type: 'Button', text: 'Back', action: 'BackToMenu' },
          ],
        },
      ],
    };

    await this.writeFile(
      path.join(bpDir, 'BP_HUD.json'),
      JSON.stringify(hudBP, null, 2)
    );

    // Generate GameState
    const gsBP = {
      name: 'BP_GameState',
      type: 'GameStateBase',
      variables: [
        { name: 'MatchTime', type: 'Float', default: 600 },
        { name: 'ScoreLimit', type: 'Int', default: 50 },
        { name: 'CurrentRound', type: 'Int', default: 1 },
        { name: 'MatchState', type: 'Enum', values: ['Waiting', 'InProgress', 'Ended'], default: 'Waiting' },
      ],
      events: {
        'StartMatch': {
          nodes: [
            { type: 'CustomEvent', name: 'StartMatch', outputs: ['Exec'] },
            { type: 'SetMatchState', inputs: ['Exec'], params: { State: 'InProgress' } },
            { type: 'StartTimer', inputs: ['Exec'] },
          ],
        },
        'EndMatch': {
          nodes: [
            { type: 'CustomEvent', name: 'EndMatch', outputs: ['Exec'] },
            { type: 'SetMatchState', inputs: ['Exec'], params: { State: 'Ended' } },
            { type: 'ShowEndScreen', inputs: ['Exec'] },
          ],
        },
      },
    };

    await this.writeFile(
      path.join(bpDir, 'BP_GameState.json'),
      JSON.stringify(gsBP, null, 2)
    );

    return {
      assets: [
        { name: 'BP_HUD', type: 'blueprint', path: path.join(bpDir, 'BP_HUD.uasset'), status: 'completed' },
        { name: 'BP_GameState', type: 'blueprint', path: path.join(bpDir, 'BP_GameState.uasset'), status: 'completed' },
        { name: 'WBP_MainHUD', type: 'ui', path: path.join(bpDir, 'WBP_MainHUD.uasset'), status: 'completed' },
        { name: 'WBP_MainMenu', type: 'ui', path: path.join(bpDir, 'WBP_MainMenu.uasset'), status: 'completed' },
      ],
    };
  }

  async generateGenericBlueprint(bpDir, task, project) {
    const genericBP = {
      name: `BP_${task.type}`,
      type: 'Actor',
      generatedBy: this.name,
      timestamp: new Date().toISOString(),
    };

    await this.writeFile(
      path.join(bpDir, `BP_${task.type}.json`),
      JSON.stringify(genericBP, null, 2)
    );

    return {
      assets: [
        { name: `BP_${task.type}`, type: 'blueprint', path: path.join(bpDir, `BP_${task.type}.uasset`), status: 'completed' },
      ],
    };
  }
}

module.exports = BlueprintAgent;
