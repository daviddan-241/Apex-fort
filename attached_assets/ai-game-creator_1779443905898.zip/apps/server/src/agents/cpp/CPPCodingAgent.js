const BaseAgent = require('../BaseAgent');
const path = require('path');

class CPPCodingAgent extends BaseAgent {
  constructor(id, name, role, color, orchestrator) {
    super(id, name, role, color, orchestrator);
  }

  async processTask(task, project) {
    const projectDir = path.join(process.env.PROJECTS_DIR || './projects', project.id);
    const sourceDir = path.join(projectDir, 'Source', project.name);

    this.emitLog(project.id, 'info', `Generating C++ code: ${task.type}`);

    let result;
    switch (task.type) {
      case 'core_systems':
        result = await this.generateCoreSystems(sourceDir, project);
        break;
      case 'ai_system':
        result = await this.generateAISystem(sourceDir, project);
        break;
      default:
        result = await this.generateGenericCPP(sourceDir, task, project);
    }

    this.emitLog(project.id, 'success', `C++ code generated: ${task.type}`);
    return result;
  }

  async generateCoreSystems(sourceDir, project) {
    // Generate main game module
    const gameModule = this.generateGameModule(project);
    await this.writeFile(
      path.join(sourceDir, `${project.name}.Build.cs`),
      gameModule
    );

    // Generate main game class
    const gameClass = this.generateGameClass(project);
    await this.writeFile(
      path.join(sourceDir, `Public/${project.name}GameMode.h`),
      gameClass.header
    );
    await this.writeFile(
      path.join(sourceDir, `Private/${project.name}GameMode.cpp`),
      gameClass.source
    );

    // Generate character class
    const charClass = this.generateCharacterClass(project);
    await this.writeFile(
      path.join(sourceDir, 'Public/PlayerCharacter.h'),
      charClass.header
    );
    await this.writeFile(
      path.join(sourceDir, 'Private/PlayerCharacter.cpp'),
      charClass.source
    );

    // Generate weapon system
    const weaponClass = this.generateWeaponClass(project);
    await this.writeFile(
      path.join(sourceDir, 'Public/WeaponBase.h'),
      weaponClass.header
    );
    await this.writeFile(
      path.join(sourceDir, 'Private/WeaponBase.cpp'),
      weaponClass.source
    );

    // Generate health component
    const healthComp = this.generateHealthComponent();
    await this.writeFile(
      path.join(sourceDir, 'Public/HealthComponent.h'),
      healthComp.header
    );
    await this.writeFile(
      path.join(sourceDir, 'Private/HealthComponent.cpp'),
      healthComp.source
    );

    // Generate inventory system
    const inventory = this.generateInventorySystem();
    await this.writeFile(
      path.join(sourceDir, 'Public/InventoryComponent.h'),
      inventory.header
    );
    await this.writeFile(
      path.join(sourceDir, 'Private/InventoryComponent.cpp'),
      inventory.source
    );

    // Generate save system
    const saveSystem = this.generateSaveSystem();
    await this.writeFile(
      path.join(sourceDir, 'Public/SaveGameData.h'),
      saveSystem.header
    );
    await this.writeFile(
      path.join(sourceDir, 'Private/SaveGameData.cpp'),
      saveSystem.source
    );

    // Generate network component for multiplayer
    if (project.multiplayer) {
      const networkComp = this.generateNetworkComponent();
      await this.writeFile(
        path.join(sourceDir, 'Public/NetworkComponent.h'),
        networkComp.header
      );
      await this.writeFile(
        path.join(sourceDir, 'Private/NetworkComponent.cpp'),
        networkComp.source
      );
    }

    return {
      assets: [
        { name: `${project.name}GameMode`, type: 'cpp', path: path.join(sourceDir, `Public/${project.name}GameMode.h`), status: 'completed' },
        { name: 'PlayerCharacter', type: 'cpp', path: path.join(sourceDir, 'Public/PlayerCharacter.h'), status: 'completed' },
        { name: 'WeaponBase', type: 'cpp', path: path.join(sourceDir, 'Public/WeaponBase.h'), status: 'completed' },
        { name: 'HealthComponent', type: 'cpp', path: path.join(sourceDir, 'Public/HealthComponent.h'), status: 'completed' },
        { name: 'InventoryComponent', type: 'cpp', path: path.join(sourceDir, 'Public/InventoryComponent.h'), status: 'completed' },
        { name: 'SaveGameData', type: 'cpp', path: path.join(sourceDir, 'Public/SaveGameData.h'), status: 'completed' },
      ],
    };
  }

  generateGameModule(project) {
    return `using UnrealBuildTool;

public class ${project.name} : ModuleRules
{
    public ${project.name}(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

        PublicDependencyModuleNames.AddRange(new string[] {
            "Core",
            "CoreUObject",
            "Engine",
            "InputCore",
            "EnhancedInput",
            "GameplayAbilities",
            "GameplayTags",
            "GameplayTasks",
            "UMG",
            "OnlineSubsystem",
            "OnlineSubsystemUtils",
            "Networking",
            "Sockets",
            "PhysicsCore",
            "Niagara",
            "MediaAssets",
            "AudioMixer",
            "LevelSequence",
            "MoviePlayer",
            "CinematicCamera",
            "Landscape",
            "Foliage",
            "ProceduralMeshComponent",
        });

        PrivateDependencyModuleNames.AddRange(new string[] {
            "Projects",
            "RenderCore",
            "RHI",
            "AssetRegistry",
            "ImageWriteQueue",
        });

        // Mobile optimizations
        if (Target.Platform == UnrealTargetPlatform.Android || Target.Platform == UnrealTargetPlatform.IOS)
        {
            PublicDefinitions.Add("MOBILE_BUILD=1");
            PublicDefinitions.Add("USE_LUMEN_MOBILE=1");
            PublicDefinitions.Add("USE_NANITE_MOBILE=1");
            PublicDefinitions.Add("MAX_MOBILE_DRAW_CALLS=500");
        }

        // Enable ray tracing for supported platforms
        if (Target.Platform == UnrealTargetPlatform.Win64)
        {
            PublicDefinitions.Add("WITH_RAY_TRACING=1");
        }

        // VR support
        PublicDefinitions.Add("WITH_VR_SUPPORT=1");

        bUseUnity = true;
        bUsePCHFiles = true;
    }
}`;
  }

  generateGameClass(project) {
    const header = `#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "${project.name}GameMode.generated.h"

UCLASS()
class ${project.name.toUpperCase()}_API A${project.name}GameMode : public AGameModeBase
{
    GENERATED_BODY()

public:
    A${project.name}GameMode();

    virtual void BeginPlay() override;
    virtual void Tick(float DeltaTime) override;
    virtual void PostLogin(APlayerController* NewPlayer) override;
    virtual void Logout(AController* ExitingPlayer) override;

    // Match management
    UFUNCTION(BlueprintCallable, Category = "Game Mode")
    void StartMatch();

    UFUNCTION(BlueprintCallable, Category = "Game Mode")
    void EndMatch();

    UFUNCTION(BlueprintCallable, Category = "Game Mode")
    void RestartMatch();

    // Player management
    UFUNCTION(BlueprintCallable, Category = "Game Mode")
    void SpawnPlayer(APlayerController* Controller);

    UFUNCTION(BlueprintCallable, Category = "Game Mode")
    void RespawnPlayer(APlayerController* Controller);

    // Game state
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Game Settings")
    float MatchDuration;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Game Settings")
    int32 ScoreLimit;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Game Settings")
    int32 MaxPlayers;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Game Settings")
    bool bAllowRespawn;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Game Settings")
    float RespawnDelay;

    UPROPERTY(Replicated, BlueprintReadOnly, Category = "Game State")
    float MatchTimeRemaining;

    UPROPERTY(Replicated, BlueprintReadOnly, Category = "Game State")
    EMatchState CurrentMatchState;

    UPROPERTY(Replicated, BlueprintReadOnly, Category = "Game State")
    int32 CurrentRound;

    // Events
    UFUNCTION(BlueprintImplementableEvent, Category = "Events")
    void OnMatchStarted();

    UFUNCTION(BlueprintImplementableEvent, Category = "Events")
    void OnMatchEnded();

    UFUNCTION(BlueprintImplementableEvent, Category = "Events")
    void OnPlayerJoined(APlayerController* NewPlayer);

    UFUNCTION(BlueprintImplementableEvent, Category = "Events")
    void OnPlayerLeft(APlayerController* LeftPlayer);

protected:
    FTimerHandle MatchTimerHandle;
    FTimerHandle RespawnTimerHandle;

    void UpdateMatchTimer();
    void CheckWinCondition();
    void HandleMatchTimeout();

    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
};

UENUM(BlueprintType)
enum class EMatchState : uint8
{
    Waiting     UMETA(DisplayName = "Waiting"),
    InProgress  UMETA(DisplayName = "In Progress"),
    Ended       UMETA(DisplayName = "Ended"),
    Paused      UMETA(DisplayName = "Paused")
};`;

    const source = `#include "${project.name}GameMode.h"
#include "PlayerCharacter.h"
#include "Engine/World.h"
#include "GameFramework/PlayerStart.h"
#include "GameFramework/PlayerController.h"
#include "Kismet/GameplayStatics.h"
#include "TimerManager.h"

A${project.name}GameMode::A${project.name}GameMode()
{
    MatchDuration = 600.0f;
    ScoreLimit = 50;
    MaxPlayers = 16;
    bAllowRespawn = true;
    RespawnDelay = 5.0f;
    MatchTimeRemaining = MatchDuration;
    CurrentMatchState = EMatchState::Waiting;
    CurrentRound = 1;

    // Set default classes
    DefaultPawnClass = APlayerCharacter::StaticClass();
    PlayerControllerClass = APlayerController::StaticClass();
}

void A${project.name}GameMode::BeginPlay()
{
    Super::BeginPlay();

    UE_LOG(LogTemp, Log, TEXT("${project.name} Game Mode Initialized"));

    // Initialize game systems
    if (HasAuthority())
    {
        GetWorld()->GetTimerManager().SetTimer(
            MatchTimerHandle,
            this,
            &A${project.name}GameMode::UpdateMatchTimer,
            1.0f,
            true
        );
    }
}

void A${project.name}GameMode::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);

    if (CurrentMatchState == EMatchState::InProgress)
    {
        CheckWinCondition();
    }
}

void A${project.name}GameMode::PostLogin(APlayerController* NewPlayer)
{
    Super::PostLogin(NewPlayer);

    OnPlayerJoined(NewPlayer);

    if (CurrentMatchState == EMatchState::Waiting && GetNumPlayers() >= 2)
    {
        StartMatch();
    }
}

void A${project.name}GameMode::Logout(AController* ExitingPlayer)
{
    Super::Logout(ExitingPlayer);

    if (APlayerController* PC = Cast<APlayerController>(ExitingPlayer))
    {
        OnPlayerLeft(PC);
    }
}

void A${project.name}GameMode::StartMatch()
{
    if (CurrentMatchState != EMatchState::Waiting)
        return;

    CurrentMatchState = EMatchState::InProgress;
    MatchTimeRemaining = MatchDuration;

    // Spawn all players
    for (FConstPlayerControllerIterator It = GetWorld()->GetPlayerControllerIterator(); It; ++It)
    {
        if (APlayerController* PC = It->Get())
        {
            SpawnPlayer(PC);
        }
    }

    OnMatchStarted();
    UE_LOG(LogTemp, Log, TEXT("Match Started!"));
}

void A${project.name}GameMode::EndMatch()
{
    if (CurrentMatchState != EMatchState::InProgress)
        return;

    CurrentMatchState = EMatchState::Ended;

    GetWorld()->GetTimerManager().ClearTimer(MatchTimerHandle);

    OnMatchEnded();
    UE_LOG(LogTemp, Log, TEXT("Match Ended!"));
}

void A${project.name}GameMode::RestartMatch()
{
    CurrentRound++;
    CurrentMatchState = EMatchState::Waiting;
    MatchTimeRemaining = MatchDuration;

    // Respawn all players
    for (FConstPlayerControllerIterator It = GetWorld()->GetPlayerControllerIterator(); It; ++It)
    {
        if (APlayerController* PC = It->Get())
        {
            RespawnPlayer(PC);
        }
    }
}

void A${project.name}GameMode::SpawnPlayer(APlayerController* Controller)
{
    if (!Controller) return;

    // Find a player start
    TArray<AActor*> PlayerStarts;
    UGameplayStatics::GetAllActorsOfClass(GetWorld(), APlayerStart::StaticClass(), PlayerStarts);

    if (PlayerStarts.Num() > 0)
    {
        int32 Index = FMath::RandRange(0, PlayerStarts.Num() - 1);
        APlayerStart* Start = Cast<APlayerStart>(PlayerStarts[Index]);

        FActorSpawnParameters SpawnParams;
        SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

        APlayerCharacter* Character = GetWorld()->SpawnActor<APlayerCharacter>(
            DefaultPawnClass,
            Start->GetActorLocation(),
            Start->GetActorRotation(),
            SpawnParams
        );

        if (Character)
        {
            Controller->Possess(Character);
        }
    }
}

void A${project.name}GameMode::RespawnPlayer(APlayerController* Controller)
{
    if (!bAllowRespawn || !Controller) return;

    FTimerHandle RespawnHandle;
    FTimerDelegate RespawnDelegate;
    RespawnDelegate.BindUFunction(this, FName("SpawnPlayer"), Controller);

    GetWorld()->GetTimerManager().SetTimer(
        RespawnHandle,
        RespawnDelegate,
        RespawnDelay,
        false
    );
}

void A${project.name}GameMode::UpdateMatchTimer()
{
    if (CurrentMatchState != EMatchState::InProgress)
        return;

    MatchTimeRemaining -= 1.0f;

    if (MatchTimeRemaining <= 0)
    {
        HandleMatchTimeout();
    }
}

void A${project.name}GameMode::CheckWinCondition()
{
    // Implement win condition logic based on game mode
    // This is a placeholder - override in subclasses
}

void A${project.name}GameMode::HandleMatchTimeout()
{
    EndMatch();
}

void A${project.name}GameMode::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
    Super::GetLifetimeReplicatedProps(OutLifetimeProps);

    DOREPLIFETIME(A${project.name}GameMode, MatchTimeRemaining);
    DOREPLIFETIME(A${project.name}GameMode, CurrentMatchState);
    DOREPLIFETIME(A${project.name}GameMode, CurrentRound);
}`;

    return { header, source };
  }

  generateCharacterClass(project) {
    const header = `#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "PlayerCharacter.generated.h"

UCLASS()
class ${project.name.toUpperCase()}_API APlayerCharacter : public ACharacter
{
    GENERATED_BODY()

public:
    APlayerCharacter();

    virtual void BeginPlay() override;
    virtual void Tick(float DeltaTime) override;
    virtual void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;
    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

    // Camera
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Camera")
    class USpringArmComponent* CameraBoom;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Camera")
    class UCameraComponent* FollowCamera;

    // Combat
    UFUNCTION(BlueprintCallable, Category = "Combat")
    void FireWeapon();

    UFUNCTION(BlueprintCallable, Category = "Combat")
    void StopFiring();

    UFUNCTION(BlueprintCallable, Category = "Combat")
    void ReloadWeapon();

    UFUNCTION(BlueprintCallable, Category = "Combat")
    void StartAiming();

    UFUNCTION(BlueprintCallable, Category = "Combat")
    void StopAiming();

    UFUNCTION(Server, Reliable, WithValidation)
    void Server_FireWeapon();

    UFUNCTION(Server, Reliable, WithValidation)
    void Server_ReloadWeapon();

    // Health
    UPROPERTY(ReplicatedUsing = OnRep_Health, EditDefaultsOnly, BlueprintReadOnly, Category = "Stats")
    float Health;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Stats")
    float MaxHealth;

    UFUNCTION()
    void OnRep_Health();

    UFUNCTION(BlueprintCallable, Category = "Health")
    void TakeDamage(float Damage, AActor* DamageCauser);

    UFUNCTION(BlueprintCallable, Category = "Health")
    void Heal(float Amount);

    UFUNCTION(BlueprintCallable, Category = "Health")
    bool IsDead() const;

    UFUNCTION(BlueprintImplementableEvent, Category = "Events")
    void OnDeath();

    UFUNCTION(BlueprintImplementableEvent, Category = "Events")
    void OnHealthChanged(float NewHealth, float MaxHealth);

    // Movement
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Movement")
    float WalkSpeed;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Movement")
    float SprintSpeed;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Movement")
    float CrouchSpeed;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Movement")
    float JumpHeight;

    UFUNCTION(BlueprintCallable, Category = "Movement")
    void Sprint();

    UFUNCTION(BlueprintCallable, Category = "Movement")
    void StopSprinting();

    UFUNCTION(BlueprintCallable, Category = "Movement")
    void Crouch();

    UFUNCTION(BlueprintCallable, Category = "Movement")
    void StopCrouching();

    // Inventory
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Inventory")
    class UInventoryComponent* InventoryComponent;

    UFUNCTION(BlueprintCallable, Category = "Inventory")
    void Interact();

    UFUNCTION(BlueprintCallable, Category = "Inventory")
    void DropItem();

    // Animation
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Animation")
    class UAnimInstance* AnimInstance;

    UPROPERTY(BlueprintReadOnly, Category = "Animation")
    bool bIsAiming;

    UPROPERTY(BlueprintReadOnly, Category = "Animation")
    bool bIsFiring;

    UPROPERTY(BlueprintReadOnly, Category = "Animation")
    bool bIsReloading;

    UPROPERTY(BlueprintReadOnly, Category = "Animation")
    bool bIsSprinting;

    UPROPERTY(BlueprintReadOnly, Category = "Animation")
    bool bIsCrouching;

protected:
    void MoveForward(float Value);
    void MoveRight(float Value);
    void Turn(float Value);
    void LookUp(float Value);
    void StartJump();
    void StopJump();

    UPROPERTY(EditDefaultsOnly, Category = "Combat")
    TSubclassOf<class AWeaponBase> DefaultWeaponClass;

    UPROPERTY(Replicated)
    class AWeaponBase* CurrentWeapon;

    FTimerHandle FireTimerHandle;
    bool bWantsToFire;

    void HandleFiring();
    void PerformLineTrace();
};`;

    const source = `#include "PlayerCharacter.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Components/CapsuleComponent.h"
#include "WeaponBase.h"
#include "Net/UnrealNetwork.h"
#include "Engine/World.h"

APlayerCharacter::APlayerCharacter()
{
    PrimaryActorTick.bCanEverTick = true;

    // Set size for collision
    GetCapsuleComponent()->InitCapsuleSize(42.0f, 96.0f);

    // Configure movement
    GetCharacterMovement()->bOrientRotationToMovement = true;
    GetCharacterMovement()->RotationRate = FRotator(0.0f, 540.0f, 0.0f);
    GetCharacterMovement()->JumpZVelocity = 600.0f;
    GetCharacterMovement()->AirControl = 0.2f;

    // Camera boom
    CameraBoom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
    CameraBoom->SetupAttachment(RootComponent);
    CameraBoom->TargetArmLength = 300.0f;
    CameraBoom->bUsePawnControlRotation = true;

    // Follow camera
    FollowCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("FollowCamera"));
    FollowCamera->SetupAttachment(CameraBoom, USpringArmComponent::SocketName);
    FollowCamera->bUsePawnControlRotation = false;

    // Stats
    MaxHealth = 100.0f;
    Health = MaxHealth;
    WalkSpeed = 600.0f;
    SprintSpeed = 1200.0f;
    CrouchSpeed = 300.0f;
    JumpHeight = 600.0f;

    // State
    bIsAiming = false;
    bIsFiring = false;
    bIsReloading = false;
    bIsSprinting = false;
    bIsCrouching = false;
    bWantsToFire = false;

    // Replication
    bReplicates = true;
    SetReplicateMovement(true);
}

void APlayerCharacter::BeginPlay()
{
    Super::BeginPlay();

    // Spawn default weapon
    if (HasAuthority() && DefaultWeaponClass)
    {
        FActorSpawnParameters SpawnParams;
        SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

        CurrentWeapon = GetWorld()->SpawnActor<AWeaponBase>(DefaultWeaponClass, SpawnParams);
        if (CurrentWeapon)
        {
            CurrentWeapon->SetOwner(this);
            CurrentWeapon->AttachToComponent(GetMesh(), FAttachmentTransformRules::SnapToTargetNotIncludingScale, TEXT("WeaponSocket"));
        }
    }
}

void APlayerCharacter::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);

    if (bWantsToFire && CurrentWeapon && !bIsReloading)
    {
        HandleFiring();
    }
}

void APlayerCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
    Super::SetupPlayerInputComponent(PlayerInputComponent);

    PlayerInputComponent->BindAxis("MoveForward", this, &APlayerCharacter::MoveForward);
    PlayerInputComponent->BindAxis("MoveRight", this, &APlayerCharacter::MoveRight);
    PlayerInputComponent->BindAxis("Turn", this, &APlayerCharacter::Turn);
    PlayerInputComponent->BindAxis("LookUp", this, &APlayerCharacter::LookUp);

    PlayerInputComponent->BindAction("Jump", IE_Pressed, this, &APlayerCharacter::StartJump);
    PlayerInputComponent->BindAction("Jump", IE_Released, this, &APlayerCharacter::StopJump);
    PlayerInputComponent->BindAction("Sprint", IE_Pressed, this, &APlayerCharacter::Sprint);
    PlayerInputComponent->BindAction("Sprint", IE_Released, this, &APlayerCharacter::StopSprinting);
    PlayerInputComponent->BindAction("Crouch", IE_Pressed, this, &APlayerCharacter::Crouch);
    PlayerInputComponent->BindAction("Crouch", IE_Released, this, &APlayerCharacter::StopCrouching);
    PlayerInputComponent->BindAction("Fire", IE_Pressed, this, &APlayerCharacter::FireWeapon);
    PlayerInputComponent->BindAction("Fire", IE_Released, this, &APlayerCharacter::StopFiring);
    PlayerInputComponent->BindAction("Reload", IE_Pressed, this, &APlayerCharacter::ReloadWeapon);
    PlayerInputComponent->BindAction("Aim", IE_Pressed, this, &APlayerCharacter::StartAiming);
    PlayerInputComponent->BindAction("Aim", IE_Released, this, &APlayerCharacter::StopAiming);
    PlayerInputComponent->BindAction("Interact", IE_Pressed, this, &APlayerCharacter::Interact);
}

void APlayerCharacter::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
    Super::GetLifetimeReplicatedProps(OutLifetimeProps);

    DOREPLIFETIME(APlayerCharacter, Health);
    DOREPLIFETIME(APlayerCharacter, CurrentWeapon);
}

void APlayerCharacter::MoveForward(float Value)
{
    if (Controller && Value != 0.0f)
    {
        const FRotator Rotation = Controller->GetControlRotation();
        const FRotator YawRotation(0, Rotation.Yaw, 0);
        const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X);
        AddMovementInput(Direction, Value);
    }
}

void APlayerCharacter::MoveRight(float Value)
{
    if (Controller && Value != 0.0f)
    {
        const FRotator Rotation = Controller->GetControlRotation();
        const FRotator YawRotation(0, Rotation.Yaw, 0);
        const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::Y);
        AddMovementInput(Direction, Value);
    }
}

void APlayerCharacter::Turn(float Value)
{
    AddControllerYawInput(Value);
}

void APlayerCharacter::LookUp(float Value)
{
    AddControllerPitchInput(Value);
}

void APlayerCharacter::StartJump()
{
    Jump();
}

void APlayerCharacter::StopJump()
{
    StopJumping();
}

void APlayerCharacter::Sprint()
{
    bIsSprinting = true;
    GetCharacterMovement()->MaxWalkSpeed = SprintSpeed;
}

void APlayerCharacter::StopSprinting()
{
    bIsSprinting = false;
    GetCharacterMovement()->MaxWalkSpeed = bIsCrouching ? CrouchSpeed : WalkSpeed;
}

void APlayerCharacter::Crouch()
{
    bIsCrouching = true;
    GetCharacterMovement()->MaxWalkSpeed = CrouchSpeed;
    GetCharacterMovement()->NavAgentProps.bCanCrouch = true;
    Super::Crouch();
}

void APlayerCharacter::StopCrouching()
{
    bIsCrouching = false;
    GetCharacterMovement()->MaxWalkSpeed = WalkSpeed;
    Super::UnCrouch();
}

void APlayerCharacter::FireWeapon()
{
    bWantsToFire = true;

    if (GetLocalRole() < ROLE_Authority)
    {
        Server_FireWeapon();
    }
}

void APlayerCharacter::StopFiring()
{
    bWantsToFire = false;
    bIsFiring = false;
}

void APlayerCharacter::ReloadWeapon()
{
    if (bIsReloading || !CurrentWeapon) return;

    bIsReloading = true;

    if (GetLocalRole() < ROLE_Authority)
    {
        Server_ReloadWeapon();
    }

    // Play reload animation
    GetWorld()->GetTimerManager().SetTimer(
        FireTimerHandle,
        [this]() { bIsReloading = false; },
        1.5f,
        false
    );
}

void APlayerCharacter::StartAiming()
{
    bIsAiming = true;
    CameraBoom->TargetArmLength = 150.0f;
}

void APlayerCharacter::StopAiming()
{
    bIsAiming = false;
    CameraBoom->TargetArmLength = 300.0f;
}

void APlayerCharacter::Server_FireWeapon_Implementation()
{
    FireWeapon();
}

bool APlayerCharacter::Server_FireWeapon_Validate()
{
    return true;
}

void APlayerCharacter::Server_ReloadWeapon_Implementation()
{
    ReloadWeapon();
}

bool APlayerCharacter::Server_ReloadWeapon_Validate()
{
    return true;
}

void APlayerCharacter::HandleFiring()
{
    if (!CurrentWeapon || bIsReloading) return;

    bIsFiring = true;
    PerformLineTrace();

    // Apply fire rate delay
    bWantsToFire = false;
    GetWorld()->GetTimerManager().SetTimer(
        FireTimerHandle,
        [this]() { bWantsToFire = true; },
        CurrentWeapon->FireRate,
        false
    );
}

void APlayerCharacter::PerformLineTrace()
{
    if (!CurrentWeapon) return;

    FVector Start = FollowCamera->GetComponentLocation();
    FVector End = Start + FollowCamera->GetForwardVector() * CurrentWeapon->Range;

    FHitResult HitResult;
    FCollisionQueryParams QueryParams;
    QueryParams.AddIgnoredActor(this);

    if (GetWorld()->LineTraceSingleByChannel(HitResult, Start, End, ECC_Visibility, QueryParams))
    {
        if (AActor* HitActor = HitResult.GetActor())
        {
            UGameplayStatics::ApplyDamage(HitActor, CurrentWeapon->Damage, GetController(), this, UDamageType::StaticClass());
        }
    }
}

void APlayerCharacter::TakeDamage(float Damage, AActor* DamageCauser)
{
    if (IsDead()) return;

    Health = FMath::Max(0.0f, Health - Damage);
    OnHealthChanged(Health, MaxHealth);

    if (Health <= 0)
    {
        OnDeath();
    }
}

void APlayerCharacter::Heal(float Amount)
{
    Health = FMath::Min(MaxHealth, Health + Amount);
    OnHealthChanged(Health, MaxHealth);
}

bool APlayerCharacter::IsDead() const
{
    return Health <= 0;
}

void APlayerCharacter::OnRep_Health()
{
    OnHealthChanged(Health, MaxHealth);
}

void APlayerCharacter::Interact()
{
    // Line trace for interactable objects
    FVector Start = FollowCamera->GetComponentLocation();
    FVector End = Start + FollowCamera->GetForwardVector() * 200.0f;

    FHitResult HitResult;
    FCollisionQueryParams QueryParams;
    QueryParams.AddIgnoredActor(this);

    if (GetWorld()->LineTraceSingleByChannel(HitResult, Start, End, ECC_Visibility, QueryParams))
    {
        // Handle interaction
    }
}

void APlayerCharacter::DropItem()
{
    // Drop current item
}`;

    return { header, source };
  }

  generateWeaponClass(project) {
    const header = `#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "WeaponBase.generated.h"

UCLASS()
class ${project.name.toUpperCase()}_API AWeaponBase : public AActor
{
    GENERATED_BODY()

public:
    AWeaponBase();

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon")
    float Damage;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon")
    float FireRate;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon")
    int32 MaxAmmo;

    UPROPERTY(Replicated, BlueprintReadOnly, Category = "Weapon")
    int32 CurrentAmmo;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon")
    float Range;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon")
    float ReloadTime;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon")
    USkeletalMeshComponent* WeaponMesh;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Effects")
    UParticleSystem* MuzzleFlash;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Effects")
    USoundBase* FireSound;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Effects")
    USoundBase* ReloadSound;

    UFUNCTION(BlueprintCallable, Category = "Weapon")
    virtual void Fire();

    UFUNCTION(BlueprintCallable, Category = "Weapon")
    virtual void Reload();

    UFUNCTION(BlueprintCallable, Category = "Weapon")
    bool CanFire() const;

    UFUNCTION(BlueprintCallable, Category = "Weapon")
    bool NeedsReload() const;

    UFUNCTION(BlueprintCallable, Category = "Weapon")
    float GetAmmoPercent() const;

    UFUNCTION(BlueprintImplementableEvent, Category = "Events")
    void OnFire();

    UFUNCTION(BlueprintImplementableEvent, Category = "Events")
    void OnReload();

    UFUNCTION(BlueprintImplementableEvent, Category = "Events")
    void OnOutOfAmmo();

protected:
    virtual void BeginPlay() override;
    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

    UPROPERTY(Replicated)
    bool bIsReloading;

    FTimerHandle ReloadTimerHandle;
};`;

    const source = `#include "WeaponBase.h"
#include "Net/UnrealNetwork.h"
#include "Particles/ParticleSystemComponent.h"
#include "Kismet/GameplayStatics.h"

AWeaponBase::AWeaponBase()
{
    PrimaryActorTick.bCanEverTick = false;
    bReplicates = true;

    WeaponMesh = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("WeaponMesh"));
    RootComponent = WeaponMesh;

    Damage = 25.0f;
    FireRate = 0.1f;
    MaxAmmo = 30;
    CurrentAmmo = MaxAmmo;
    Range = 5000.0f;
    ReloadTime = 1.5f;
    bIsReloading = false;
}

void AWeaponBase::BeginPlay()
{
    Super::BeginPlay();
}

void AWeaponBase::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
    Super::GetLifetimeReplicatedProps(OutLifetimeProps);

    DOREPLIFETIME(AWeaponBase, CurrentAmmo);
    DOREPLIFETIME(AWeaponBase, bIsReloading);
}

void AWeaponBase::Fire()
{
    if (!CanFire())
    {
        if (NeedsReload())
        {
            OnOutOfAmmo();
        }
        return;
    }

    CurrentAmmo--;

    // Play effects
    if (MuzzleFlash)
    {
        UGameplayStatics::SpawnEmitterAttached(MuzzleFlash, WeaponMesh, TEXT("MuzzleSocket"));
    }

    if (FireSound)
    {
        UGameplayStatics::PlaySoundAtLocation(GetWorld(), FireSound, GetActorLocation());
    }

    OnFire();
}

void AWeaponBase::Reload()
{
    if (bIsReloading || CurrentAmmo >= MaxAmmo) return;

    bIsReloading = true;

    if (ReloadSound)
    {
        UGameplayStatics::PlaySoundAtLocation(GetWorld(), ReloadSound, GetActorLocation());
    }

    GetWorld()->GetTimerManager().SetTimer(
        ReloadTimerHandle,
        [this]()
        {
            CurrentAmmo = MaxAmmo;
            bIsReloading = false;
            OnReload();
        },
        ReloadTime,
        false
    );
}

bool AWeaponBase::CanFire() const
{
    return CurrentAmmo > 0 && !bIsReloading;
}

bool AWeaponBase::NeedsReload() const
{
    return CurrentAmmo <= 0;
}

float AWeaponBase::GetAmmoPercent() const
{
    return (float)CurrentAmmo / (float)MaxAmmo;
}`;

    return { header, source };
  }

  generateHealthComponent() {
    const header = `#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "HealthComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnHealthChanged, float, NewHealth, float, MaxHealth);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnDeath);

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class UHealthComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    UHealthComponent();

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Health")
    float MaxHealth;

    UPROPERTY(ReplicatedUsing = OnRep_Health, BlueprintReadOnly, Category = "Health")
    float CurrentHealth;

    UPROPERTY(BlueprintAssignable, Category = "Events")
    FOnHealthChanged OnHealthChanged;

    UPROPERTY(BlueprintAssignable, Category = "Events")
    FOnDeath OnDeath;

    UFUNCTION(BlueprintCallable, Category = "Health")
    void TakeDamage(float Damage, AActor* DamageCauser);

    UFUNCTION(BlueprintCallable, Category = "Health")
    void Heal(float Amount);

    UFUNCTION(BlueprintCallable, Category = "Health")
    void SetHealth(float NewHealth);

    UFUNCTION(BlueprintPure, Category = "Health")
    float GetHealthPercent() const;

    UFUNCTION(BlueprintPure, Category = "Health")
    bool IsDead() const;

    UFUNCTION(BlueprintPure, Category = "Health")
    bool IsLowHealth() const;

protected:
    virtual void BeginPlay() override;
    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

    UFUNCTION()
    void OnRep_Health();

    UPROPERTY(EditDefaultsOnly, Category = "Health")
    float LowHealthThreshold;
};`;

    const source = `#include "HealthComponent.h"
#include "Net/UnrealNetwork.h"

UHealthComponent::UHealthComponent()
{
    PrimaryComponentTick.bCanEverTick = false;

    MaxHealth = 100.0f;
    CurrentHealth = MaxHealth;
    LowHealthThreshold = 25.0f;

    SetIsReplicatedByDefault(true);
}

void UHealthComponent::BeginPlay()
{
    Super::BeginPlay();
    CurrentHealth = MaxHealth;
}

void UHealthComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
    Super::GetLifetimeReplicatedProps(OutLifetimeProps);

    DOREPLIFETIME(UHealthComponent, CurrentHealth);
}

void UHealthComponent::TakeDamage(float Damage, AActor* DamageCauser)
{
    if (IsDead()) return;

    CurrentHealth = FMath::Max(0.0f, CurrentHealth - Damage);
    OnRep_Health();

    if (CurrentHealth <= 0)
    {
        OnDeath.Broadcast();
    }
}

void UHealthComponent::Heal(float Amount)
{
    if (IsDead()) return;

    CurrentHealth = FMath::Min(MaxHealth, CurrentHealth + Amount);
    OnRep_Health();
}

void UHealthComponent::SetHealth(float NewHealth)
{
    CurrentHealth = FMath::Clamp(NewHealth, 0.0f, MaxHealth);
    OnRep_Health();
}

float UHealthComponent::GetHealthPercent() const
{
    return MaxHealth > 0 ? CurrentHealth / MaxHealth : 0.0f;
}

bool UHealthComponent::IsDead() const
{
    return CurrentHealth <= 0;
}

bool UHealthComponent::IsLowHealth() const
{
    return CurrentHealth <= LowHealthThreshold && !IsDead();
}

void UHealthComponent::OnRep_Health()
{
    OnHealthChanged.Broadcast(CurrentHealth, MaxHealth);
}`;

    return { header, source };
  }

  generateInventorySystem() {
    const header = `#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "InventoryComponent.generated.h"

USTRUCT(BlueprintType)
struct FInventoryItem
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FName ItemID;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FString DisplayName;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 Quantity;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    UTexture2D* Icon;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    TSubclassOf<AActor> ItemClass;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    bool bIsStackable;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 MaxStackSize;
};

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class UInventoryComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    UInventoryComponent();

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Inventory")
    int32 MaxSlots;

    UPROPERTY(Replicated, BlueprintReadOnly, Category = "Inventory")
    TArray<FInventoryItem> Items;

    UFUNCTION(BlueprintCallable, Category = "Inventory")
    bool AddItem(const FInventoryItem& Item);

    UFUNCTION(BlueprintCallable, Category = "Inventory")
    bool RemoveItem(const FName& ItemID, int32 Quantity);

    UFUNCTION(BlueprintCallable, Category = "Inventory")
    bool HasItem(const FName& ItemID) const;

    UFUNCTION(BlueprintCallable, Category = "Inventory")
    int32 GetItemQuantity(const FName& ItemID) const;

    UFUNCTION(BlueprintCallable, Category = "Inventory")
    void DropItem(const FName& ItemID);

    UFUNCTION(BlueprintCallable, Category = "Inventory")
    void UseItem(const FName& ItemID);

    UFUNCTION(BlueprintPure, Category = "Inventory")
    bool IsFull() const;

    UFUNCTION(BlueprintPure, Category = "Inventory")
    int32 GetEmptySlots() const;

protected:
    virtual void BeginPlay() override;
    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

    int32 FindItemIndex(const FName& ItemID) const;
    int32 FindEmptySlot() const;
};`;

    const source = `#include "InventoryComponent.h"
#include "Net/UnrealNetwork.h"

UInventoryComponent::UInventoryComponent()
{
    PrimaryComponentTick.bCanEverTick = false;
    MaxSlots = 20;
    SetIsReplicatedByDefault(true);
}

void UInventoryComponent::BeginPlay()
{
    Super::BeginPlay();
    Items.Reserve(MaxSlots);
}

void UInventoryComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
    Super::GetLifetimeReplicatedProps(OutLifetimeProps);

    DOREPLIFETIME(UInventoryComponent, Items);
}

bool UInventoryComponent::AddItem(const FInventoryItem& Item)
{
    if (Item.bIsStackable)
    {
        int32 Index = FindItemIndex(Item.ItemID);
        if (Index != INDEX_NONE)
        {
            int32 NewQuantity = Items[Index].Quantity + Item.Quantity;
            if (NewQuantity <= Items[Index].MaxStackSize)
            {
                Items[Index].Quantity = NewQuantity;
                return true;
            }
        }
    }

    int32 EmptySlot = FindEmptySlot();
    if (EmptySlot != INDEX_NONE)
    {
        Items.Insert(Item, EmptySlot);
        return true;
    }

    return false;
}

bool UInventoryComponent::RemoveItem(const FName& ItemID, int32 Quantity)
{
    int32 Index = FindItemIndex(ItemID);
    if (Index == INDEX_NONE) return false;

    if (Items[Index].Quantity <= Quantity)
    {
        Items.RemoveAt(Index);
    }
    else
    {
        Items[Index].Quantity -= Quantity;
    }

    return true;
}

bool UInventoryComponent::HasItem(const FName& ItemID) const
{
    return FindItemIndex(ItemID) != INDEX_NONE;
}

int32 UInventoryComponent::GetItemQuantity(const FName& ItemID) const
{
    int32 Index = FindItemIndex(ItemID);
    return Index != INDEX_NONE ? Items[Index].Quantity : 0;
}

void UInventoryComponent::DropItem(const FName& ItemID)
{
    int32 Index = FindItemIndex(ItemID);
    if (Index == INDEX_NONE) return;

    FInventoryItem Item = Items[Index];
    Items.RemoveAt(Index);

    // Spawn dropped item in world
    if (Item.ItemClass && GetOwner())
    {
        FActorSpawnParameters Params;
        Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
        GetWorld()->SpawnActor<AActor>(Item.ItemClass, GetOwner()->GetActorLocation(), FRotator::ZeroRotator, Params);
    }
}

void UInventoryComponent::UseItem(const FName& ItemID)
{
    // Implement item usage logic
}

bool UInventoryComponent::IsFull() const
{
    return Items.Num() >= MaxSlots;
}

int32 UInventoryComponent::GetEmptySlots() const
{
    return MaxSlots - Items.Num();
}

int32 UInventoryComponent::FindItemIndex(const FName& ItemID) const
{
    for (int32 i = 0; i < Items.Num(); i++)
    {
        if (Items[i].ItemID == ItemID)
        {
            return i;
        }
    }
    return INDEX_NONE;
}

int32 UInventoryComponent::FindEmptySlot() const
{
    if (Items.Num() < MaxSlots)
    {
        return Items.Num();
    }
    return INDEX_NONE;
}`;

    return { header, source };
  }

  generateSaveSystem() {
    const header = `#pragma once

#include "CoreMinimal.h"
#include "GameFramework/SaveGame.h"
#include "SaveGameData.generated.h"

USTRUCT(BlueprintType)
struct FPlayerSaveData
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FString PlayerName;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 Level;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 Experience;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float Health;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FVector Location;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FRotator Rotation;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    TArray<FString> InventoryItems;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    TMap<FString, int32> Statistics;
};

UCLASS()
class USaveGameData : public USaveGame
{
    GENERATED_BODY()

public:
    USaveGameData();

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Save Data")
    FString SaveSlotName;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Save Data")
    int32 UserIndex;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Save Data")
    FDateTime SaveDate;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Save Data")
    FPlayerSaveData PlayerData;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Save Data")
    FString CurrentLevel;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Save Data")
    TMap<FString, FString> GameSettings;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Save Data")
    TArray<FString> CompletedQuests;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Save Data")
    float PlayTime;

    UFUNCTION(BlueprintCallable, Category = "Save System")
    static bool SaveGame(const FString& SlotName, const FPlayerSaveData& Data);

    UFUNCTION(BlueprintCallable, Category = "Save System")
    static bool LoadGame(const FString& SlotName, FPlayerSaveData& OutData);

    UFUNCTION(BlueprintCallable, Category = "Save System")
    static bool DeleteSave(const FString& SlotName);

    UFUNCTION(BlueprintCallable, Category = "Save System")
    static TArray<FString> GetAllSaveSlots();
};`;

    const source = `#include "SaveGameData.h"
#include "Kismet/GameplayStatics.h"

USaveGameData::USaveGameData()
{
    SaveSlotName = TEXT("DefaultSave");
    UserIndex = 0;
    SaveDate = FDateTime::Now();
    PlayTime = 0.0f;
}

bool USaveGameData::SaveGame(const FString& SlotName, const FPlayerSaveData& Data)
{
    USaveGameData* SaveGameInstance = Cast<USaveGameData>(UGameplayStatics::CreateSaveGameObject(USaveGameData::StaticClass()));

    if (SaveGameInstance)
    {
        SaveGameInstance->SaveSlotName = SlotName;
        SaveGameInstance->PlayerData = Data;
        SaveGameInstance->SaveDate = FDateTime::Now();

        return UGameplayStatics::SaveGameToSlot(SaveGameInstance, SlotName, 0);
    }

    return false;
}

bool USaveGameData::LoadGame(const FString& SlotName, FPlayerSaveData& OutData)
{
    if (UGameplayStatics::DoesSaveGameExist(SlotName, 0))
    {
        USaveGameData* SaveGameInstance = Cast<USaveGameData>(UGameplayStatics::LoadGameFromSlot(SlotName, 0));

        if (SaveGameInstance)
        {
            OutData = SaveGameInstance->PlayerData;
            return true;
        }
    }

    return false;
}

bool USaveGameData::DeleteSave(const FString& SlotName)
{
    if (UGameplayStatics::DoesSaveGameExist(SlotName, 0))
    {
        return UGameplayStatics::DeleteGameInSlot(SlotName, 0);
    }

    return false;
}

TArray<FString> USaveGameData::GetAllSaveSlots()
{
    TArray<FString> SaveSlots;
    // Implementation depends on platform
    return SaveSlots;
}`;

    return { header, source };
  }

  generateNetworkComponent() {
    const header = `#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "NetworkComponent.generated.h"

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class UNetworkComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    UNetworkComponent();

    UFUNCTION(BlueprintCallable, Category = "Network")
    void InitializeNetwork();

    UFUNCTION(BlueprintCallable, Category = "Network")
    void ConnectToServer(const FString& ServerAddress);

    UFUNCTION(BlueprintCallable, Category = "Network")
    void HostServer(int32 MaxPlayers);

    UFUNCTION(BlueprintCallable, Category = "Network")
    void Disconnect();

    UFUNCTION(BlueprintPure, Category = "Network")
    bool IsConnected() const;

    UFUNCTION(BlueprintPure, Category = "Network")
    bool IsHost() const;

    UFUNCTION(BlueprintPure, Category = "Network")
    int32 GetPing() const;

    UFUNCTION(BlueprintPure, Category = "Network")
    int32 GetPlayerCount() const;

    UPROPERTY(BlueprintAssignable, Category = "Events")
    FSimpleDelegate OnConnected;

    UPROPERTY(BlueprintAssignable, Category = "Events")
    FSimpleDelegate OnDisconnected;

    UPROPERTY(BlueprintAssignable, Category = "Events")
    FSimpleDelegate OnPlayerJoined;

    UPROPERTY(BlueprintAssignable, Category = "Events")
    FSimpleDelegate OnPlayerLeft;

protected:
    virtual void BeginPlay() override;

    UPROPERTY(EditDefaultsOnly, Category = "Network")
    int32 DefaultPort;

    UPROPERTY(EditDefaultsOnly, Category = "Network")
    float ConnectionTimeout;

    bool bIsConnected;
    bool bIsHost;
    int32 CurrentPing;
};`;

    const source = `#include "NetworkComponent.h"
#include "OnlineSubsystem.h"
#include "OnlineSessionSettings.h"

UNetworkComponent::UNetworkComponent()
{
    PrimaryComponentTick.bCanEverTick = false;
    DefaultPort = 7777;
    ConnectionTimeout = 10.0f;
    bIsConnected = false;
    bIsHost = false;
    CurrentPing = 0;
}

void UNetworkComponent::BeginPlay()
{
    Super::BeginPlay();
}

void UNetworkComponent::InitializeNetwork()
{
    IOnlineSubsystem* OnlineSub = IOnlineSubsystem::Get();
    if (OnlineSub)
    {
        IOnlineSessionPtr Sessions = OnlineSub->GetSessionInterface();
        if (Sessions.IsValid())
        {
            // Initialize session system
        }
    }
}

void UNetworkComponent::ConnectToServer(const FString& ServerAddress)
{
    // Implementation using OnlineSubsystem
    bIsConnected = true;
    OnConnected.Broadcast();
}

void UNetworkComponent::HostServer(int32 MaxPlayers)
{
    // Implementation using OnlineSubsystem
    bIsHost = true;
    bIsConnected = true;
    OnConnected.Broadcast();
}

void UNetworkComponent::Disconnect()
{
    bIsConnected = false;
    bIsHost = false;
    OnDisconnected.Broadcast();
}

bool UNetworkComponent::IsConnected() const
{
    return bIsConnected;
}

bool UNetworkComponent::IsHost() const
{
    return bIsHost;
}

int32 UNetworkComponent::GetPing() const
{
    return CurrentPing;
}

int32 UNetworkComponent::GetPlayerCount() const
{
    // Return actual player count from session
    return 1;
}`;

    return { header, source };
  }

  async generateAISystem(sourceDir, project) {
    const header = `#pragma once

#include "CoreMinimal.h"
#include "AIController.h"
#include "AIControllerBase.generated.h"

UCLASS()
class AAIControllerBase : public AAIController
{
    GENERATED_BODY()

public:
    AAIControllerBase();

    virtual void OnPossess(APawn* InPawn) override;
    virtual void Tick(float DeltaTime) override;

    UFUNCTION(BlueprintCallable, Category = "AI")
    void SetTarget(AActor* NewTarget);

    UFUNCTION(BlueprintCallable, Category = "AI")
    void SetPatrolPoints(const TArray<FVector>& Points);

    UFUNCTION(BlueprintCallable, Category = "AI")
    void SetBehaviorState(EAIBehaviorState NewState);

    UPROPERTY(EditDefaultsOnly, Category = "AI")
    float DetectionRange;

    UPROPERTY(EditDefaultsOnly, Category = "AI")
    float AttackRange;

    UPROPERTY(EditDefaultsOnly, Category = "AI")
    float PatrolSpeed;

    UPROPERTY(EditDefaultsOnly, Category = "AI")
    float ChaseSpeed;

protected:
    UPROPERTY()
    AActor* CurrentTarget;

    UPROPERTY()
    TArray<FVector> PatrolPoints;

    UPROPERTY()
    EAIBehaviorState CurrentState;

    int32 CurrentPatrolIndex;
    FTimerHandle BehaviorTimerHandle;

    void UpdateBehavior();
    void Patrol();
    void Chase();
    void Attack();
    void Search();

    AActor* FindNearestPlayer();
    bool CanSeeTarget(AActor* Target);
    float GetDistanceToTarget(AActor* Target);
};

UENUM(BlueprintType)
enum class EAIBehaviorState : uint8
{
    Idle        UMETA(DisplayName = "Idle"),
    Patrol      UMETA(DisplayName = "Patrol"),
    Chase       UMETA(DisplayName = "Chase"),
    Attack      UMETA(DisplayName = "Attack"),
    Search      UMETA(DisplayName = "Search"),
    Flee        UMETA(DisplayName = "Flee")
};`;

    await this.writeFile(path.join(sourceDir, 'Public/AIControllerBase.h'), header);

    return {
      assets: [
        { name: 'AIControllerBase', type: 'cpp', path: path.join(sourceDir, 'Public/AIControllerBase.h'), status: 'completed' },
      ],
    };
  }

  async generateGenericCPP(sourceDir, task, project) {
    const genericHeader = `#pragma once

#include "CoreMinimal.h"
// Generated by ${this.name} for ${task.type}`;
    const genericSource = `#include "${task.type}.h"
// Generated by ${this.name}`;

    await this.writeFile(path.join(sourceDir, `Public/${task.type}.h`), genericHeader);
    await this.writeFile(path.join(sourceDir, `Private/${task.type}.cpp`), genericSource);

    return {
      assets: [
        { name: task.type, type: 'cpp', path: path.join(sourceDir, `Public/${task.type}.h`), status: 'completed' },
      ],
    };
  }
}

module.exports = CPPCodingAgent;
