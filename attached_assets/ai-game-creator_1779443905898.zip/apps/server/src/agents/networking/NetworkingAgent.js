const BaseAgent = require('../BaseAgent');
const path = require('path');

class NetworkingAgent extends BaseAgent {
  constructor(id, name, role, color, orchestrator) {
    super(id, name, role, color, orchestrator);
  }

  async processTask(task, project) {
    const projectDir = path.join(process.env.PROJECTS_DIR || './projects', project.id);
    const sourceDir = path.join(projectDir, 'Source', project.name);

    this.emitLog(project.id, 'info', 'Setting up multiplayer networking...');

    const networkCode = this.generateNetworkCode(project);
    await this.writeFile(path.join(sourceDir, 'Public/NetworkReplication.h'), networkCode.header);
    await this.writeFile(path.join(sourceDir, 'Private/NetworkReplication.cpp'), networkCode.source);

    const matchmakingCode = this.generateMatchmakingCode(project);
    await this.writeFile(path.join(sourceDir, 'Public/MatchmakingSystem.h'), matchmakingCode.header);

    const eosCode = this.generateEOSIntegration(project);
    await this.writeFile(path.join(sourceDir, 'Public/EOSIntegration.h'), eosCode);

    this.emitLog(project.id, 'success', 'Multiplayer networking configured');

    return {
      assets: [
        { name: 'NetworkReplication', type: 'cpp', path: path.join(sourceDir, 'Public/NetworkReplication.h'), status: 'completed', generatedBy: this.name },
        { name: 'MatchmakingSystem', type: 'cpp', path: path.join(sourceDir, 'Public/MatchmakingSystem.h'), status: 'completed', generatedBy: this.name },
        { name: 'EOSIntegration', type: 'cpp', path: path.join(sourceDir, 'Public/EOSIntegration.h'), status: 'completed', generatedBy: this.name },
      ],
    };
  }

  generateNetworkCode(project) {
    const header = `#pragma once
#include "CoreMinimal.h"
#include "NetworkReplication.generated.h"

UCLASS()
class ${project.name.toUpperCase()}_API UNetworkReplication : public UObject
{
    GENERATED_BODY()
public:
    UFUNCTION(BlueprintCallable, Category = "Network")
    static void SetupReplication(AActor* Actor);
    UFUNCTION(BlueprintCallable, Category = "Network")
    static void ReplicateProperty(UObject* Object, FName PropertyName);
    UFUNCTION(BlueprintCallable, Category = "Network")
    static void SetNetworkPriority(AActor* Actor, float Priority);
    UPROPERTY(EditDefaultsOnly, Category = "Network")
    static float MobileReplicationInterval;
    UPROPERTY(EditDefaultsOnly, Category = "Network")
    static int32 MaxReplicatedActors;
    UPROPERTY(EditDefaultsOnly, Category = "Network")
    static bool bUseNetworkPrediction;
};

USTRUCT()
struct FReplicatedTransform
{
    GENERATED_BODY()
    UPROPERTY() FVector_NetQuantize Location;
    UPROPERTY() FVector_NetQuantize10 Velocity;
    UPROPERTY() FVector_NetQuantizeNormal Rotation;
    UPROPERTY() uint32 Timestamp;
};`;

    const source = `#include "NetworkReplication.h"
#include "Net/UnrealNetwork.h"
#include "GameFramework/Actor.h"

float UNetworkReplication::MobileReplicationInterval = 0.05f;
int32 UNetworkReplication::MaxReplicatedActors = 100;
bool UNetworkReplication::bUseNetworkPrediction = true;

void UNetworkReplication::SetupReplication(AActor* Actor)
{
    if (!Actor) return;
    Actor->SetReplicates(true);
    Actor->SetReplicateMovement(true);
    Actor->NetUpdateFrequency = 1.0f / MobileReplicationInterval;
    Actor->MinNetUpdateFrequency = 2.0f;
}

void UNetworkReplication::ReplicateProperty(UObject* Object, FName PropertyName)
{
    if (!Object) return;
    UProperty* Property = Object->GetClass()->FindPropertyByName(PropertyName);
    if (Property) Property->SetPropertyFlags(CPF_Net);
}

void UNetworkReplication::SetNetworkPriority(AActor* Actor, float Priority)
{
    if (!Actor) return;
    Actor->NetPriority = Priority;
}`;

    return { header, source };
  }

  generateMatchmakingCode(project) {
    const header = `#pragma once
#include "CoreMinimal.h"
#include "MatchmakingSystem.generated.h"

UCLASS()
class ${project.name.toUpperCase()}_API UMatchmakingSystem : public UObject
{
    GENERATED_BODY()
public:
    UFUNCTION(BlueprintCallable, Category = "Matchmaking")
    static void StartMatchmaking(const FString& GameMode, int32 MaxPlayers);
    UFUNCTION(BlueprintCallable, Category = "Matchmaking")
    static void CancelMatchmaking();
    UFUNCTION(BlueprintCallable, Category = "Matchmaking")
    static void JoinSession(const FString& SessionId);
    UFUNCTION(BlueprintCallable, Category = "Matchmaking")
    static void HostSession(const FString& SessionName, int32 MaxPlayers);
    UFUNCTION(BlueprintCallable, Category = "Matchmaking")
    static TArray<FString> FindSessions();
    UFUNCTION(BlueprintCallable, Category = "Matchmaking")
    static bool IsInSession();
    UPROPERTY(EditDefaultsOnly, Category = "Matchmaking") int32 MaxSearchResults;
    UPROPERTY(EditDefaultsOnly, Category = "Matchmaking") float SearchTimeout;
    UPROPERTY(EditDefaultsOnly, Category = "Matchmaking") bool bUseEosBackend;
    UPROPERTY(EditDefaultsOnly, Category = "Matchmaking") bool bUseSteamBackend;
    UPROPERTY(EditDefaultsOnly, Category = "Matchmaking") bool bUseLan;
};

USTRUCT(BlueprintType)
struct FSessionInfo
{
    GENERATED_BODY()
    UPROPERTY(BlueprintReadOnly) FString SessionId;
    UPROPERTY(BlueprintReadOnly) FString HostName;
    UPROPERTY(BlueprintReadOnly) FString MapName;
    UPROPERTY(BlueprintReadOnly) int32 CurrentPlayers;
    UPROPERTY(BlueprintReadOnly) int32 MaxPlayers;
    UPROPERTY(BlueprintReadOnly) int32 Ping;
    UPROPERTY(BlueprintReadOnly) bool bIsPasswordProtected;
};`;

    return { header, source: '// Matchmaking implementation' };
  }

  generateEOSIntegration(project) {
    return `#pragma once
#include "CoreMinimal.h"

class ${project.name.toUpperCase()}_API FEOSIntegration
{
public:
    static void Initialize();
    static void Shutdown();
    static bool Login(const FString& AuthToken);
    static void Logout();
    static bool CreateLobby(int32 MaxPlayers);
    static bool JoinLobby(const FString& LobbyId);
    static void LeaveLobby();
    static void SendLobbyMessage(const FString& Message);
    static TArray<FString> GetLobbyMembers();
    static void InitializeAntiCheat();
    static bool ValidatePlayer(const FString& PlayerId);
    static void ReportPlayer(const FString& PlayerId, const FString& Reason);
    static void InitializeVoiceChat();
    static void JoinVoiceChannel(const FString& ChannelName);
    static void LeaveVoiceChannel();
    static void MutePlayer(const FString& PlayerId);
    static void UnmutePlayer(const FString& PlayerId);
};`;
  }
}

module.exports = NetworkingAgent;
