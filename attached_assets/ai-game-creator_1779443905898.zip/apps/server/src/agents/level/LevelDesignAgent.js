const BaseAgent = require('../BaseAgent');
const logger = require('../../utils/logger');
const path = require('path');

class LevelDesignAgent extends BaseAgent {
  constructor(id, name, role, color, orchestrator) {
    super(id, name, role, color, orchestrator);
  }

  async processTask(task, project) {
    const projectDir = path.join(process.env.PROJECTS_DIR || './projects', project.id);

    this.emitLog(projectId, 'info', `Designing level for ${project.genre} game...`);

    // Generate level layout based on genre
    const levelConfig = this.generateLevelConfig(project);

    // Create level files
    const levelPath = path.join(projectDir, 'Content', 'Maps', 'MainLevel.umap');
    const levelData = this.generateLevelData(levelConfig);

    await this.writeFile(levelPath + '.json', JSON.stringify(levelData, null, 2));

    // Generate terrain data
    const terrainPath = path.join(projectDir, 'Content', 'Maps', 'TerrainData.json');
    const terrainData = this.generateTerrain(project);
    await this.writeFile(terrainPath, JSON.stringify(terrainData, null, 2));

    // Generate lighting config (Lumen + Nanite ready)
    const lightingPath = path.join(projectDir, 'Config', 'Lighting.ini');
    const lightingConfig = this.generateLightingConfig(project);
    await this.writeFile(lightingPath, lightingConfig);

    this.emitLog(project.id, 'success', `Level designed: ${levelConfig.name} (${levelConfig.size}x${levelConfig.size})`);

    return {
      assets: [
        { name: 'MainLevel', type: 'map', path: levelPath, status: 'completed' },
        { name: 'TerrainData', type: 'map', path: terrainPath, status: 'completed' },
      ],
      levelConfig,
    };
  }

  generateLevelConfig(project) {
    const configs = {
      shooter: {
        name: 'CombatArena',
        size: 2000,
        zones: ['spawn', 'combat', 'cover', 'sniper', 'objective'],
        verticality: true,
        indoorRatio: 0.3,
      },
      rpg: {
        name: 'AdventureWorld',
        size: 8000,
        zones: ['village', 'forest', 'dungeon', 'castle', 'mountain'],
        verticality: true,
        indoorRatio: 0.5,
      },
      survival: {
        name: 'SurvivalZone',
        size: 4000,
        zones: ['base', 'scavenge', 'danger', 'resource', 'safe'],
        verticality: false,
        indoorRatio: 0.4,
      },
      racing: {
        name: 'SpeedCircuit',
        size: 5000,
        zones: ['start', 'straight', 'curve', 'jump', 'finish'],
        verticality: true,
        indoorRatio: 0.1,
      },
    };

    return configs[project.genre] || configs.shooter;
  }

  generateLevelData(config) {
    return {
      version: '5.4',
      worldSettings: {
        defaultGameMode: '/Game/Blueprints/BP_GameMode',
        defaultPawn: '/Game/Blueprints/BP_PlayerCharacter',
        lighting: {
          type: 'Lumen',
          quality: 'High',
          rayTracing: true,
        },
        nanite: {
          enabled: true,
          fallback: 'LOD',
        },
      },
      actors: this.generateActors(config),
      landscape: {
        size: config.size,
        resolution: 1024,
        material: '/Game/Materials/M_Landscape',
      },
    };
  }

  generateActors(config) {
    const actors = [];

    // Spawn points
    for (let i = 0; i < 8; i++) {
      actors.push({
        type: 'PlayerStart',
        position: { x: Math.random() * config.size, y: Math.random() * config.size, z: 100 },
        rotation: { pitch: 0, yaw: Math.random() * 360, roll: 0 },
      });
    }

    // Cover points for shooters
    if (config.zones.includes('cover')) {
      for (let i = 0; i < 20; i++) {
        actors.push({
          type: 'StaticMesh',
          mesh: '/Game/Meshes/SM_Cover',
          position: { x: Math.random() * config.size, y: Math.random() * config.size, z: 0 },
        });
      }
    }

    // Lighting
    actors.push({
      type: 'DirectionalLight',
      position: { x: 0, y: 0, z: 1000 },
      settings: {
        intensity: 10,
        color: { r: 1, g: 0.95, b: 0.8 },
        castShadows: true,
        rayTracedShadows: true,
      },
    });

    // Sky atmosphere
    actors.push({
      type: 'SkyAtmosphere',
      settings: {
        rayleighScattering: 0.1,
        mieScattering: 0.003,
      },
    });

    // Post Process Volume
    actors.push({
      type: 'PostProcessVolume',
      position: { x: config.size/2, y: config.size/2, z: 500 },
      extent: { x: config.size, y: config.size, z: 1000 },
      settings: {
        bloom: true,
        ambientOcclusion: true,
        rayTracing: true,
        motionBlur: true,
        lensFlare: false,
      },
    });

    return actors;
  }

  generateTerrain(project) {
    return {
      heightmap: {
        width: 1024,
        height: 1024,
        scale: { x: 100, y: 100, z: 500 },
        seed: Math.floor(Math.random() * 100000),
      },
      layers: [
        { name: 'Grass', weight: 0.6, material: '/Game/Materials/M_Grass' },
        { name: 'Rock', weight: 0.2, material: '/Game/Materials/M_Rock' },
        { name: 'Dirt', weight: 0.15, material: '/Game/Materials/M_Dirt' },
        { name: 'Snow', weight: 0.05, material: '/Game/Materials/M_Snow' },
      ],
    };
  }

  generateLightingConfig(project) {
    return `[Lighting]
DefaultBrightness=10.0
DefaultLightColor=(R=1.0,G=0.95,B=0.8)
DynamicShadows=True
RayTracedShadows=True
LumenEnabled=True
LumenQuality=High
NaniteEnabled=True
MobileLumen=True
MobileNanite=True

[/Script/Engine.RendererSettings]
r.DefaultFeature.AutoExposure=True
r.DefaultFeature.MotionBlur=True
r.DefaultFeature.LensFlare=False
r.DefaultFeature.AntiAliasing=2
r.DefaultFeature.AmbientOcclusion=True
r.DefaultFeature.AmbientOcclusionStaticFraction=True
r.DefaultFeature.AutoExposure.Method=1
r.DefaultFeature.AutoExposure.Bias=1.0
r.DefaultFeature.AutoExposure.ExtendDefaultLuminanceRange=True

; Mobile optimizations
r.Mobile.AntiAliasing=1
r.Mobile.UseHWsRGBEncoding=True
r.Mobile.AllowDitheredLODTransition=True
r.Mobile.VirtualTextures=True

; Nanite settings
r.Nanite.MaxPixelsPerEdge=1.0
r.Nanite.MaxPixelsPerEdgeMM=1.0
r.Nanite.MaxPixelsPerEdgeSD=1.0

; Lumen settings
r.Lumen.DiffuseIndirect.Allow=1
r.Lumen.Reflections.Allow=1
r.Lumen.ScreenProbeGather.RadianceCache.Resolution=32
r.Lumen.ScreenProbeGather.RadianceCache.Directional=1
`;
  }
}

module.exports = LevelDesignAgent;
