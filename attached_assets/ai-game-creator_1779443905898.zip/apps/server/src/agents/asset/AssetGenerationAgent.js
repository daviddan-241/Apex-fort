const BaseAgent = require('../BaseAgent');
const path = require('path');
const fs = require('fs').promises;

class AssetGenerationAgent extends BaseAgent {
  constructor(id, name, role, color, orchestrator) {
    super(id, name, role, color, orchestrator);
  }

  async processTask(task, project) {
    const projectDir = path.join(process.env.PROJECTS_DIR || './projects', project.id);

    this.emitLog(project.id, 'info', `Generating assets: ${task.type}`);

    let result;
    switch (task.type) {
      case 'character_mesh':
        result = await this.generateCharacterMesh(projectDir, project);
        break;
      case 'weapons':
        result = await this.generateWeapons(projectDir, project);
        break;
      case 'environment':
        result = await this.generateEnvironment(projectDir, project);
        break;
      default:
        result = await this.generateGenericAsset(projectDir, task, project);
    }

    this.emitLog(project.id, 'success', `Assets generated: ${task.type}`);
    return result;
  }

  async generateCharacterMesh(projectDir, project) {
    const meshDir = path.join(projectDir, 'Content', 'Meshes');
    const style = project.config?.style || 'realistic';

    // Generate placeholder mesh data
    const meshData = this.generateMeshData('character', style, project.genre);

    await this.writeFile(
      path.join(meshDir, 'SK_Player.fbx'),
      JSON.stringify(meshData, null, 2)
    );

    // Generate materials for character
    const matData = this.generateMaterialData('character', style);
    await this.writeFile(
      path.join(projectDir, 'Content', 'Materials', 'M_Character.json'),
      JSON.stringify(matData, null, 2)
    );

    // Generate textures
    const textures = ['T_Character_Diffuse', 'T_Character_Normal', 'T_Character_Roughness', 'T_Character_Metallic'];
    for (const tex of textures) {
      await this.writeFile(
        path.join(projectDir, 'Content', 'Textures', `${tex}.png`),
        'PNG_TEXTURE_DATA_PLACEHOLDER'
      );
    }

    return {
      assets: [
        { name: 'SK_Player', type: 'mesh', path: path.join(meshDir, 'SK_Player.fbx'), size: 2048, status: 'completed', generatedBy: this.name },
        { name: 'M_Character', type: 'material', path: path.join(projectDir, 'Content', 'Materials', 'M_Character.json'), size: 12, status: 'completed', generatedBy: this.name },
        { name: 'T_Character_Diffuse', type: 'texture', path: path.join(projectDir, 'Content', 'Textures', 'T_Character_Diffuse.png'), size: 4096, status: 'completed', generatedBy: this.name },
        { name: 'T_Character_Normal', type: 'texture', path: path.join(projectDir, 'Content', 'Textures', 'T_Character_Normal.png'), size: 4096, status: 'completed', generatedBy: this.name },
        { name: 'T_Character_Roughness', type: 'texture', path: path.join(projectDir, 'Content', 'Textures', 'T_Character_Roughness.png'), size: 2048, status: 'completed', generatedBy: this.name },
        { name: 'T_Character_Metallic', type: 'texture', path: path.join(projectDir, 'Content', 'Textures', 'T_Character_Metallic.png'), size: 2048, status: 'completed', generatedBy: this.name },
      ],
    };
  }

  async generateWeapons(projectDir, project) {
    const meshDir = path.join(projectDir, 'Content', 'Meshes');
    const weapons = ['SM_Rifle', 'SM_Pistol', 'SM_Shotgun', 'SM_Sniper'];
    const assets = [];

    for (const weapon of weapons) {
      const meshData = this.generateMeshData(weapon, 'realistic', 'shooter');
      await this.writeFile(
        path.join(meshDir, `${weapon}.fbx`),
        JSON.stringify(meshData, null, 2)
      );

      assets.push({
        name: weapon,
        type: 'mesh',
        path: path.join(meshDir, `${weapon}.fbx`),
        size: 1024,
        status: 'completed',
        generatedBy: this.name,
      });
    }

    // Weapon materials
    const weaponMat = this.generateMaterialData('weapon', 'metallic');
    await this.writeFile(
      path.join(projectDir, 'Content', 'Materials', 'M_Weapon.json'),
      JSON.stringify(weaponMat, null, 2)
    );

    assets.push({
      name: 'M_Weapon',
      type: 'material',
      path: path.join(projectDir, 'Content', 'Materials', 'M_Weapon.json'),
      size: 8,
      status: 'completed',
      generatedBy: this.name,
    });

    return { assets };
  }

  async generateEnvironment(projectDir, project) {
    const meshDir = path.join(projectDir, 'Content', 'Meshes');
    const envAssets = [];

    const props = [
      'SM_Building_01', 'SM_Building_02', 'SM_Crate', 'SM_Barrel',
      'SM_Tree_01', 'SM_Tree_02', 'SM_Rock_01', 'SM_Rock_02',
      'SM_Fence', 'SM_Wall', 'SM_Door', 'SM_Window',
      'SM_Vehicle_Jeep', 'SM_Vehicle_Tank',
    ];

    for (const prop of props) {
      const meshData = this.generateMeshData(prop, project.config?.style || 'realistic', project.genre);
      await this.writeFile(
        path.join(meshDir, `${prop}.fbx`),
        JSON.stringify(meshData, null, 2)
      );

      envAssets.push({
        name: prop,
        type: 'mesh',
        path: path.join(meshDir, `${prop}.fbx`),
        size: 512 + Math.floor(Math.random() * 2048),
        status: 'completed',
        generatedBy: this.name,
      });
    }

    // Environment materials
    const envMats = ['M_Ground', 'M_Building', 'M_Vegetation', 'M_Metal'];
    for (const mat of envMats) {
      const matData = this.generateMaterialData(mat, 'environment');
      await this.writeFile(
        path.join(projectDir, 'Content', 'Materials', `${mat}.json`),
        JSON.stringify(matData, null, 2)
      );

      envAssets.push({
        name: mat,
        type: 'material',
        path: path.join(projectDir, 'Content', 'Materials', `${mat}.json`),
        size: 8,
        status: 'completed',
        generatedBy: this.name,
      });
    }

    // Environment textures
    const envTextures = [
      'T_Ground_Diffuse', 'T_Ground_Normal',
      'T_Building_Diffuse', 'T_Building_Normal',
      'T_Vegetation_Diffuse', 'T_Vegetation_Normal',
    ];
    for (const tex of envTextures) {
      await this.writeFile(
        path.join(projectDir, 'Content', 'Textures', `${tex}.png`),
        'PNG_TEXTURE_DATA_PLACEHOLDER'
      );

      envAssets.push({
        name: tex,
        type: 'texture',
        path: path.join(projectDir, 'Content', 'Textures', `${tex}.png`),
        size: 4096,
        status: 'completed',
        generatedBy: this.name,
      });
    }

    return { assets: envAssets };
  }

  generateMeshData(type, style, genre) {
    const baseVertices = {
      character: 15000,
      weapon: 5000,
      building: 20000,
      prop: 2000,
      vehicle: 25000,
      tree: 8000,
      rock: 3000,
    };

    const vertexCount = baseVertices[type] || 5000;
    const lodLevels = style === 'simple' ? 2 : 4;

    return {
      version: '7.4',
      type: 'FBX',
      metadata: {
        generator: 'AI Game Creator - Asset Generation Agent',
        created: new Date().toISOString(),
        style,
        genre,
      },
      geometry: {
        vertices: vertexCount,
        triangles: Math.floor(vertexCount * 0.8),
        uvs: true,
        normals: true,
        tangents: true,
        vertexColors: false,
        skinWeights: type === 'character',
        morphTargets: false,
      },
      lods: Array.from({ length: lodLevels }, (_, i) => ({
        level: i,
        vertexCount: Math.floor(vertexCount * Math.pow(0.5, i)),
        screenSize: 1.0 / (i + 1),
      })),
      materials: ['default'],
      boundingBox: {
        min: [-1, -1, -1],
        max: [1, 1, 1],
      },
      nanite: {
        enabled: true,
        fallbackTrianglePercent: 50,
      },
    };
  }

  generateMaterialData(name, type) {
    const materialTemplates = {
      character: {
        shadingModel: 'DefaultLit',
        blendMode: 'Opaque',
        twoSided: false,
        textures: {
          BaseColor: { path: '/Game/Textures/T_Character_Diffuse', sampler: 'Linear' },
          Normal: { path: '/Game/Textures/T_Character_Normal', sampler: 'Linear' },
          Roughness: { path: '/Game/Textures/T_Character_Roughness', sampler: 'Linear' },
          Metallic: { path: '/Game/Textures/T_Character_Metallic', sampler: 'Linear' },
        },
        parameters: {
          Roughness: 0.5,
          Metallic: 0.0,
          Specular: 0.5,
          Emissive: [0, 0, 0],
        },
      },
      weapon: {
        shadingModel: 'DefaultLit',
        blendMode: 'Opaque',
        twoSided: false,
        textures: {
          BaseColor: { path: '/Game/Textures/T_Weapon_Diffuse', sampler: 'Linear' },
          Normal: { path: '/Game/Textures/T_Weapon_Normal', sampler: 'Linear' },
          Roughness: { path: '/Game/Textures/T_Weapon_Roughness', sampler: 'Linear' },
          Metallic: { path: '/Game/Textures/T_Weapon_Metallic', sampler: 'Linear' },
        },
        parameters: {
          Roughness: 0.3,
          Metallic: 0.8,
          Specular: 0.8,
        },
      },
      environment: {
        shadingModel: 'DefaultLit',
        blendMode: 'Opaque',
        twoSided: true,
        textures: {
          BaseColor: { path: '/Game/Textures/T_Env_Diffuse', sampler: 'Linear' },
          Normal: { path: '/Game/Textures/T_Env_Normal', sampler: 'Linear' },
          Roughness: { path: '/Game/Textures/T_Env_Roughness', sampler: 'Linear' },
        },
        parameters: {
          Roughness: 0.7,
          Metallic: 0.0,
        },
      },
    };

    return materialTemplates[type] || materialTemplates.environment;
  }

  async generateGenericAsset(projectDir, task, project) {
    const assetPath = path.join(projectDir, 'Content', task.type);
    await fs.mkdir(assetPath, { recursive: true });

    await this.writeFile(
      path.join(assetPath, `${task.type}_generated.json`),
      JSON.stringify({ generated: true, by: this.name, task: task.type }, null, 2)
    );

    return {
      assets: [
        { name: `${task.type}_generated`, type: 'mesh', path: path.join(assetPath, `${task.type}_generated.json`), size: 4, status: 'completed', generatedBy: this.name },
      ],
    };
  }
}

module.exports = AssetGenerationAgent;
