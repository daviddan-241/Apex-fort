const EventEmitter = require('events');
const logger = require('../utils/logger');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs').promises;
const path = require('path');

class BaseAgent extends EventEmitter {
  constructor(id, name, role, color, orchestrator) {
    super();
    this.id = id;
    this.name = name;
    this.role = role;
    this.color = color;
    this.orchestrator = orchestrator;
    this.status = 'idle';
    this.currentTask = null;
    this.progress = 0;
    this.workQueue = [];
    this.isProcessing = false;
  }

  async execute(task, project) {
    this.status = 'working';
    this.currentTask = task.description;
    this.progress = 0;

    this.emit('status', {
      projectId: project.id,
      status: 'working',
      currentTask: task.description,
      progress: 0,
    });

    try {
      const result = await this.processTask(task, project);

      this.status = 'completed';
      this.progress = 100;
      this.currentTask = null;

      this.emit('complete', {
        projectId: project.id,
        task: task.id,
        result,
      });

      return result;
    } catch (error) {
      this.status = 'error';
      this.emit('error', {
        projectId: project.id,
        task: task.id,
        error,
      });
      throw error;
    }
  }

  async processTask(task, project) {
    throw new Error('processTask must be implemented by subclass');
  }

  async generateWithAI(prompt, type = 'text') {
    // This would connect to OpenAI/Claude/local models
    // For now, return structured mock responses
    logger.info(`[${this.name}] AI generation requested: ${prompt.substring(0, 100)}...`);

    // Simulate AI processing time
    await this.delay(1000 + Math.random() * 2000);

    return {
      content: `Generated ${type} content for: ${prompt}`,
      metadata: { model: 'local-fallback', tokens: Math.floor(Math.random() * 1000) },
    };
  }

  async writeFile(filePath, content) {
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    await fs.writeFile(filePath, content);
  }

  async readFile(filePath) {
    return await fs.readFile(filePath, 'utf-8');
  }

  emitLog(projectId, level, message) {
    this.emit('log', { projectId, level, message });
  }

  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  updateProgress(projectId, progress) {
    this.progress = progress;
    this.emit('status', {
      projectId,
      status: 'working',
      currentTask: this.currentTask,
      progress,
    });
  }
}

module.exports = BaseAgent;
