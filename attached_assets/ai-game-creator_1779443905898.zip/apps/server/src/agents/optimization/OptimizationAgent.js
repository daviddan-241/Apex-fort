const BaseAgent = require('../BaseAgent');
const path = require('path');

class OptimizationAgent extends BaseAgent {
  constructor(id, name, role, color, orchestrator) {
    super(id, name, role, color, orchestrator);
  }

  async processTask(task, project) {
    const projectDir = path.join(process.env.PROJECTS_DIR || './projects', project.id);
    this.emitLog(project.id, 'info', 'Starting performance optimization...');

    if (project.platform?.includes('android') || project.platform?.includes('ios')) {
      await this.optimizeForMobile(projectDir, project);
    }
    await this.optimizeNanite(projectDir, project);
    await this.optimizeLumen(projectDir, project);
    await this.optimizeTextures(projectDir, project);
    await this.generateLODs(projectDir, project);
    await this.optimizeDrawCalls(projectDir, project);

    this.emitLog(project.id, 'success', 'Performance optimization complete');
    return {
      optimizations: [
        'Mobile rendering path enabled',
        'Nanite fallback LODs configured',
        'Lumen mobile settings applied',
        'Textures compressed to ASTC/ETC2',
        'Auto LODs generated',
        'Instanced rendering enabled',
        'Occlusion culling configured',
      ],
    };
  }

  async optimizeForMobile(projectDir, project) {
    this.emitLog(project.id, 'info', 'Applying mobile optimizations...');
    const mobileConfig = `[Mobile]
r.Mobile.AntiAliasing=1
r.Mobile.UseHWsRGBEncoding=1
r.Mobile.AllowDitheredLODTransition=1
r.Mobile.VirtualTextures=1
r.Streaming.PoolSize=512
r.Shadow.CSM.MaxCascades=2
r.Shadow.DistanceScale=0.7
r.DefaultFeature.Bloom=0
r.DefaultFeature.AmbientOcclusion=0
r.DefaultFeature.AutoExposure=0
r.DefaultFeature.MotionBlur=0
r.Lumen.DiffuseIndirect.Allow=1
r.Lumen.Reflections.Allow=1
r.Lumen.ScreenProbeGather.RadianceCache.Resolution=16
r.Nanite.MaxPixelsPerEdge=2.0
r.Nanite.ProxyMeshMode=1
r.GTSyncType=1
r.GPUCrashDebugging=0
r.TextureStreaming=1
r.Streaming.UseFixedPoolSize=1
r.Streaming.PoolSize=400
r.InstanceCulling.OcclusionSlop=1
r.AllowOcclusionQueries=1
`;
    await this.writeFile(path.join(projectDir, 'Config', 'Mobile.ini'), mobileConfig);
  }

  async optimizeNanite(projectDir, project) {
    this.emitLog(project.id, 'info', 'Configuring Nanite...');
    const naniteConfig = `[Nanite]
r.Nanite.Enabled=1
r.Nanite.MaxPixelsPerEdge=1.0
r.Nanite.MaxPixelsPerEdgeMM=1.0
r.Nanite.MaxPixelsPerEdgeSD=1.0
r.Nanite.ProxyMeshMode=0
r.Nanite.Tessellation=1
r.Nanite.ProgrammableRaster=1
r.Nanite.Visualize.Active=0
r.Nanite.Visualize.LegacyMaterial=0
r.Nanite.Visualize.Mesh=0
r.Nanite.Visualize.Overdraw=0
r.Nanite.Visualize.Clusters=0
r.Nanite.Visualize.Hierarchy=0
r.Nanite.Visualize.Materials=0
r.Nanite.Visualize.MaterialsByteSize=0
r.Nanite.Visualize.MaterialComplexity=0
`;
    await this.writeFile(path.join(projectDir, 'Config', 'Nanite.ini'), naniteConfig);
  }

  async optimizeLumen(projectDir, project) {
    this.emitLog(project.id, 'info', 'Configuring Lumen...');
    const lumenConfig = `[Lumen]
r.Lumen.DiffuseIndirect.Allow=1
r.Lumen.Reflections.Allow=1
r.Lumen.TranslucencyReflections.Allow=1
r.Lumen.HardwareRayTracing=1
r.Lumen.Reflections.HardwareRayTracing=1
r.Lumen.TranslucencyReflections.HardwareRayTracing=1
r.Lumen.ScreenProbeGather.RadianceCache.Resolution=32
r.Lumen.ScreenProbeGather.RadianceCache.Directional=1
r.Lumen.ScreenProbeGather.ScreenTraces.HZBTraversal.FullresDepth=1
r.Lumen.ScreenProbeGather.Temporal.DenoiceMode=1
r.Lumen.Reflections.MaxRoughnessToTrace=0.4
r.Lumen.Reflections.MaxRoughnessToTraceForFoliage=0.2
r.Lumen.TranslucencyReflections.TraceFromSurface=1
`;
    await this.writeFile(path.join(projectDir, 'Config', 'Lumen.ini'), lumenConfig);
  }

  async optimizeTextures(projectDir, project) {
    this.emitLog(project.id, 'info', 'Optimizing textures...');
    const textureConfig = `[Texture]
r.TextureStreaming=1
r.Streaming.UseFixedPoolSize=1
r.Streaming.PoolSize=1024
r.Streaming.LimitPoolSizeToVRAM=1
r.Streaming.MaxTempMemoryAllowed=512
r.Streaming.FramesForFullUpdate=1
r.Streaming.HLODStrategy=2
r.DefaultTextureFormat=AutoDXT
r.Mobile.DefaultTextureFormat=AutoPVRTC
r.Android.DefaultTextureFormat=AutoASTC
r.IOS.DefaultTextureFormat=AutoPVRTC
r.MipMap.LodBias=0
r.MipMap.GenNewMips=1
`;
    await this.writeFile(path.join(projectDir, 'Config', 'Texture.ini'), textureConfig);
  }

  async generateLODs(projectDir, project) {
    this.emitLog(project.id, 'info', 'Generating LODs...');
    const lodConfig = `[LOD]
r.StaticMesh.LODBias=0
r.SkeletalMesh.LODBias=0
r.LandscapeLODDistribution=3.0
r.LandscapeLODBias=0
r.ViewDistanceScale=1.0
r.GenerateMeshDistanceFields=1
r.DistanceField.MaxOcclusionDistance=512.0
r.DistanceField.DefaultVoxelDensity=0.1
`;
    await this.writeFile(path.join(projectDir, 'Config', 'LOD.ini'), lodConfig);
  }

  async optimizeDrawCalls(projectDir, project) {
    this.emitLog(project.id, 'info', 'Optimizing draw calls...');
    const drawCallConfig = `[DrawCalls]
r.InstanceCulling.OcclusionSlop=1
r.AllowOcclusionQueries=1
r.OcclusionQueryLocation=1
r.MinScreenRadiusForLights=0.03
r.MinScreenRadiusForDepthPrepass=0.03
r.MinScreenRadiusForCSMDepth=0.01
r.PrecomputedVisibilityWarning=0
r.PrecomputedVisibilityCellBucketNumCells=64
r.PrecomputedVisibilityCellSize=64
r.PrecomputedVisibilityNumCellBuckets=16
r.PrecomputedVisibilityApplyShadows=1
r.HLOD.MaximumLevel=-1
r.HLOD.Distance=10000
r.HLOD.MaximumClusterCount=500
`;
    await this.writeFile(path.join(projectDir, 'Config', 'DrawCalls.ini'), drawCallConfig);
  }
}

module.exports = OptimizationAgent;
