const EventEmitter = require('events');
const logger = require('../utils/logger');
const { v4: uuidv4 } = require('uuid');

// Import all agent classes
const LevelDesignAgent = require('../agents/level/LevelDesignAgent');
const BlueprintAgent = require('../agents/blueprint/BlueprintAgent');
const CPPCodingAgent = require('../agents/cpp/CPPCodingAgent');
const AssetGenerationAgent = require('../agents/asset/AssetGenerationAgent');
const UIGenerationAgent = require('../agents/ui/UIGenerationAgent');
const SoundGenerationAgent = require('../agents/sound/SoundGenerationAgent');
const NetworkingAgent = require('../agents/networking/NetworkingAgent');
const QATestingAgent = require('../agents/qa/QATestingAgent');
const OptimizationAgent = require('../agents/optimization/OptimizationAgent');

class AgentOrchestrator extends EventEmitter {
  constructor(projectManager) {
    super();
    this.projectManager = projectManager;
    this.agents = new Map();
    this.activeProjects = new Map();
    this.wsManager = null;

    // Initialize all specialized agents
    this.initializeAgents();
  }

  initializeAgents() {
    const agentConfigs = [
      { id: 'director', name: 'AI Director', role: 'Orchestrator', class: null, color: '#a855f7' },
      { id: 'level', name: 'Level Designer', role: 'Level Design', class: LevelDesignAgent, color: '#4ade80' },
      { id: 'blueprint', name: 'Blueprint Agent', role: 'Blueprint Generation', class: BlueprintAgent, color: '#00f0ff' },
      { id: 'cpp', name: 'C++ Coder', role: 'C++ Programming', class: CPPCodingAgent, color: '#fb923c' },
      { id: 'asset', name: 'Asset Generator', role: '3D/2D Assets', class: AssetGenerationAgent, color: '#ec4899' },
      { id: 'ui', name: 'UI Designer', role: 'Interface Design', class: UIGenerationAgent, color: '#22d3ee' },
      { id: 'sound', name: 'Audio Engineer', role: 'Sound & Music', class: SoundGenerationAgent, color: '#facc15' },
      { id: 'network', name: 'Network Engineer', role: 'Multiplayer', class: NetworkingAgent, color: '#818cf8' },
      { id: 'qa', name: 'QA Tester', role: 'Testing', class: QATestingAgent, color: '#f87171' },
      { id: 'optimizer', name: 'Optimizer', role: 'Performance', class: OptimizationAgent, color: '#ffd700' },
    ];

    for (const config of agentConfigs) {
      const agent = config.class 
        ? new config.class(config.id, config.name, config.role, config.color, this)
        : { id: config.id, name: config.name, role: config.role, color: config.color, status: 'idle' };

      this.agents.set(config.id, agent);

      // Listen to agent events
      if (agent.on) {
        agent.on('status', (data) => this.handleAgentStatus(config.id, data));
        agent.on('log', (data) => this.handleAgentLog(config.id, data));
        agent.on('complete', (data) => this.handleAgentComplete(config.id, data));
        agent.on('error', (data) => this.handleAgentError(config.id, data));
      }
    }

    logger.info('All agents initialized');
  }

  setWebSocketManager(wsManager) {
    this.wsManager = wsManager;
  }

  async createGame(prompt, config = {}) {
    const project = await this.projectManager.createProject({
      prompt,
      ...config,
    });

    this.activeProjects.set(project.id, {
      project,
      phase: 'planning',
      completedAgents: new Set(),
      failedAgents: new Set(),
    });

    // Start the game creation pipeline
    this.startPipeline(project.id);

    return project;
  }

  async startPipeline(projectId) {
    const context = this.activeProjects.get(projectId);
    if (!context) return;

    logger.info(`Starting pipeline for project ${projectId}`);

    // Phase 1: Planning & Analysis
    await this.runPhase(projectId, 'planning', async () => {
      await this.planGame(projectId);
    });

    // Phase 2: Asset Generation (parallel)
    await this.runPhase(projectId, 'generating', async () => {
      await this.generateAssets(projectId);
    });

    // Phase 3: Code & Blueprint Generation (parallel)
    await this.runPhase(projectId, 'building', async () => {
      await this.generateCode(projectId);
    });

    // Phase 4: Level Building
    await this.runPhase(projectId, 'building', async () => {
      await this.buildLevel(projectId);
    });

    // Phase 5: Integration & Testing
    await this.runPhase(projectId, 'testing', async () => {
      await this.testGame(projectId);
    });

    // Phase 6: Optimization
    await this.runPhase(projectId, 'testing', async () => {
      await this.optimizeGame(projectId);
    });

    // Phase 7: Packaging
    await this.runPhase(projectId, 'packaging', async () => {
      await this.packageGame(projectId);
    });

    // Complete
    await this.projectManager.updateProject(projectId, {
      status: 'completed',
      progress: 100,
    });

    this.emit('project_complete', { projectId });
    this.broadcast('build_complete', { projectId, projectName: context.project.name });
  }

  async runPhase(projectId, phaseName, phaseFn) {
    const context = this.activeProjects.get(projectId);
    if (!context) return;

    context.phase = phaseName;
    await this.projectManager.updateProject(projectId, { status: phaseName });
    this.broadcast('project_update', { id: projectId, status: phaseName });

    try {
      await phaseFn();
    } catch (error) {
      logger.error(`Phase ${phaseName} failed for project ${projectId}:`, error);
      await this.projectManager.addError(projectId, {
        message: `Phase ${phaseName} failed: ${error.message}`,
        severity: 'error',
      });
      // Try to recover
      await this.attemptRecovery(projectId, phaseName, error);
    }
  }

  async planGame(projectId) {
    const project = this.projectManager.getProject(projectId);

    this.broadcastLog(projectId, 'info', 'director', 'Analyzing game requirements...');

    // Parse the prompt to extract game requirements
    const requirements = this.parseGameRequirements(project.description);

    // Create task list for all agents
    const tasks = this.generateTaskList(requirements, project);

    for (const task of tasks) {
      await this.projectManager.addTask(projectId, task);
    }

    this.broadcastLog(projectId, 'success', 'director', `Game plan created: ${requirements.genre} with ${tasks.length} tasks`);

    // Update progress
    await this.updateProgress(projectId, 10);
  }

  parseGameRequirements(prompt) {
    const prompt_lower = prompt.toLowerCase();

    // Detect genre
    const genres = {
      shooter: ['shooter', 'fps', 'tps', 'battle royale', 'call of duty', 'cod'],
      rpg: ['rpg', 'role playing', 'open world', 'adventure'],
      survival: ['survival', 'zombie', 'horror', 'crafting'],
      racing: ['racing', 'car', 'drive', 'race'],
      strategy: ['strategy', 'tower defense', 'rts', 'turn based'],
      puzzle: ['puzzle', 'match', 'brain'],
    };

    let detectedGenre = 'action';
    for (const [genre, keywords] of Object.entries(genres)) {
      if (keywords.some(k => prompt_lower.includes(k))) {
        detectedGenre = genre;
        break;
      }
    }

    // Detect features
    const features = {
      multiplayer: ['multiplayer', 'online', 'pvp', 'coop', 'lan'],
      openWorld: ['open world', 'sandbox', 'exploration'],
      vehicles: ['vehicle', 'car', 'drive', 'fly', 'helicopter'],
      inventory: ['inventory', 'loot', 'items', 'crafting'],
      quests: ['quest', 'mission', 'story', 'campaign'],
      ai: ['ai', 'npc', 'enemy', 'bot'],
      weather: ['weather', 'rain', 'storm', 'dynamic'],
      dayNight: ['day night', 'cycle', 'time'],
    };

    const detectedFeatures = [];
    for (const [feature, keywords] of Object.entries(features)) {
      if (keywords.some(k => prompt_lower.includes(k))) {
        detectedFeatures.push(feature);
      }
    }

    // Detect style
    const styles = {
      realistic: ['realistic', 'photo', 'real', 'hyper'],
      cartoon: ['cartoon', 'toon', 'stylized', 'anime'],
      lowPoly: ['low poly', 'minimal', 'simple'],
      retro: ['retro', 'pixel', '8bit', '16bit'],
    };

    let detectedStyle = 'realistic';
    for (const [style, keywords] of Object.entries(styles)) {
      if (keywords.some(k => prompt_lower.includes(k))) {
        detectedStyle = style;
        break;
      }
    }

    return {
      genre: detectedGenre,
      features: detectedFeatures,
      style: detectedStyle,
      complexity: prompt_lower.includes('simple') ? 'simple' : 
                  prompt_lower.includes('complex') ? 'complex' : 'medium',
    };
  }

  generateTaskList(requirements, project) {
    const tasks = [];
    const basePriority = 100;

    // Core systems first
    tasks.push({
      agentId: 'cpp',
      type: 'core_systems',
      description: `Generate core C++ classes for ${requirements.genre} game`,
      priority: basePriority,
      dependencies: [],
    });

    tasks.push({
      agentId: 'blueprint',
      type: 'game_mode',
      description: 'Create GameMode, GameState, and PlayerController blueprints',
      priority: basePriority - 1,
      dependencies: ['core_systems'],
    });

    // Character
    tasks.push({
      agentId: 'asset',
      type: 'character_mesh',
      description: `Generate ${requirements.style} player character mesh`,
      priority: basePriority - 2,
      dependencies: [],
    });

    tasks.push({
      agentId: 'blueprint',
      type: 'character_bp',
      description: 'Create player character blueprint with movement and abilities',
      priority: basePriority - 3,
      dependencies: ['character_mesh', 'core_systems'],
    });

    // Weapons/Combat
    if (requirements.genre === 'shooter' || requirements.genre === 'rpg') {
      tasks.push({
        agentId: 'asset',
        type: 'weapons',
        description: 'Generate weapon meshes and textures',
        priority: basePriority - 4,
        dependencies: [],
      });

      tasks.push({
        agentId: 'blueprint',
        type: 'weapon_system',
        description: 'Create weapon system with shooting, reloading, and damage',
        priority: basePriority - 5,
        dependencies: ['weapons', 'character_bp'],
      });
    }

    // Level
    tasks.push({
      agentId: 'level',
      type: 'level_design',
      description: `Design ${requirements.genre} level layout with ${requirements.style} aesthetics`,
      priority: basePriority - 6,
      dependencies: [],
    });

    // Environment assets
    tasks.push({
      agentId: 'asset',
      type: 'environment',
      description: 'Generate environment props, buildings, and terrain textures',
      priority: basePriority - 7,
      dependencies: ['level_design'],
    });

    // UI
    tasks.push({
      agentId: 'ui',
      type: 'hud',
      description: 'Create HUD, menus, and UI widgets',
      priority: basePriority - 8,
      dependencies: ['game_mode'],
    });

    // Audio
    tasks.push({
      agentId: 'sound',
      type: 'audio',
      description: 'Generate background music, SFX, and voice placeholders',
      priority: basePriority - 9,
      dependencies: [],
    });

    // Multiplayer
    if (project.multiplayer) {
      tasks.push({
        agentId: 'network',
        type: 'networking',
        description: 'Implement multiplayer networking, replication, and matchmaking',
        priority: basePriority - 10,
        dependencies: ['game_mode', 'character_bp'],
      });
    }

    // AI
    if (requirements.features.includes('ai')) {
      tasks.push({
        agentId: 'cpp',
        type: 'ai_system',
        description: 'Create AI controller with behavior trees and navigation',
        priority: basePriority - 11,
        dependencies: ['level_design'],
      });
    }

    // Optimization
    tasks.push({
      agentId: 'optimizer',
      type: 'optimization',
      description: 'Optimize for mobile with LODs, texture compression, and draw calls',
      priority: basePriority - 20,
      dependencies: ['level_design', 'environment', 'character_mesh'],
    });

    // QA
    tasks.push({
      agentId: 'qa',
      type: 'testing',
      description: 'Run automated gameplay tests and performance benchmarks',
      priority: basePriority - 21,
      dependencies: ['optimization'],
    });

    return tasks;
  }

  async generateAssets(projectId) {
    const project = this.projectManager.getProject(projectId);
    const tasks = project.tasks.filter(t => 
      t.agentId === 'asset' && t.status === 'pending'
    );

    this.broadcastLog(projectId, 'info', 'asset', `Starting asset generation: ${tasks.length} tasks`);

    const assetAgent = this.agents.get('asset');

    for (const task of tasks) {
      await this.projectManager.updateTask(projectId, task.id, { status: 'in_progress' });

      try {
        const result = await assetAgent.execute(task, project);
        await this.projectManager.updateTask(projectId, task.id, { 
          status: 'completed',
          result,
        });

        // Add generated assets to project
        if (result.assets) {
          for (const asset of result.assets) {
            await this.projectManager.addAsset(projectId, asset);
          }
        }

        this.broadcastLog(projectId, 'success', 'asset', `Generated: ${task.description}`);
      } catch (error) {
        await this.projectManager.updateTask(projectId, task.id, { 
          status: 'failed',
          error: error.message,
        });
        this.broadcastLog(projectId, 'error', 'asset', `Failed: ${task.description} - ${error.message}`);
      }
    }

    await this.updateProgress(projectId, 40);
  }

  async generateCode(projectId) {
    const project = this.projectManager.getProject(projectId);

    // Run C++ and Blueprint agents in parallel
    const cppTasks = project.tasks.filter(t => t.agentId === 'cpp' && t.status === 'pending');
    const bpTasks = project.tasks.filter(t => t.agentId === 'blueprint' && t.status === 'pending');

    this.broadcastLog(projectId, 'info', 'cpp', `Starting code generation: ${cppTasks.length} C++ tasks`);
    this.broadcastLog(projectId, 'info', 'blueprint', `Starting blueprint generation: ${bpTasks.length} tasks`);

    await Promise.all([
      this.runAgentTasks(projectId, 'cpp', cppTasks),
      this.runAgentTasks(projectId, 'blueprint', bpTasks),
    ]);

    await this.updateProgress(projectId, 60);
  }

  async buildLevel(projectId) {
    const project = this.projectManager.getProject(projectId);
    const levelTasks = project.tasks.filter(t => t.agentId === 'level' && t.status === 'pending');

    const levelAgent = this.agents.get('level');

    for (const task of levelTasks) {
      await this.projectManager.updateTask(projectId, task.id, { status: 'in_progress' });

      try {
        const result = await levelAgent.execute(task, project);
        await this.projectManager.updateTask(projectId, task.id, { 
          status: 'completed',
          result,
        });
        this.broadcastLog(projectId, 'success', 'level', `Level built: ${task.description}`);
      } catch (error) {
        await this.projectManager.updateTask(projectId, task.id, { 
          status: 'failed',
          error: error.message,
        });
        this.broadcastLog(projectId, 'error', 'level', `Failed: ${task.description}`);
      }
    }

    await this.updateProgress(projectId, 75);
  }

  async testGame(projectId) {
    const project = this.projectManager.getProject(projectId);
    const qaAgent = this.agents.get('qa');

    this.broadcastLog(projectId, 'info', 'qa', 'Starting automated testing...');

    try {
      const results = await qaAgent.execute({ type: 'full_test' }, project);

      for (const result of results.tests) {
        await this.projectManager.updateProject(projectId, {
          testResults: [...(project.testResults || []), result],
        });
      }

      this.broadcastLog(projectId, 'success', 'qa', `Tests complete: ${results.passed}/${results.total} passed`);
    } catch (error) {
      this.broadcastLog(projectId, 'error', 'qa', `Testing failed: ${error.message}`);
    }

    await this.updateProgress(projectId, 85);
  }

  async optimizeGame(projectId) {
    const project = this.projectManager.getProject(projectId);
    const optimizer = this.agents.get('optimizer');

    this.broadcastLog(projectId, 'info', 'optimizer', 'Starting performance optimization...');

    try {
      await optimizer.execute({ type: 'mobile_optimize' }, project);
      this.broadcastLog(projectId, 'success', 'optimizer', 'Mobile optimization complete');
    } catch (error) {
      this.broadcastLog(projectId, 'error', 'optimizer', `Optimization failed: ${error.message}`);
    }

    await this.updateProgress(projectId, 95);
  }

  async packageGame(projectId) {
    const project = this.projectManager.getProject(projectId);

    this.broadcastLog(projectId, 'info', 'director', 'Packaging game for distribution...');

    // Simulate packaging process
    for (const platform of project.platform) {
      this.broadcastLog(projectId, 'info', 'director', `Packaging for ${platform}...`);
      await this.delay(2000);
      this.broadcastLog(projectId, 'success', 'director', `${platform} package ready`);
    }

    await this.updateProgress(projectId, 100);
  }

  async runAgentTasks(projectId, agentId, tasks) {
    const agent = this.agents.get(agentId);
    const project = this.projectManager.getProject(projectId);

    for (const task of tasks) {
      // Check dependencies
      const depsComplete = task.dependencies.every(depId => {
        const depTask = project.tasks.find(t => t.type === depId);
        return depTask && depTask.status === 'completed';
      });

      if (!depsComplete) {
        this.broadcastLog(projectId, 'warn', agentId, `Waiting for dependencies: ${task.description}`);
        continue;
      }

      await this.projectManager.updateTask(projectId, task.id, { status: 'in_progress' });

      try {
        const result = await agent.execute(task, project);
        await this.projectManager.updateTask(projectId, task.id, { 
          status: 'completed',
          result,
        });
        this.broadcastLog(projectId, 'success', agentId, `Completed: ${task.description}`);
      } catch (error) {
        await this.projectManager.updateTask(projectId, task.id, { 
          status: 'failed',
          error: error.message,
        });
        this.broadcastLog(projectId, 'error', agentId, `Failed: ${task.description} - ${error.message}`);
      }
    }
  }

  async attemptRecovery(projectId, phase, error) {
    this.broadcastLog(projectId, 'warn', 'director', `Attempting recovery for ${phase}...`);

    // Retry failed tasks
    const project = this.projectManager.getProject(projectId);
    const failedTasks = project.tasks.filter(t => t.status === 'failed');

    for (const task of failedTasks) {
      if (task.error && task.error.includes('timeout')) {
        this.broadcastLog(projectId, 'info', 'director', `Retrying task: ${task.description}`);
        await this.projectManager.updateTask(projectId, task.id, { status: 'pending' });
      }
    }
  }

  async updateProgress(projectId, progress) {
    await this.projectManager.updateProject(projectId, { progress });
    this.broadcast('project_update', { id: projectId, progress });
  }

  handleAgentStatus(agentId, data) {
    this.broadcast('agent_update', { id: agentId, ...data });
  }

  handleAgentLog(agentId, data) {
    const { projectId, ...logData } = data;
    this.broadcastLog(projectId, logData.level || 'info', agentId, logData.message);
  }

  handleAgentComplete(agentId, data) {
    const { projectId } = data;
    const context = this.activeProjects.get(projectId);
    if (context) {
      context.completedAgents.add(agentId);
    }
  }

  handleAgentError(agentId, data) {
    const { projectId, error } = data;
    const context = this.activeProjects.get(projectId);
    if (context) {
      context.failedAgents.add(agentId);
    }
    this.broadcastLog(projectId, 'error', agentId, error.message);
  }

  broadcastLog(projectId, level, agent, message) {
    const log = {
      id: uuidv4(),
      timestamp: new Date().toISOString(),
      level,
      message,
      agent,
    };

    this.projectManager.addLog(projectId, log);
    this.broadcast('log', log);
  }

  broadcast(event, data) {
    if (this.wsManager) {
      this.wsManager.broadcast(event, data);
    }
  }

  getAgentStatuses() {
    return Array.from(this.agents.entries()).map(([id, agent]) => ({
      id,
      name: agent.name,
      role: agent.role,
      status: agent.status || 'idle',
      currentTask: agent.currentTask || null,
      progress: agent.progress || 0,
      color: agent.color,
    }));
  }

  async shutdown() {
    logger.info('Shutting down orchestrator...');
    for (const [id, agent] of this.agents) {
      if (agent.shutdown) {
        await agent.shutdown();
      }
    }
  }

  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

module.exports = { AgentOrchestrator };
