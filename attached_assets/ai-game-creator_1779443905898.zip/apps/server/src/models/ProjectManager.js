const { v4: uuidv4 } = require('uuid');
const fs = require('fs').promises;
const path = require('path');
const logger = require('../utils/logger');

class ProjectManager {
  constructor() {
    this.projects = new Map();
    this.projectsDir = process.env.PROJECTS_DIR || './projects';
    this.ensureProjectsDir();
  }

  async ensureProjectsDir() {
    try {
      await fs.mkdir(this.projectsDir, { recursive: true });
    } catch (err) {
      logger.error('Failed to create projects directory:', err);
    }
  }

  async createProject(config) {
    const id = uuidv4();
    const project = {
      id,
      name: this.generateProjectName(config.prompt),
      description: config.prompt,
      status: 'planning',
      progress: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      ue5Path: path.join(this.projectsDir, id, 'UE5'),
      buildPath: path.join(this.projectsDir, id, 'Build'),
      genre: config.genre || 'action',
      platform: config.platform || ['windows'],
      multiplayer: config.multiplayer || false,
      complexity: config.complexity || 'medium',
      assets: [],
      agents: [],
      logs: [],
      errors: [],
      testResults: [],
      tasks: [],
      config: {
        lighting: 'dynamic',
        renderScale: config.complexity === 'simple' ? 'low' : 'high',
        networkType: config.multiplayer ? 'dedicated' : 'single',
        aiDifficulty: 'medium',
        saveSystem: true,
        inventory: true,
        weather: true,
        dayNightCycle: true,
      },
    };

    // Create project directory structure
    const projectDir = path.join(this.projectsDir, id);
    const dirs = [
      'Source',
      'Content/Blueprints',
      'Content/Maps',
      'Content/Materials',
      'Content/Meshes',
      'Content/Textures',
      'Content/Sounds',
      'Content/UI',
      'Content/Animations',
      'Config',
      'Build',
      'Plugins',
      'Scripts',
    ];

    for (const dir of dirs) {
      await fs.mkdir(path.join(projectDir, dir), { recursive: true });
    }

    // Write initial project config
    await fs.writeFile(
      path.join(projectDir, 'project.json'),
      JSON.stringify(project, null, 2)
    );

    this.projects.set(id, project);
    logger.info(`Project created: ${project.name} (${id})`);
    return project;
  }

  generateProjectName(prompt) {
    // Extract key words from prompt for project name
    const words = prompt.toLowerCase().split(/\s+/);
    const keyWords = words.filter(w => 
      !['a', 'an', 'the', 'create', 'make', 'build', 'game', 'with', 'and', 'or', 'in'].includes(w)
    );
    const name = keyWords.slice(0, 3).map(w => w.charAt(0).toUpperCase() + w.slice(1)).join('');
    return name || 'UntitledProject';
  }

  getProject(id) {
    return this.projects.get(id);
  }

  getAllProjects() {
    return Array.from(this.projects.values());
  }

  async updateProject(id, updates) {
    const project = this.projects.get(id);
    if (!project) throw new Error(`Project ${id} not found`);

    Object.assign(project, updates, { updatedAt: new Date().toISOString() });

    // Persist to disk
    const projectDir = path.join(this.projectsDir, id);
    await fs.writeFile(
      path.join(projectDir, 'project.json'),
      JSON.stringify(project, null, 2)
    );

    return project;
  }

  async addLog(projectId, log) {
    const project = this.projects.get(projectId);
    if (!project) return;

    project.logs.unshift({
      id: uuidv4(),
      timestamp: new Date().toISOString(),
      ...log,
    });

    // Keep only last 1000 logs
    if (project.logs.length > 1000) {
      project.logs = project.logs.slice(0, 1000);
    }
  }

  async addAsset(projectId, asset) {
    const project = this.projects.get(projectId);
    if (!project) return;

    project.assets.push({
      id: uuidv4(),
      createdAt: new Date().toISOString(),
      status: 'pending',
      ...asset,
    });
  }

  async updateAsset(projectId, assetId, updates) {
    const project = this.projects.get(projectId);
    if (!project) return;

    const asset = project.assets.find(a => a.id === assetId);
    if (asset) {
      Object.assign(asset, updates);
    }
  }

  async addError(projectId, error) {
    const project = this.projects.get(projectId);
    if (!project) return;

    project.errors.push({
      id: uuidv4(),
      timestamp: new Date().toISOString(),
      fixed: false,
      fixAttempt: 0,
      ...error,
    });
  }

  async addTask(projectId, task) {
    const project = this.projects.get(projectId);
    if (!project) return;

    project.tasks.push({
      id: uuidv4(),
      projectId,
      status: 'pending',
      createdAt: new Date().toISOString(),
      ...task,
    });
  }

  async updateTask(projectId, taskId, updates) {
    const project = this.projects.get(projectId);
    if (!project) return;

    const task = project.tasks.find(t => t.id === taskId);
    if (task) {
      Object.assign(task, updates);
      if (updates.status === 'completed' || updates.status === 'failed') {
        task.completedAt = new Date().toISOString();
      }
    }
  }

  async deleteProject(id) {
    const project = this.projects.get(id);
    if (!project) return false;

    try {
      const projectDir = path.join(this.projectsDir, id);
      await fs.rm(projectDir, { recursive: true, force: true });
      this.projects.delete(id);
      logger.info(`Project deleted: ${id}`);
      return true;
    } catch (err) {
      logger.error(`Failed to delete project ${id}:`, err);
      return false;
    }
  }
}

module.exports = { ProjectManager };
