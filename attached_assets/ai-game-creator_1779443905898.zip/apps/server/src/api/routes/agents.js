const express = require('express');
const { asyncHandler } = require('../../utils/errors');

function createAgentsRouter({ orchestrator, wsManager }) {
  const router = express.Router();

  // Get all agent statuses
  router.get('/', asyncHandler(async (req, res) => {
    const agents = orchestrator.getAgentStatuses();
    res.json({ success: true, agents });
  }));

  // Get specific agent status
  router.get('/:id', asyncHandler(async (req, res) => {
    const agents = orchestrator.getAgentStatuses();
    const agent = agents.find(a => a.id === req.params.id);
    if (!agent) {
      return res.status(404).json({ error: 'Agent not found' });
    }
    res.json({ success: true, agent });
  }));

  // Restart agent
  router.post('/:id/restart', asyncHandler(async (req, res) => {
    const agent = orchestrator.agents.get(req.params.id);
    if (!agent) {
      return res.status(404).json({ error: 'Agent not found' });
    }

    if (agent.shutdown) await agent.shutdown();
    if (agent.initialize) await agent.initialize();

    res.json({ success: true, message: 'Agent restarted' });
  }));

  // Send message to agent
  router.post('/:id/message', asyncHandler(async (req, res) => {
    const { message } = req.body;
    const agent = orchestrator.agents.get(req.params.id);
    if (!agent) {
      return res.status(404).json({ error: 'Agent not found' });
    }

    // Process message
    res.json({ success: true, response: `Agent ${agent.name} received: ${message}` });
  }));

  return router;
}

module.exports = createAgentsRouter;
