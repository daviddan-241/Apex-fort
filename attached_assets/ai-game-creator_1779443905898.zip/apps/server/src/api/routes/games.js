const express = require('express');
const { asyncHandler } = require('../../utils/errors');
const logger = require('../../utils/logger');

function createGamesRouter({ projectManager, orchestrator, wsManager }) {
  const router = express.Router();

  // Create a new game
  router.post('/create', asyncHandler(async (req, res) => {
    const { prompt, genre, platform, multiplayer, complexity, style } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    logger.info(`Creating game from prompt: ${prompt}`);

    const project = await orchestrator.createGame(prompt, {
      genre,
      platform: platform || ['windows'],
      multiplayer: multiplayer || false,
      complexity,
      style,
    });

    res.json({
      success: true,
      project,
      message: 'Game creation started',
    });
  }));

  // Get all projects
  router.get('/', asyncHandler(async (req, res) => {
    const projects = projectManager.getAllProjects();
    res.json({ success: true, projects });
  }));

  // Get specific project
  router.get('/:id', asyncHandler(async (req, res) => {
    const project = projectManager.getProject(req.params.id);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }
    res.json({ success: true, project });
  }));

  // Update project
  router.patch('/:id', asyncHandler(async (req, res) => {
    const project = await projectManager.updateProject(req.params.id, req.body);
    res.json({ success: true, project });
  }));

  // Delete project
  router.delete('/:id', asyncHandler(async (req, res) => {
    const deleted = await projectManager.deleteProject(req.params.id);
    res.json({ success: deleted });
  }));

  // Stop generation
  router.post('/stop', asyncHandler(async (req, res) => {
    // Implementation for stopping generation
    res.json({ success: true, message: 'Generation stopped' });
  }));

  // Export build
  router.post('/:id/export', asyncHandler(async (req, res) => {
    const { platform } = req.body;
    const project = projectManager.getProject(req.params.id);

    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    logger.info(`Exporting project ${project.id} for ${platform}`);

    // Trigger packaging
    res.json({
      success: true,
      message: `Export started for ${platform}`,
      downloadUrl: `/downloads/${project.id}/${platform}`,
    });
  }));

  // Get project logs
  router.get('/:id/logs', asyncHandler(async (req, res) => {
    const project = projectManager.getProject(req.params.id);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }
    res.json({ success: true, logs: project.logs || [] });
  }));

  // Get project assets
  router.get('/:id/assets', asyncHandler(async (req, res) => {
    const project = projectManager.getProject(req.params.id);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }
    res.json({ success: true, assets: project.assets || [] });
  }));

  // Get project errors
  router.get('/:id/errors', asyncHandler(async (req, res) => {
    const project = projectManager.getProject(req.params.id);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }
    res.json({ success: true, errors: project.errors || [] });
  }));

  // Get project tasks
  router.get('/:id/tasks', asyncHandler(async (req, res) => {
    const project = projectManager.getProject(req.params.id);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }
    res.json({ success: true, tasks: project.tasks || [] });
  }));

  return router;
}

module.exports = createGamesRouter;
