const express = require('express');
const { asyncHandler } = require('../../utils/errors');

function createAssetsRouter({ projectManager }) {
  const router = express.Router();

  // Get asset preview
  router.get('/:projectId/:assetId', asyncHandler(async (req, res) => {
    const project = projectManager.getProject(req.params.projectId);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    const asset = project.assets?.find(a => a.id === req.params.assetId);
    if (!asset) {
      return res.status(404).json({ error: 'Asset not found' });
    }

    res.json({ success: true, asset });
  }));

  // Regenerate asset
  router.post('/:projectId/:assetId/regenerate', asyncHandler(async (req, res) => {
    const project = projectManager.getProject(req.params.projectId);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    // Trigger regeneration
    res.json({ success: true, message: 'Asset regeneration started' });
  }));

  return router;
}

module.exports = createAssetsRouter;
