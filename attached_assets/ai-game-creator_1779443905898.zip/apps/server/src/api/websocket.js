const logger = require('../../utils/logger');

class WebSocketManager {
  constructor(io, orchestrator) {
    this.io = null;
    this.orchestrator = orchestrator;
    this.clients = new Map();
  }

  attach(io) {
    this.io = io;

    io.on('connection', (socket) => {
      logger.info(`Client connected: ${socket.id}`);

      this.clients.set(socket.id, {
        socket,
        subscribedProjects: new Set(),
      });

      socket.on('subscribe', (projectId) => {
        const client = this.clients.get(socket.id);
        if (client) {
          client.subscribedProjects.add(projectId);
          socket.join(`project:${projectId}`);
          logger.info(`Client ${socket.id} subscribed to project ${projectId}`);
        }
      });

      socket.on('unsubscribe', (projectId) => {
        const client = this.clients.get(socket.id);
        if (client) {
          client.subscribedProjects.delete(projectId);
          socket.leave(`project:${projectId}`);
        }
      });

      socket.on('command', (data) => {
        // Handle client commands
        logger.info(`Command from ${socket.id}: ${data.command}`);
      });

      socket.on('disconnect', () => {
        logger.info(`Client disconnected: ${socket.id}`);
        this.clients.delete(socket.id);
      });
    });
  }

  broadcast(event, data) {
    if (this.io) {
      this.io.emit(event, data);
    }
  }

  broadcastToProject(projectId, event, data) {
    if (this.io) {
      this.io.to(`project:${projectId}`).emit(event, data);
    }
  }

  sendToClient(socketId, event, data) {
    const client = this.clients.get(socketId);
    if (client) {
      client.socket.emit(event, data);
    }
  }
}

module.exports = { WebSocketManager };
